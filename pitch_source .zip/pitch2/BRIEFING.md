# PITCH v3.5 — AI Briefing

## Commands
| Action | Command |
|--------|---------|
| Build | `python3 /home/claude/pitch2/build.py` |
| Validate | `node /home/claude/pitch2/validate.js` (0 failures required) |
| Output | `/mnt/user-data/outputs/index.html` |

## Project
Single-file football career manager. Vanilla JS + IndexedDB. No framework. `build.py` concatenates 22 source files in strict order → one HTML file.

## Source Map
```
/home/claude/pitch2/
├── build.py / validate.js / shell.html (HTML+CSS)
├── data/
│   ├── plTeams.js / extraLeagues.js (PL + La Liga/Bundesliga/Serie A/Ligue 1)
│   ├── championship.js / leagueOne.js / leagueTwo.js / eredivisie.js  ← AUTO-GENERATED
│   └── csv/  ← edit these, not the .js files
├── modules/  (game logic, no DOM)
│   ├── db.js · matchEngine.js · standings.js · fixtures.js · cups.js
│   ├── transfers.js · potential.js · promotion.js · youthAcademy.js
│   ├── save.js · season.js · gameweek.js
└── ui/
    ├── helpers.js · renderers.js · home_transfers.js
    ├── squad_tactics_offers.js · academy.js · prematch.js · watchmatch.js
```

## Build Order (never reorder)
```
plTeams → extraLeagues → championship → db → matchEngine → standings → fixtures
→ cups → transfers → potential → promotion → youthAcademy → save → season
→ gameweek → helpers → home_transfers → renderers → squad_tactics_offers
→ academy → prematch → watchmatch
```

## Critical Rules

**Event queue:** One button press → pop ONE pendingEvent → pre-match → simulate → result. GW advances only when pendingEvents empty. ❌ `processCupRounds()` · `finaliseGW()` · silent cup sim in `advanceOneFixture`

**Watch Match:** `#modal-bd` IS the modal. All panels use `_openInlinePanel()` (fixed, z-10500). ❌ `showModal()` inside watchmatch · `showModal()` inside `showModal()` · `position:absolute` inside `.modal-xl`

**Match Engine:** 120 phases. GK weight=0 in `pickScorer`. Drain rates must be identical in `simulateMatch` and `simulateMatchSegment`. Mentality flows through every sim path via `getMentalityMods()`.

**Cups:** `LEAGUE_DOMESTIC_CUPS` = knockout cups only. Super cups/European go in `INVITATION_ONLY_CUPS`. On season rollover use `buildInitialCupState()` not `resetCups()`. ❌ Invitation cups with zero activity shown in UI.

**Promotion:** English pyramid only (PL/Champ/L1/L2). Top 2 auto-up, 3–6 playoffs, bottom 3 down. ❌ Playoffs for non-English leagues.

**Fixtures:** Always use `getEffectiveTotalGW(save)` not `save.totalGameweeks`. European finals are post-season.

**Data:** Always `str_replace` over full rewrites. Never hand-edit generated JS (edit CSVs → re-run `csv_to_league.py`). 2025/26 squads, ages from DOB as of Aug 2025.

## Key Schemas
```js
// Player
{ id, name, position, age, attack, midfield, defence, goalkeeping,
  value, wage, teamId, fitness, potentialRating, peakAge,
  goals, assists, cleanSheets, form, injured, suspended, transferListed, isYouth }

// Save
{ userTeamId, userLeague, currentGameweek, totalGameweeks, currentDate, season,
  formation, mentality, lineup, cups, pendingEvents, inboundOffers, youthCohort }
```

## Mentality Mods
| Mentality | goalProbMult | defResistMult | midShareBoost |
|-----------|-------------|---------------|---------------|
| defensive | 0.72 | 1.30 | −0.07 |
| balanced  | 1.00 | 1.00 |  0.00 |
| possession| 0.88 | 1.08 | +0.09 |
| attacking | 1.32 | 0.78 | +0.06 |
