// ── Full-screen overlay for blocking operations ─────────────
function _showFullOverlay(msg) {
  _removeFullOverlay();
  const ov = document.createElement('div');
  ov.id = 'pitch-full-overlay';
  ov.style.cssText = 'position:fixed;inset:0;z-index:10001;background:var(--night,#0a0e14);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px';
  ov.innerHTML = '<div class="loader-spin"></div><div style="color:var(--tx,#fff);font-family:var(--fd,sans-serif);font-size:18px;letter-spacing:1px">' + (msg || 'Loading…') + '</div>';
  document.body.appendChild(ov);
}
function _removeFullOverlay() {
  document.getElementById('pitch-full-overlay')?.remove();
}

// ── COMPETITIONS ─────────────────────────────────────────────
async function renderCompetitions(){
  const save=await getSave();
  const table=await getLeagueTable();
  const allTeams=await getAllTeams();
  const byId=new Map(allTeams.map(t=>[t.id,t]));
  const fullEl=document.getElementById('full-table');
  // Dynamic league title
  const compTitleEl=document.querySelector('.comp-pt');
  if(compTitleEl) compTitleEl.textContent=`${save.userLeague||'Premier League'} ${save.season||'2025/26'}`;
  const totalTeams = table.length;
  const zoneInfo=(pos)=>{
    if(totalTeams===20){
      if(pos<=4)  return 'border-left:3px solid #3b82f6';
      if(pos<=6)  return 'border-left:3px solid #f97316';
      if(pos===7) return 'border-left:3px solid #22c55e';
      if(pos>=18) return 'border-left:3px solid #e84855';
      if(pos>=15) return 'border-left:3px solid #f5c842';
    } else if(totalTeams===24){
      if(pos<=2)  return 'border-left:3px solid #3b82f6';
      if(pos<=6)  return 'border-left:3px solid #22c55e';
      if(pos>=22) return 'border-left:3px solid #e84855';
    } else if(totalTeams===18){
      if(pos<=4)  return 'border-left:3px solid #3b82f6';
      if(pos<=6)  return 'border-left:3px solid #f97316';
      if(pos>=16) return 'border-left:3px solid #e84855';
    }
    return '';
  };
  if(fullEl) fullEl.innerHTML=table.map(row=>`
    <div class="full-row ${row.teamId===save.userTeamId?'hl':''}" style="${zoneInfo(row.position)}">
      <div class="rc">${row.position}</div>
      <div class="tc">${row.crest||''} ${row.teamName}</div>
      <div class="sc">${row.played}</div><div class="sc">${row.won}</div>
      <div class="sc">${row.drawn}</div><div class="sc">${row.lost}</div>
      <div class="sc">${row.goalsFor}</div><div class="sc">${row.goalsAgainst}</div>
      <div class="sc" style="color:${row.goalDifference>=0?'var(--acc)':'var(--acc3)'}">${row.goalDifference>=0?'+':''}${row.goalDifference}</div>
      <div class="pc">${row.points}</div>
      <div class="form-mini">${(row.form||[]).map(f=>`<span class="fdot fd-${f}">${f}</span>`).join('')}</div>
    </div>`).join('');
  // Add zone legend
  const legendEl = document.getElementById('zone-legend');
  if(legendEl){
    if(totalTeams===20) legendEl.innerHTML=`<div class="zone-legend"><span style="border-left:3px solid #3b82f6;padding-left:6px">UCL (Top 4)</span><span style="border-left:3px solid #f97316;padding-left:6px">UEL (5-6)</span><span style="border-left:3px solid #22c55e;padding-left:6px">UECL (7)</span><span style="border-left:3px solid #e84855;padding-left:6px">Relegated (18-20)</span></div>`;
    else if(totalTeams===24) legendEl.innerHTML=`<div class="zone-legend"><span style="border-left:3px solid #3b82f6;padding-left:6px">Promoted (1-2)</span><span style="border-left:3px solid #22c55e;padding-left:6px">Play-offs (3-6)</span><span style="border-left:3px solid #e84855;padding-left:6px">Relegated (22-24)</span></div>`;
    else if(totalTeams===18) legendEl.innerHTML=`<div class="zone-legend"><span style="border-left:3px solid #3b82f6;padding-left:6px">UCL (Top 4)</span><span style="border-left:3px solid #f97316;padding-left:6px">UEL (5-6)</span><span style="border-left:3px solid #e84855;padding-left:6px">Relegated (16-18)</span></div>`;
  }
  const fixtures=await getAllFixtures();
  const played=fixtures.filter(f=>f.played&&f.competition==='league').sort((a,b)=>b.gameweek-a.gameweek).slice(0,30);
  const resEl=document.getElementById('recent-res');
  if(resEl){
    if(!played.length){resEl.innerHTML=`<div class="no-data">No matches played yet.</div>`;return;}
    resEl.innerHTML=played.map(f=>`
      <div class="res-row ${f.homeTeamId===save.userTeamId||f.awayTeamId===save.userTeamId?'ur':''}">
        <div class="res-gw">GW${f.gameweek}</div>
        <div class="res-teams">
          <span class="rth">${byId.get(f.homeTeamId)?.name||f.homeTeamId}</span>
          <span class="rsc">${f.homeGoals} – ${f.awayGoals}</span>
          <span class="rta">${byId.get(f.awayTeamId)?.name||f.awayTeamId}</span>
        </div>
        <div class="res-date">${fmt.dateShort(f.date)}</div>
      </div>`).join('');
  }
}

// ── HONOURS ───────────────────────────────────────────────────
async function renderHonours(){
  const save=await getSave();
  const {combined,earned}=await getHonorsForTeam(save.userTeamId);
  const el=document.getElementById('honours-grid');
  if(!el) return;
  const team=await getTeam(save.userTeamId);
  const league=team?.league??save.userLeague??'Premier League';

  // League title key: derive from save.userLeague
  const leagueTitleKey = {
    'Premier League':'premier_league',
    'Championship':'championship',
    'League One':'league_one',
    'League Two':'league_two',
    'La Liga':'la_liga',
    'Bundesliga':'bundesliga',
    'Serie A':'serie_a',
    'Ligue 1':'ligue_1',
    'Eredivisie':'eredivisie',
  }[league] ?? 'premier_league';

  const leagueTitleName = {
    'Premier League':'Premier League',
    'Championship':'Championship',
    'League One':'League One',
    'League Two':'League Two',
    'La Liga':'La Liga',
    'Bundesliga':'Bundesliga',
    'Serie A':'Serie A',
    'Ligue 1':'Ligue 1',
    'Eredivisie':'Eredivisie',
  }[league] ?? 'League Title';

  // Domestic cups for this nation
  const domesticCupDefs = {
    'Premier League':  [{key:'fa_cup',name:'FA Cup',icon:'🏆',color:'#f5c842'},{key:'league_cup',name:'Carabao Cup',icon:'🥛',color:'#c084fc'}],
    'Championship':    [{key:'fa_cup',name:'FA Cup',icon:'🏆',color:'#f5c842'},{key:'league_cup',name:'Carabao Cup',icon:'🥛',color:'#c084fc'}],
    'League One':      [{key:'fa_cup',name:'FA Cup',icon:'🏆',color:'#f5c842'},{key:'league_cup',name:'Carabao Cup',icon:'🥛',color:'#c084fc'}],
    'League Two':      [{key:'fa_cup',name:'FA Cup',icon:'🏆',color:'#f5c842'},{key:'league_cup',name:'Carabao Cup',icon:'🥛',color:'#c084fc'}],
    'Eredivisie':      [{key:'knvb_beker',name:'KNVB Beker',icon:'🏆',color:'#FF6600'}],
    'La Liga':         [{key:'copa_del_rey',name:'Copa del Rey',icon:'👑',color:'#c8102e'},{key:'supercopa',name:'Supercopa de España',icon:'🔴',color:'#f5c842'}],
    'Bundesliga':      [{key:'dfb_pokal',name:'DFB-Pokal',icon:'🏆',color:'#000000'},{key:'dfb_supercup',name:'DFL-Supercup',icon:'⚡',color:'#d4a017'}],
    'Serie A':         [{key:'coppa_italia',name:'Coppa Italia',icon:'🏆',color:'#009246'},{key:'supercoppa',name:'Supercoppa Italiana',icon:'🔵',color:'#009246'}],
    'Ligue 1':         [{key:'coupe_de_france',name:'Coupe de France',icon:'🏆',color:'#003189'},{key:'trophee_des_champions',name:"Trophée des Champions",icon:'🔵',color:'#e8151b'}],
  }[league] ?? [{key:'fa_cup',name:'FA Cup',icon:'🏆',color:'#f5c842'},{key:'league_cup',name:'League Cup',icon:'🥛',color:'#c084fc'}];

  const trophies=[
    {key:leagueTitleKey, name:leagueTitleName, icon:'🏆', color:'#3b82f6'},
    ...domesticCupDefs,
    {key:'ucl',  name:'Champions League', icon:'⭐', color:'#3b82f6'},
    {key:'uel',  name:'Europa League',    icon:'🟠', color:'#f97316'},
    {key:'uecl', name:'Conference Lge',   icon:'🟢', color:'#22c55e'},
  ];

  el.innerHTML=trophies.map(t=>{
    const total=combined[t.key]||0;
    const myEarned=earned.filter(h=>h.trophy===t.key);
    return`<div class="hon-card">
      <div class="hon-icon">${t.icon}</div>
      <div class="hon-name">${t.name}</div>
      <div class="hon-count" style="color:${t.color}">${total}</div>
      <div class="hon-sub">All-time wins</div>
      ${myEarned.length?`<div class="hon-earned">+${myEarned.length} in your save</div>
        <div class="hon-history">${myEarned.map(h=>`<div class="hon-season">🏆 ${h.season}</div>`).join('')}</div>`:''}
    </div>`;
  }).join('');
}

// ── SETTINGS ──────────────────────────────────────────────────
async function renderSettings(){
  const seasons=await getAllSeasons();
  const el=document.getElementById('season-history');
  if(!el) return;
  if(!seasons.length){el.innerHTML=`<div class="no-data">No completed seasons yet.</div>`;return;}
  el.innerHTML=`<div class="season-hist">${[...seasons].reverse().map(s=>`
    <div class="sh-row">
      <div class="sh-season">Season ${s.season}</div>
      <div class="sh-detail">
        ${s.userFinish}${['st','nd','rd'][s.userFinish-1]||'th'} place ·
        ${s.topScorers?.[0]?`Top scorer: ${s.topScorers[0].name} (${s.topScorers[0].goals}g)`:''}
        ${s.topAssists?.[0]?`· Top assists: ${s.topAssists[0].name} (${s.topAssists[0].assists}a)`:''}
        ${s.prizeMoney?`· Prize: ${fmt.money(s.prizeMoney)}`:''}
      </div>
    </div>`).join('')}</div>`;
}

// ── NEW GAME ───────────────────────────────────────────────────
function renderNewGame(){
  const grid=document.getElementById('team-grid');
  let selId=null,leagueFilter='all';

  // Auto-collects all *_TEAMS arrays — add new leagues via csv_to_league.py, no code changes needed
  const ALL_TEAMS_DATA=[
    ...(typeof PL_TEAMS!=='undefined'?PL_TEAMS:[]),
    ...(typeof EXTRA_LEAGUES_TEAMS!=='undefined'?EXTRA_LEAGUES_TEAMS:[]),
    ...(typeof CHAMPIONSHIP_TEAMS!=='undefined'?CHAMPIONSHIP_TEAMS:[]),
    ...(typeof LEAGUE_ONE_TEAMS!=='undefined'?LEAGUE_ONE_TEAMS:[]),
    ...(typeof LEAGUE_TWO_TEAMS!=='undefined'?LEAGUE_TWO_TEAMS:[]),
    ...(typeof SEGUNDA_TEAMS!=='undefined'?SEGUNDA_TEAMS:[]),
    ...(typeof ZWEITE_LIGA_TEAMS!=='undefined'?ZWEITE_LIGA_TEAMS:[]),
    ...(typeof SERIE_B_TEAMS!=='undefined'?SERIE_B_TEAMS:[]),
    ...(typeof LIGUE_2_TEAMS!=='undefined'?LIGUE_2_TEAMS:[]),
    ...(typeof EREDIVISIE_TEAMS!=='undefined'?EREDIVISIE_TEAMS:[]),
  ];

  const leagues=[...new Set(ALL_TEAMS_DATA.map(t=>t.league||'Premier League'))];

  // Build league filter buttons
  const filterEl=document.getElementById('ng-filters');
  if(filterEl){
    filterEl.innerHTML=`<button class="ng-f on" data-league="all">All (${ALL_TEAMS_DATA.length})</button>`
      +leagues.map(l=>{
        const count=ALL_TEAMS_DATA.filter(t=>(t.league||'Premier League')===l).length;
        const icons={'Premier League':'🏴󠁧󠁢󠁥󠁮󠁧󠁿','Championship':'🏴󠁧󠁢󠁥󠁮󠁧󠁿','League One':'🏴󠁧󠁢󠁥󠁮󠁧󠁿','League Two':'🏴󠁧󠁢󠁥󠁮󠁧󠁿','La Liga':'🇪🇸','Segunda División':'🇪🇸','Bundesliga':'🇩🇪','2. Bundesliga':'🇩🇪','Serie A':'🇮🇹','Serie B':'🇮🇹','Ligue 1':'🇫🇷','Ligue 2':'🇫🇷','Eredivisie':'🇳🇱'};
        return `<button class="ng-f" data-league="${l}">${icons[l]||'🌐'} ${l} (${count})</button>`;
      }).join('');
  }

  function buildGrid(){
    const teams=leagueFilter==='all'?ALL_TEAMS_DATA:ALL_TEAMS_DATA.filter(t=>(t.league||'Premier League')===leagueFilter);
    grid.innerHTML=teams.map(t=>`
      <div class="team-card ${t.id===selId?'sel':''}" data-tid="${t.id}">
        <div class="tc-crest">${t.crest}</div>
        <div class="tc-name">${t.name}</div>
        <div class="tc-rep">${t.league||'Premier League'} · Rep ${t.reputation}</div>
        <div class="tc-budget">${fmt.money(t.budget)}</div>
      </div>`).join('');
    grid.querySelectorAll('.team-card').forEach(card=>{
      card.onclick=()=>{
        grid.querySelectorAll('.team-card').forEach(c=>c.classList.remove('sel'));
        card.classList.add('sel');
        selId=card.dataset.tid;
        document.getElementById('btn-start').disabled=false;
      };
    });
  }

  buildGrid();

  document.querySelectorAll('#ng-filters .ng-f').forEach(btn=>{
    btn.onclick=()=>{
      document.querySelectorAll('#ng-filters .ng-f').forEach(b=>b.classList.remove('on'));
      btn.classList.add('on');
      leagueFilter=btn.dataset.league;
      buildGrid();
    };
  });

  document.getElementById('btn-start').onclick=async()=>{
    if(!selId) return;
    const btn=document.getElementById('btn-start');
    btn.disabled=true; btn.textContent='Setting up…';
    try{
      await startNewGame(selId);
      document.getElementById('ng').style.display='none';
      document.getElementById('app').style.display='flex';
      initUI();
      await navigateTo('home');
    }catch(err){
      btn.disabled=false; btn.textContent='Start Season →';
      toast(err.message,'error');
    }
  };

  // ── Import save from new game screen ──────────────────────
  const ngImportBtn = document.getElementById('btn-import-ng');
  const ngImportInput = document.getElementById('import-save-ng');
  ngImportBtn?.addEventListener('click', () => {
    showModal('Import Save', `
      <p style="color:var(--tx2);line-height:1.7;margin-bottom:10px">Paste a save code to resume a previous career.</p>
      <textarea id="ng-save-code-input" placeholder="Paste save code here…" style="width:100%;height:90px;background:var(--sur);color:var(--tx);border:1px solid var(--bdr);border-radius:8px;padding:10px;font-family:monospace;font-size:10px;resize:none;word-break:break-all"></textarea>
    `, [
      { id:'ng-import-code', label:'📋 Load from Code', cls:'btn-p', handler: async () => {
        const code = document.getElementById('ng-save-code-input')?.value?.trim();
        if (!code) { toast('Paste a save code first', 'error'); return false; }
        _showFullOverlay('Loading save…');
        try {
          await importSaveFromCode(code);
          location.reload();
        } catch (err) {
          _removeFullOverlay();
          toast('Import failed: ' + err.message, 'error');
          return false;
        }
      }},
      { id:'ng-import-file', label:'📂 Load from File', cls:'btn-s', handler: () => { ngImportInput?.click(); return false; } },
      { id:'cancel', label:'Cancel', cls:'btn-s' }
    ]);
  });
  ngImportInput?.addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    _showFullOverlay('Loading save…');
    try {
      await importSaveFile(file);
      location.reload();
    } catch (err) {
      _removeFullOverlay();
      toast('Import failed: ' + err.message, 'error');
    } finally {
      ngImportInput.value = '';
    }
  });
}

// ── INIT UI ────────────────────────────────────────────────────
function initUI(){
  registerScreen('home',         renderHome);
  registerScreen('transfers',    renderTransfers);
  registerScreen('competitions', renderCompetitions);
  registerScreen('cups',         renderCups);
  registerScreen('squad',        renderSquad);
  registerScreen('academy',      renderAcademy);
  registerScreen('tactics',      renderTactics);
  registerScreen('honours',      renderHonours);
  registerScreen('settings',     renderSettings);

  document.querySelectorAll('[data-nav]').forEach(el=>{
    el.addEventListener('click',()=>navigateTo(el.dataset.nav));
  });
  document.getElementById('h-tbl-link')?.addEventListener('click',()=>navigateTo('competitions'));
  document.getElementById('btn-reset')?.addEventListener('click',()=>{
    showModal('Reset Game?',
      '<p style="color:var(--tx2);line-height:1.7">Delete all progress and return to team selection. Cannot be undone.</p>',
      [{id:'reset',label:'Reset',cls:'btn-d',handler:async()=>{
        _showFullOverlay('Resetting…');
        try { await deleteDB(); } catch(e) { console.error(e); }
        location.reload();
      }},
       {id:'cancel',label:'Cancel',cls:'btn-s'}]
    );
  });

  // ── Shared save/load handlers ────────────────────────────────
  function _handleExportClick() {
    (async () => {
      try {
        const result = await exportSaveFile();
        showModal('Save Exported', `
          <p style="color:var(--tx2);line-height:1.7;margin-bottom:10px">Your save code is below. <strong>Copy it</strong> and paste it somewhere safe to restore later.</p>
          <p style="color:var(--txd);font-size:11px;margin-bottom:8px">Season ${result.meta.season} · GW ${result.meta.gameweek} · ${result.meta.teamId}</p>
          <textarea id="save-code-output" readonly style="width:100%;height:90px;background:var(--sur);color:var(--tx);border:1px solid var(--bdr);border-radius:8px;padding:10px;font-family:monospace;font-size:10px;resize:none;word-break:break-all">${result.saveCode}</textarea>
        `, [
          { id:'copy-code', label:'📋 Copy Save Code', cls:'btn-p', handler: async () => {
            const ta = document.getElementById('save-code-output');
            try { await navigator.clipboard.writeText(ta.value); toast('Save code copied to clipboard!'); }
            catch(e) { ta.select(); document.execCommand('copy'); toast('Save code copied!'); }
            return false;
          }},
          { id:'done', label:'Done', cls:'btn-s' }
        ]);
      } catch (err) { toast('Export failed: ' + err.message, 'error'); }
    })();
  }

  function _handleImportClick(fileInputId) {
    const fileInput = document.getElementById(fileInputId);
    showModal('Import Save', `
      <p style="color:var(--tx2);line-height:1.7;margin-bottom:10px">This will <strong>replace</strong> your current career. Paste a save code below, or choose a .pitch file.</p>
      <textarea id="save-code-input" placeholder="Paste save code here…" style="width:100%;height:90px;background:var(--sur);color:var(--tx);border:1px solid var(--bdr);border-radius:8px;padding:10px;font-family:monospace;font-size:10px;resize:none;word-break:break-all"></textarea>
    `, [
      { id:'import-code', label:'📋 Load from Code', cls:'btn-p', handler: async () => {
        const code = document.getElementById('save-code-input')?.value?.trim();
        if (!code) { toast('Paste a save code first', 'error'); return false; }
        _showFullOverlay('Loading save…');
        try { await importSaveFromCode(code); location.reload(); }
        catch (err) { _removeFullOverlay(); toast('Import failed: ' + err.message, 'error'); return false; }
      }},
      { id:'import-file', label:'📂 Load from File', cls:'btn-s', handler: () => { fileInput?.click(); return false; } },
      { id:'cancel', label:'Cancel', cls:'btn-s' }
    ]);
  }

  // ── Settings Export Save ───────────────────────────────────
  document.getElementById('btn-export-save')?.addEventListener('click', _handleExportClick);

  // ── Settings Import Save ───────────────────────────────────
  document.getElementById('btn-import-save')?.addEventListener('click', () => _handleImportClick('import-save-input'));
  const importInput = document.getElementById('import-save-input');
  importInput?.addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    _showFullOverlay('Loading save…');
    try { await importSaveFile(file); location.reload(); }
    catch (err) { _removeFullOverlay(); toast('Import failed: ' + err.message, 'error'); }
    finally { importInput.value = ''; }
  });
}

// ── BOOT ──────────────────────────────────────────────────────
async function boot(){
  try{
    await openDB();
    const save=await getSave();
    if(!save||save._deleted){
      document.getElementById('ng').style.display='flex';
      document.getElementById('app').style.display='none';
      renderNewGame();
    } else {
      document.getElementById('ng').style.display='none';
      document.getElementById('app').style.display='flex';
      initUI();
      await navigateTo('home');
    }
  }catch(err){
    console.error('[boot]',err);
    document.body.innerHTML=`<div style="color:var(--acc3);padding:40px;font-family:monospace;background:var(--night)">Fatal error: ${err.message}<br><br><button onclick="location.reload()" style="padding:8px 16px;margin-top:12px;cursor:pointer">Reload</button></div>`;
  }
}

document.addEventListener('DOMContentLoaded',boot);
