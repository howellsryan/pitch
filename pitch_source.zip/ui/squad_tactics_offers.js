// ══════════════════════════════════════════════════════════════
// SQUAD SCREEN — clean card-based layout with transfer listing
// ══════════════════════════════════════════════════════════════
async function renderSquad() {
  const save    = await getSave();
  const players = await getPlayersByTeam(save.userTeamId);
  const team    = await getTeam(save.userTeamId);
  const el      = document.getElementById('sq-list');
  if (!el) return;

  const hdrEl = document.getElementById('sq-hdr');
  if (hdrEl && team) hdrEl.innerHTML = `
    <div style="text-align:right">
      <div style="font-family:var(--fd);font-size:16px;letter-spacing:1px">${team.name}</div>
      <div style="font-size:11px;color:var(--tx2)">${players.length} players registered</div>
    </div>`;

  const groups = {
    'GK': players.filter(p => p.position === 'GK'),
    'DEF': players.filter(p => ['CB','RB','LB'].includes(p.position)),
    'MID': players.filter(p => ['CM','CDM','CAM','RM','LM'].includes(p.position)),
    'FWD': players.filter(p => ['ST','CF','RW','LW'].includes(p.position)),
  };
  const groupNames = { GK:'Goalkeepers', DEF:'Defenders', MID:'Midfielders', FWD:'Forwards' };

  el.innerHTML = Object.entries(groups).filter(([,g]) => g.length > 0).map(([key, grp]) => {
    const sorted = [...grp].sort((a,b) => primaryRating(b) - primaryRating(a));
    return `<div class="sq-group">
      <div class="sq-group-hdr">
        <span>${groupNames[key]}</span>
        <span style="font-size:11px;font-family:var(--fm);color:var(--tx2)">${grp.length} players</span>
      </div>
      <div class="sq-cards">
        ${sorted.map(p => buildPlayerCard(p, save)).join('')}
      </div>
    </div>`;
  }).join('');

  // Wire all action buttons
  el.querySelectorAll('[data-sq-action]').forEach(btn => {
    btn.onclick = (e) => {
      e.stopPropagation();
      handleSquadAction(btn.dataset.sqAction, btn.dataset.pid, players, save);
    };
  });
}

function buildPlayerCard(p, save) {
  const g        = posGroup(p.position);
  const r        = primaryRating(p);
  const fl       = formLabel(p);
  const fitness  = Math.round(p.fitness ?? 90);
  const fitColor = fitness >= 75 ? 'var(--acc)' : fitness >= 50 ? 'var(--acc2)' : 'var(--acc3)';
  const fav      = formAdjustedValue ? formAdjustedValue(p) : p.value;
  const isListed = p.transferListed === true;
  const potStars = getPotentialStars ? getPotentialStars(p) : 0;
  const potLabel = getPotentialLabel ? getPotentialLabel(p) : '';
  const potDisp  = potStars ? '★'.repeat(potStars) + '☆'.repeat(5 - potStars) : '';
  const potColor = ['','#8a9ab0','#22c55e','#3b82f6','#f5c842','#e84855'][potStars] ?? '#8a9ab0';

  return `<div class="sq-card ${p.injured ? 'sq-card-inj' : ''} ${isListed ? 'sq-card-listed' : ''}">
    <div class="sq-card-left">
      <div class="sq-card-rat">${r}</div>
      <div class="sq-card-pos pos ${g}">${p.position}</div>
    </div>
    <div class="sq-card-mid">
      <div class="sq-card-name">
        ${p.injured ? '🤕 ' : ''}${p.name}
        ${p.injured ? '<span class="inj-badge">INJ</span>' : ''}
        ${isListed ? '<span class="listed-badge">LISTED</span>' : ''}
      </div>
      <div class="sq-card-meta">
        <span>Age ${p.age}</span>
        <span class="fb ${fl.cls}">${fl.text}</span>
        ${potDisp ? `<span style="color:${potColor};font-size:10px" title="${potLabel}">${potDisp}</span>` : ''}
        ${p.goals > 0    ? `<span>⚽ ${p.goals}</span>` : ''}
        ${p.assists > 0  ? `<span>🎯 ${p.assists}</span>` : ''}
        ${p.cleanSheets > 0 ? `<span>🧤 ${p.cleanSheets}</span>` : ''}
      </div>
      <div class="sq-card-bars">
        ${p.position === 'GK'
          ? `${attrBar('GK', p.goalkeeping, true)}${attrBar('ATK', p.attack, false)}`
          : `${attrBar('ATK', p.attack, g==='ATT')}${attrBar('MID', p.midfield, g==='MID')}${attrBar('DEF', p.defence, g==='DEF')}`
        }
      </div>
    </div>
    <div class="sq-card-right">
      <div class="sq-card-val">${fmt.money(fav)}</div>
      <div class="sq-card-wage">${fmt.wage(p.wage)}</div>
      <div class="sq-card-fit" style="color:${fitColor}">🏃 ${fitness}%</div>
      <div class="sq-card-btns">
        <button class="sq-btn-sm ${p.inSquad !== false ? 'sq-btn-in' : 'sq-btn-out'}"
          data-sq-action="${p.inSquad !== false ? 'exclude' : 'include'}"
          data-pid="${p.id}">
          ${p.inSquad !== false ? 'Active' : 'Excluded'}
        </button>
        <button class="sq-btn-sm ${isListed ? 'sq-btn-unlist' : 'sq-btn-list'}"
          data-sq-action="${isListed ? 'unlist' : 'list'}"
          data-pid="${p.id}">
          ${isListed ? 'Unlist' : 'List'}
        </button>
      </div>
    </div>
  </div>`;
}

function attrBar(label, val, isPrimary) {
  const pct = Math.round((val / 99) * 100);
  const color = isPrimary
    ? 'linear-gradient(90deg,var(--acc),#7fff9a)'
    : 'linear-gradient(90deg,var(--sur3),var(--tx2))';
  return `<div class="sq-bar-row">
    <span class="sq-bar-lbl">${label}</span>
    <div class="sq-bar-w"><div class="sq-bar" style="width:${pct}%;background:${color}"></div></div>
    <span class="sq-bar-v" style="${isPrimary ? 'color:var(--acc)' : ''}">${val}</span>
  </div>`;
}

async function handleSquadAction(action, playerId, players, save) {
  const pl = players.find(p => p.id === playerId);
  if (!pl) return;

  switch (action) {
    case 'include':
      await putPlayer({ ...pl, inSquad: true });
      toast(`${pl.name} added to squad`, 'success', 2000);
      break;
    case 'exclude':
      await putPlayer({ ...pl, inSquad: false });
      toast(`${pl.name} excluded from squad`, 'info', 2000);
      break;
    case 'list':
      await putPlayer({ ...pl, transferListed: true });
      toast(`${pl.name} listed for transfer — AI clubs will now bid`, 'success', 3000);
      break;
    case 'unlist':
      await putPlayer({ ...pl, transferListed: false });
      toast(`${pl.name} removed from transfer list`, 'info', 2000);
      break;
  }
  await renderSquad();
}

// ══════════════════════════════════════════════════════════════
// TACTICS SCREEN — full-screen pitch, tap-to-swap bottom sheet
// ══════════════════════════════════════════════════════════════
async function renderTactics() {
  const save    = await getSave();
  const players = await getPlayersByTeam(save.userTeamId);
  const el      = document.getElementById('screen-tactics');
  if (!el) return;

  const currentFormation = save.formation ?? '4-3-3';
  const savedLineup      = save.lineup ?? [];
  const currentMentality = save.mentality ?? 'balanced';

  const MENTALITIES = [
    // mentality-pill buttons rendered as compact m-pill strip
    { id:'defensive',  icon:'🛡️', label:'DEF',  fullLabel:'Defensive',  desc:'Compact & hard to break down' },
    { id:'balanced',   icon:'⚖️', label:'BAL',   fullLabel:'Balanced',   desc:'No bias — steady in both phases' },
    { id:'possession', icon:'🎯', label:'POS', fullLabel:'Possession', desc:'Patient build-up, dominate the ball' },
    { id:'attacking',  icon:'⚡', label:'ATK',  fullLabel:'Attacking',  desc:'High press & direct, more exposed' },
  ];
  const curMentObj = MENTALITIES.find(m => m.id === currentMentality) ?? MENTALITIES[1];

  // Formation visual slot positions (x/y as % of pitch)
  const SLOT_LAYOUT = {
    // 3 at the back
    '3-4-3':   [{p:'GK',x:50,y:90},{p:'CB',x:70,y:76},{p:'CB',x:50,y:78},{p:'CB',x:30,y:76},{p:'RM',x:85,y:54},{p:'CM',x:62,y:54},{p:'CM',x:38,y:54},{p:'LM',x:15,y:54},{p:'RW',x:80,y:28},{p:'ST',x:50,y:20},{p:'LW',x:20,y:28}],
    '3-5-2':   [{p:'GK',x:50,y:90},{p:'CB',x:70,y:76},{p:'CB',x:50,y:78},{p:'CB',x:30,y:76},{p:'RM',x:88,y:52},{p:'CM',x:67,y:52},{p:'CDM',x:50,y:55},{p:'CM',x:33,y:52},{p:'LM',x:12,y:52},{p:'ST',x:65,y:22},{p:'ST',x:35,y:22}],
    '3-4-1-2': [{p:'GK',x:50,y:90},{p:'CB',x:70,y:76},{p:'CB',x:50,y:78},{p:'CB',x:30,y:76},{p:'RM',x:85,y:56},{p:'CM',x:62,y:56},{p:'CM',x:38,y:56},{p:'LM',x:15,y:56},{p:'CAM',x:50,y:38},{p:'ST',x:65,y:22},{p:'ST',x:35,y:22}],
    // 4 at the back
    '4-3-3':   [{p:'GK',x:50,y:90},{p:'RB',x:82,y:74},{p:'CB',x:63,y:76},{p:'CB',x:37,y:76},{p:'LB',x:18,y:74},{p:'CM',x:73,y:52},{p:'CDM',x:50,y:55},{p:'CM',x:27,y:52},{p:'RW',x:82,y:28},{p:'ST',x:50,y:20},{p:'LW',x:18,y:28}],
    '4-2-3-1': [{p:'GK',x:50,y:90},{p:'RB',x:82,y:74},{p:'CB',x:63,y:76},{p:'CB',x:37,y:76},{p:'LB',x:18,y:74},{p:'CDM',x:63,y:58},{p:'CDM',x:37,y:58},{p:'RW',x:80,y:38},{p:'CAM',x:50,y:38},{p:'LW',x:20,y:38},{p:'ST',x:50,y:18}],
    '4-4-2':   [{p:'GK',x:50,y:90},{p:'RB',x:82,y:74},{p:'CB',x:63,y:76},{p:'CB',x:37,y:76},{p:'LB',x:18,y:74},{p:'RM',x:82,y:52},{p:'CM',x:63,y:52},{p:'CM',x:37,y:52},{p:'LM',x:18,y:52},{p:'ST',x:65,y:22},{p:'ST',x:35,y:22}],
    '4-1-2-1-2':[{p:'GK',x:50,y:90},{p:'RB',x:82,y:74},{p:'CB',x:63,y:76},{p:'CB',x:37,y:76},{p:'LB',x:18,y:74},{p:'CDM',x:50,y:60},{p:'CM',x:70,y:46},{p:'CM',x:30,y:46},{p:'CAM',x:50,y:34},{p:'ST',x:65,y:20},{p:'ST',x:35,y:20}],
    '4-3-2-1': [{p:'GK',x:50,y:90},{p:'RB',x:82,y:74},{p:'CB',x:63,y:76},{p:'CB',x:37,y:76},{p:'LB',x:18,y:74},{p:'CM',x:70,y:55},{p:'CDM',x:50,y:58},{p:'CM',x:30,y:55},{p:'RW',x:72,y:35},{p:'LW',x:28,y:35},{p:'ST',x:50,y:20}],
    '4-5-1':   [{p:'GK',x:50,y:90},{p:'RB',x:82,y:74},{p:'CB',x:63,y:76},{p:'CB',x:37,y:76},{p:'LB',x:18,y:74},{p:'RM',x:82,y:52},{p:'CM',x:66,y:52},{p:'CM',x:50,y:52},{p:'CM',x:34,y:52},{p:'LM',x:18,y:52},{p:'ST',x:50,y:20}],
    '4-4-1-1': [{p:'GK',x:50,y:90},{p:'RB',x:82,y:74},{p:'CB',x:63,y:76},{p:'CB',x:37,y:76},{p:'LB',x:18,y:74},{p:'RM',x:82,y:52},{p:'CM',x:63,y:52},{p:'CM',x:37,y:52},{p:'LM',x:18,y:52},{p:'CAM',x:50,y:34},{p:'ST',x:50,y:20}],
    '4-1-4-1': [{p:'GK',x:50,y:90},{p:'RB',x:82,y:74},{p:'CB',x:63,y:76},{p:'CB',x:37,y:76},{p:'LB',x:18,y:74},{p:'CDM',x:50,y:60},{p:'RM',x:82,y:44},{p:'CM',x:63,y:44},{p:'CM',x:37,y:44},{p:'LM',x:18,y:44},{p:'ST',x:50,y:20}],
    // 5 at the back
    '5-3-2':   [{p:'GK',x:50,y:90},{p:'RB',x:88,y:74},{p:'CB',x:70,y:76},{p:'CB',x:50,y:78},{p:'CB',x:30,y:76},{p:'LB',x:12,y:74},{p:'CM',x:68,y:52},{p:'CDM',x:50,y:55},{p:'CM',x:32,y:52},{p:'ST',x:65,y:22},{p:'ST',x:35,y:22}],
    '5-4-1':   [{p:'GK',x:50,y:90},{p:'RB',x:88,y:74},{p:'CB',x:70,y:76},{p:'CB',x:50,y:78},{p:'CB',x:30,y:76},{p:'LB',x:12,y:74},{p:'RM',x:82,y:52},{p:'CM',x:63,y:52},{p:'CM',x:37,y:52},{p:'LM',x:18,y:52},{p:'ST',x:50,y:20}],
    '5-2-3':   [{p:'GK',x:50,y:90},{p:'RB',x:88,y:74},{p:'CB',x:70,y:76},{p:'CB',x:50,y:78},{p:'CB',x:30,y:76},{p:'LB',x:12,y:74},{p:'CM',x:63,y:52},{p:'CM',x:37,y:52},{p:'RW',x:80,y:28},{p:'ST',x:50,y:20},{p:'LW',x:20,y:28}],
  };

  const slots = SLOT_LAYOUT[currentFormation] ?? SLOT_LAYOUT['4-3-3'];

  // Build assignment: for each slot, find best available player
  const posMap = { GK:['GK'], RB:['RB'], LB:['LB'], CB:['CB'], RM:['RM','CM'], LM:['LM','CM'], CDM:['CDM','CM'], CM:['CM','CDM','CAM'], CAM:['CAM','CM'], RW:['RW','CAM','LW'], LW:['LW','CAM','RW'], ST:['ST','CF','LW','RW'] };
  const avail  = players.filter(p => !p.injured && !p.suspended).sort((a,b) => primaryRating(b)-primaryRating(a));
  const assignment = new Array(11).fill(null);
  const usedIds    = new Set();

  // If there's a saved lineup, use those players in order
  if (savedLineup.length === 11) {
    savedLineup.forEach((pid, i) => {
      const pl = players.find(p => p.id === pid);
      if (pl) { assignment[i] = pl; usedIds.add(pl.id); }
    });
  } else {
    // Auto-assign
    slots.forEach((slot, i) => {
      const acceptable = posMap[slot.p] ?? [slot.p];
      const cand = avail.find(p => !usedIds.has(p.id) && acceptable.includes(p.position));
      if (cand) { assignment[i] = cand; usedIds.add(cand.id); }
    });
    // Fill any remaining with best available
    slots.forEach((slot, i) => {
      if (assignment[i]) return;
      const cand = avail.find(p => !usedIds.has(p.id) && p.position !== 'GK');
      if (cand) { assignment[i] = cand; usedIds.add(cand.id); }
    });
  }

  const mentalityLabels = { defensive:'🛡️ Defensive', balanced:'⚖️ Balanced', possession:'🎯 Possession', attacking:'⚡ Attacking' };

  // Group formations by back line count
  const formationGroups = [
    { label:'3 at the back', formations: Object.keys(FORMATIONS).filter(f => f.startsWith('3-')) },
    { label:'4 at the back', formations: Object.keys(FORMATIONS).filter(f => f.startsWith('4-')) },
    { label:'5 at the back', formations: Object.keys(FORMATIONS).filter(f => f.startsWith('5-')) },
  ];

  el.innerHTML = `
  <div class="tactics-layout">
    <!-- Controls bar -->
    <div class="tac-controls">
      <div class="tac-dd-half">
        <div class="tac-dd-label">Formation</div>
        <div class="tac-dropdown" id="formation-dd">
          <button class="tac-dd-btn" id="fm-selected-btn">
            <span class="tac-dd-val">${currentFormation}</span>
            <span class="tac-dd-arrow">▾</span>
          </button>
          <div class="tac-dd-list" id="fm-dd-list">
            ${formationGroups.map(g => g.formations.length ? `
              <div class="tac-dd-group-hdr">${g.label}</div>
              ${g.formations.map(f => `
                <button class="tac-dd-option ${f===currentFormation?'tac-dd-active':''}" data-fm="${f}">
                  <span class="tac-dd-opt-name">${f}</span>
                  ${f===currentFormation ? '<span class="tac-dd-check">✓</span>' : ''}
                </button>`).join('')}` : '').join('')}
          </div>
        </div>
      </div>
      <div class="tac-dd-half">
        <div class="tac-dd-label">Mentality</div>
        <div class="tac-dropdown" id="mentality-dd">
          <button class="tac-dd-btn" id="m-selected-btn">
            <span class="m-pill-icon">${curMentObj.icon}</span>
            <span class="tac-dd-val">${curMentObj.fullLabel}</span>
            <span class="tac-dd-arrow">▾</span>
          </button>
          <div class="tac-dd-list" id="m-dd-list">
            ${MENTALITIES.filter(m => m.id !== currentMentality).map(m => `
              <button class="tac-dd-option" data-mentality="${m.id}">
                <span class="m-pill-icon">${m.icon}</span>
                <span class="m-dd-opt-info">
                  <span class="m-dd-opt-label">${m.fullLabel}</span>
                  <span class="m-dd-opt-desc">${m.desc}</span>
                </span>
              </button>`).join('')}
          </div>
        </div>
      </div>
    </div>

    <!-- Full-screen pitch -->
    <div class="tac-pitch-area">
      <div class="pitch-wrap">
        <div class="pitch-bg" id="tac-pitch">
          <div class="pitch-line half"></div>
          <div class="pitch-circle"></div>
          <div class="pitch-box top"></div>
          <div class="pitch-box bot"></div>
          <div class="pitch-six top"></div>
          <div class="pitch-six bot"></div>
          <div class="pitch-arc top"></div>
          <div class="pitch-arc bot"></div>
          <div class="pitch-spot top"></div>
          <div class="pitch-spot bot"></div>
          <div class="pitch-spot mid"></div>
          ${slots.map((slot, i) => {
            const pl = assignment[i];
            const g  = pl ? posGroup(pl.position) : posGroup(slot.p);
            const r  = pl ? primaryRating(pl) : '';
            return `<div class="pitch-slot" style="left:${slot.x}%;top:${slot.y}%" data-slot="${i}">
              <div class="slot-outer">
                <div class="slot-inner ${pl ? `pos-${g}` : 'pos-empty'}" title="${pl?.name ?? slot.p}">
                  ${pl
                    ? `<div class="slot-rating">${r}</div><div class="slot-pos">${pl.position}</div>`
                    : `<div class="slot-pos slot-empty-lbl">${slot.p}</div>`
                  }
                </div>
                ${pl ? `<div class="slot-name">${pl.name.split(' ').slice(-1)[0]}</div>` : ''}
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>
  </div>`;

  // ── Generic dropdown wiring helper ─────────────────────
  function wireDropdown(btnId, listId, onSelect) {
    const btn = el.querySelector('#' + btnId);
    const list = el.querySelector('#' + listId);
    if (!btn || !list) return;
    btn.onclick = (e) => {
      e.stopPropagation();
      // Close any other open dropdown first
      el.querySelectorAll('.tac-dd-list.open').forEach(l => { if (l !== list) l.classList.remove('open'); });
      const isOpen = list.classList.contains('open');
      list.classList.toggle('open');
      if (!isOpen) {
        const closeDD = () => { list.classList.remove('open'); document.removeEventListener('click', closeDD); };
        setTimeout(() => document.addEventListener('click', closeDD), 0);
      }
    };
    list.querySelectorAll('.tac-dd-option').forEach(opt => {
      opt.onclick = async (e) => {
        e.stopPropagation();
        list.classList.remove('open');
        await onSelect(opt);
      };
    });
  }

  // ── Formation dropdown ────────────────────────────────────
  wireDropdown('fm-selected-btn', 'fm-dd-list', async (opt) => {
    const sv = await getSave();
    await putSave({ ...sv, formation: opt.dataset.fm, lineup: null });
    await renderTactics();
  });

  // ── Mentality dropdown ─────────────────────────────────
  wireDropdown('m-selected-btn', 'm-dd-list', async (opt) => {
    const sv = await getSave();
    await putSave({ ...sv, mentality: opt.dataset.mentality });
    toast(`Mentality: ${mentalityLabels[opt.dataset.mentality] ?? opt.dataset.mentality}`, 'info', 2000);
    await renderTactics();
  });

  // ── Click a pitch slot → open swap bottom sheet ───────────
  el.querySelectorAll('.pitch-slot').forEach(slot => {
    slot.onclick = () => {
      const idx = parseInt(slot.dataset.slot);
      const cur = assignment[idx];
      openSwapPicker(idx, cur, players, assignment, slots, currentFormation, save);
    };
  });
}

function openSwapPicker(slotIdx, currentPlayer, players, assignment, slots, formation, save, preSelected) {
  // Remove any existing swap sheet
  document.querySelector('.swap-backdrop')?.remove();
  document.querySelector('.swap-sheet')?.remove();

  const slot     = slots[slotIdx];
  const posMap   = { GK:['GK'], RB:['RB','LB'], LB:['LB','RB'], CB:['CB'], RM:['RM','CM','CAM'], LM:['LM','CM','CAM'], CDM:['CDM','CM'], CM:['CM','CDM','CAM'], CAM:['CAM','CM','RW','LW'], RW:['RW','CAM','LW'], LW:['LW','CAM','RW'], ST:['ST','CF','LW','RW','CAM'] };
  const naturalPositions = posMap[slot.p] ?? [slot.p];

  // Score each candidate by how good a fit they are
  const candidates = players.filter(p => !p.injured && !p.suspended);

  // Categorise players into groups for clarity
  const naturalFit = [];   // Position matches the slot
  const versatile  = [];   // Same position group (DEF/MID/ATT)
  const outOfPos   = [];   // Different group entirely

  const slotGroup = posGroup(slot.p);

  candidates.forEach(p => {
    const isCurrent = currentPlayer?.id === p.id;
    const isInXI    = assignment.some((ap, i) => ap?.id === p.id && i !== slotIdx);
    const pGroup    = posGroup(p.position);
    const isNatural = naturalPositions.includes(p.position);

    const entry = { player: p, isCurrent, isInXI, isNatural, group: pGroup };

    if (isCurrent) {
      // Current player shown separately in the header
    } else if (isNatural) {
      naturalFit.push(entry);
    } else if (pGroup === slotGroup || (slotGroup === 'MID' && pGroup === 'ATT') || (slotGroup === 'ATT' && pGroup === 'MID')) {
      versatile.push(entry);
    } else {
      outOfPos.push(entry);
    }
  });

  // Sort each group: non-XI first (bench options), then by rating
  const sortGroup = arr => arr.sort((a, b) => {
    if (a.isInXI !== b.isInXI) return a.isInXI ? 1 : -1;
    return primaryRating(b.player) - primaryRating(a.player);
  });
  sortGroup(naturalFit);
  sortGroup(versatile);
  sortGroup(outOfPos);

  const buildRow = (entry) => {
    const p = entry.player;
    const g = posGroup(p.position);
    const r = primaryRating(p);
    const fit = Math.round(p.fitness ?? 90);
    const fitCol = fit >= 75 ? 'var(--tx2)' : fit >= 50 ? 'var(--acc2)' : 'var(--acc3)';
    const ratingColor = entry.isNatural ? 'var(--acc)' : 'var(--tx2)';

    return `<div class="swap-row ${entry.isInXI ? 'dimmed' : ''} ${entry.isNatural ? 'natural' : ''} ${preSelected?.id===p.id?'swap-presel':''}" data-pid="${p.id}">
      <div class="swap-row-pos" style="background:var(--sur2);border:1px solid var(--bdr);color:var(--tx)">${p.position}</div>
      <div class="swap-row-info">
        <div class="swap-row-name">${p.name}</div>
        <div class="swap-row-meta">
          <span>Age ${p.age}</span>
          ${p.goals > 0 ? `<span>⚽${p.goals}</span>` : ''}
          ${p.assists > 0 ? `<span>🎯${p.assists}</span>` : ''}
        </div>
      </div>
      ${entry.isInXI ? '<span class="swap-row-badge xi">IN XI</span>' : ''}
      <span class="swap-row-fit" style="color:${fitCol}">${fit}%</span>
      <span class="swap-row-rat" style="color:${ratingColor}">${r}</span>
    </div>`;
  };

  // Build sections HTML
  let sectionsHTML = '';
  if (naturalFit.length) {
    sectionsHTML += `<div class="swap-section-hdr">Best fit for ${slot.p}</div>`;
    sectionsHTML += naturalFit.map(buildRow).join('');
  }
  if (versatile.length) {
    sectionsHTML += `<div class="swap-section-hdr">Can play here</div>`;
    sectionsHTML += versatile.map(buildRow).join('');
  }
  if (outOfPos.length) {
    sectionsHTML += `<div class="swap-section-hdr">Out of position</div>`;
    sectionsHTML += outOfPos.map(buildRow).join('');
  }

  // Current player info
  const curG = currentPlayer ? posGroup(currentPlayer.position) : '';
  const curR = currentPlayer ? primaryRating(currentPlayer) : '';
  const curFit = currentPlayer ? Math.round(currentPlayer.fitness ?? 90) : 0;

  // Create backdrop
  const backdrop = document.createElement('div');
  backdrop.className = 'swap-backdrop';
  document.body.appendChild(backdrop);

  // Create sheet
  const sheet = document.createElement('div');
  sheet.className = 'swap-sheet';
  sheet.innerHTML = `
    <div class="swap-sheet-handle"></div>
    <div class="swap-sheet-hdr">
      <span class="swap-sheet-title">${slot.p} Slot</span>
      <div class="swap-sheet-close">✕</div>
    </div>
    ${currentPlayer ? `
    <div class="swap-sheet-current">
      <div class="swap-row-pos" style="background:var(--sur2);border:1px solid var(--bdr);color:var(--tx);font-size:10px;font-weight:700;width:32px;height:24px;border-radius:4px;display:flex;align-items:center;justify-content:center">${currentPlayer.position}</div>
      <div class="swap-current-info">
        <div class="swap-current-name">${currentPlayer.name}</div>
        <div class="swap-current-meta">Current · Rating ${curR} · Fitness ${curFit}%</div>
      </div>
    </div>` : ''}
    <div class="swap-list">
      ${sectionsHTML}
    </div>`;
  document.body.appendChild(sheet);

  // Animate in
  requestAnimationFrame(() => {
    backdrop.classList.add('open');
    sheet.classList.add('open');
  });

  const close = () => {
    sheet.classList.remove('open');
    backdrop.classList.remove('open');
    backdrop.addEventListener('transitionend', () => backdrop.remove(), { once: true });
    sheet.addEventListener('transitionend', () => sheet.remove(), { once: true });
  };

  backdrop.onclick = close;
  sheet.querySelector('.swap-sheet-close').onclick = close;

  // Wire swap rows
  sheet.querySelectorAll('.swap-row').forEach(row => {
    row.onclick = async () => {
      const allCandidates = [...naturalFit, ...versatile, ...outOfPos];
      const entry = allCandidates.find(e => e.player.id === row.dataset.pid);
      if (!entry) return;
      const newPlayer = entry.player;

      close();

      // If new player is in another slot, swap them
      const otherSlotIdx = assignment.findIndex((ap, i) => ap?.id === newPlayer.id && i !== slotIdx);
      const newAssignment = [...assignment];
      newAssignment[slotIdx] = newPlayer;
      if (otherSlotIdx >= 0) newAssignment[otherSlotIdx] = currentPlayer ?? null;

      const sv = await getSave();
      const lineup = newAssignment.filter(Boolean).map(p => p.id);
      await putSave({ ...sv, lineup, formation });
      toast(`${newPlayer.name} → ${slot.p} slot`, 'success', 2000);
      await renderTactics();
    };
  });
}

// ══════════════════════════════════════════════════════════════
// TRANSFER OFFERS — shown via modal from Transfers screen
// ══════════════════════════════════════════════════════════════
async function showOffersModal() {
  const save    = await getSave();
  const players = await getPlayersByTeam(save.userTeamId);

  const offers  = (save.inboundOffers ?? []).filter(o => o.status === 'pending');
  const byId    = new Map(players.map(p => [p.id, p]));
  const listed  = players.filter(p => p.transferListed);

  const bodyHTML = `
    <div style="display:grid;grid-template-columns:1fr;gap:14px;max-height:70vh;overflow-y:auto;padding:4px">

      <div>
        <div style="font-family:var(--fd);font-size:16px;letter-spacing:1px;margin-bottom:14px">
          Inbound Offers <span style="font-size:13px;color:var(--tx2);font-family:var(--fb)">(${offers.length})</span>
        </div>
        ${offers.length ? offers.map(offer => {
          const pl = byId.get(offer.playerId);
          if (!pl) return '';
          const fav      = formAdjustedValue(pl);
          const pct      = Math.round((offer.fee / fav) * 100);
          const g        = posGroup(pl.position);
          const fl       = formLabel(pl);
          const isListed = pl.transferListed === true;
          return `<div class="offer-card-v2" data-offer-pid="${pl.id}">
            <div class="offer-card-top">
              <div class="offer-player-info">
                <div class="pl-av">${flagEmoji(pl.name)}</div>
                <div>
                  <div style="font-weight:600;font-size:14px">${pl.name} ${isListed ? '<span class="listed-badge">LISTED</span>' : ''}</div>
                  <div style="font-size:11px;color:var(--tx2);display:flex;gap:6px;margin-top:2px;flex-wrap:wrap">
                    <span class="pos ${g}">${pl.position}</span>
                    <span>Age ${pl.age}</span>
                    <span class="fb ${fl.cls}">${fl.text}</span>
                    ${!isListed ? `<span style="color:var(--acc2);font-size:10px">⚠ Unsolicited bid</span>` : ''}
                  </div>
                </div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:10px;color:var(--tx2)">From</div>
                <div style="font-weight:700;font-size:14px">${offer.clubName}</div>
              </div>
            </div>
            <div class="offer-amounts">
              <div class="offer-amt-box" style="border-color:${pct>=100?'rgba(18,168,100,.4)':'rgba(232,72,85,.4)'}">
                <div class="offer-amt-lbl">Their Offer</div>
                <div class="offer-amt-val" style="color:${pct>=100?'var(--acc)':'var(--acc3)'}">${fmt.money(offer.fee)}</div>
                <div class="offer-amt-sub">${pct}% of form value</div>
              </div>
              <div class="offer-amt-box">
                <div class="offer-amt-lbl">Form Value</div>
                <div class="offer-amt-val">${fmt.money(fav)}</div>
                <div class="offer-amt-sub">Base: ${fmt.money(pl.value)}</div>
              </div>
              <div class="offer-amt-box">
                <div class="offer-amt-lbl">Min. Accept</div>
                <div class="offer-amt-val" style="color:var(--tx2)">${fmt.money(Math.round(fav * (isListed ? 0.88 : 1.05)))}</div>
                <div class="offer-amt-sub">${isListed ? 'Listed player' : 'Unlisted premium'}</div>
              </div>
            </div>
            <div class="offer-btns">
              <button class="btn btn-p" data-offer-accept="${pl.id}">✅ Accept ${fmt.money(offer.fee)}</button>
              <button class="btn btn-s" data-offer-counter="${pl.id}" data-offer-ask="${Math.round(fav * (isListed ? 1.0 : 1.1))}">
                💬 Counter ${fmt.money(Math.round(fav * (isListed ? 1.0 : 1.1)))}
              </button>
              <button class="btn btn-d" data-offer-reject="${pl.id}">✕ Reject</button>
            </div>
          </div>`;
        }).join('') : `<div style="background:var(--sur);border:1px solid var(--bdr);border-radius:14px;padding:40px;text-align:center">
          <div style="font-size:36px;margin-bottom:10px">📭</div>
          <div style="font-family:var(--fd);font-size:20px;letter-spacing:1px;margin-bottom:6px">No Pending Offers</div>
          <div style="font-size:12px;color:var(--tx2)">AI clubs bid each gameweek. List players to attract more offers.</div>
        </div>`}
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div style="background:var(--sur);border:1px solid var(--bdr);border-radius:14px;padding:16px">
          <div style="font-family:var(--fd);font-size:14px;letter-spacing:1px;margin-bottom:4px">Transfer Listed</div>
          <div style="font-size:11px;color:var(--tx2);margin-bottom:12px">${listed.length} player${listed.length!==1?'s':''} available</div>
          ${listed.length ? listed.map(p => {
            const g = posGroup(p.position);
            return `<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--bdr)">
              <span class="pos ${g}">${p.position}</span>
              <span style="flex:1;font-size:12px;font-weight:500">${p.name}</span>
              <span style="font-family:var(--fm);font-size:11px;color:var(--acc2)">${fmt.money(formAdjustedValue(p))}</span>
            </div>`;
          }).join('') : `<div style="font-size:12px;color:var(--txd)">No players listed. Go to Squad to list players.</div>`}
        </div>
        <div style="background:var(--sur);border:1px solid var(--bdr);border-radius:14px;padding:16px">
          <div style="font-family:var(--fd);font-size:14px;letter-spacing:1px;margin-bottom:8px;color:var(--acc2)">ℹ Offer Rules</div>
          <div style="font-size:11px;color:var(--tx2);line-height:1.7">
            <div>• <strong>Listed players:</strong> AI offers from 85% of form value</div>
            <div>• <strong>Unlisted players:</strong> AI must offer 110%+ to tempt you</div>
            <div>• <strong>Form boost:</strong> goals/assists increase asking price</div>
            <div>• Offers arrive each gameweek automatically</div>
          </div>
        </div>
      </div>

    </div>`;

  const modal = showModal('📨 Transfer Inbox', bodyHTML, [], { wide: true });

  // ── Button handlers inside modal ────────────────────────
  const bd = document.getElementById('modal-bd');
  if (!bd) return;

  bd.querySelectorAll('[data-offer-accept]').forEach(btn => {
    btn.onclick = async () => {
      try {
        btn.closest('.offer-card-v2')?.remove();
        const { fee, buyerName } = await acceptOffer(btn.dataset.offerAccept);
        toast(`✅ Sold for ${fmt.money(fee)} to ${buyerName}!`, 'success', 5000);
        _updateOffersBadge();
        modal.close();
        await renderTransfers();
        await renderHome();
      } catch(e) { toast(`❌ ${e.message}`, 'error', 4000); }
    };
  });
  bd.querySelectorAll('[data-offer-reject]').forEach(btn => {
    btn.onclick = async () => {
      btn.closest('.offer-card-v2')?.remove();
      await rejectOffer(btn.dataset.offerReject);
      toast('Offer rejected', 'info', 2000);
      _updateOffersBadge();
      // Check if any offers remain
      const remaining = bd.querySelectorAll('.offer-card-v2');
      if (!remaining.length) {
        modal.close();
        await showOffersModal();
      }
    };
  });
  bd.querySelectorAll('[data-offer-counter]').forEach(btn => {
    btn.onclick = async () => {
      const ask = parseInt(btn.dataset.offerAsk);
      const pid = btn.dataset.offerCounter;
      const result = await counterOffer(pid, ask);
      const card = btn.closest('.offer-card-v2');

      if (result.outcome === 'accepted') {
        // AI accepted — update the card to show accepted fee, let user confirm
        toast(`✅ ${result.clubName} agreed to ${fmt.money(result.fee)}!`, 'success', 4000);
        // Auto-close and reopen the modal to show the updated offer
        modal.close();
        await showOffersModal();
      } else if (result.outcome === 'counter') {
        // AI came back with a revised offer
        toast(`💬 ${result.clubName} counter: ${fmt.money(result.fee)} (was ${fmt.money(result.originalFee)})`, 'info', 5000);
        modal.close();
        await showOffersModal();
      } else {
        // Rejected — they walked away
        if (card) card.remove();
        toast(`❌ ${result.clubName ?? 'Club'} withdrew their interest`, 'error', 4000);
        _updateOffersBadge();
        const remaining = bd.querySelectorAll('.offer-card-v2');
        if (!remaining.length) {
          modal.close();
          await showOffersModal();
        }
      }
    };
  });
}

// Update the badge on the Offers button in the Transfers screen
async function _updateOffersBadge() {
  const save  = await getSave();
  const count = (save.inboundOffers ?? []).filter(o => o.status === 'pending').length;
  const badge = document.getElementById('tt-offers-badge');
  const btn   = document.getElementById('tt-offers');
  if (badge) {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'inline-block' : 'none';
  }
  if (btn) {
    btn.style.borderColor = count > 0 ? 'var(--acc2)' : 'var(--bdr)';
  }
}

// Keep old name as alias so nothing breaks if referenced elsewhere
async function renderOffers() { await showOffersModal(); }

// ══════════════════════════════════════════════════════════════
// UCL SCREEN: override renderCups to show league phase table
// ══════════════════════════════════════════════════════════════
async function renderCups() {
  const save = await getSave();
  const el   = document.getElementById('cups-grid');
  if (!el) return;

  const cups   = save.cups ?? {};
  // Cups that are only shown if the team has actually participated.
  // European cups + invitation-only super cups require real activity.
  // Invitation-only super cups are hidden unless the team has actually played in them.
  // European cups (UCL/UEL/UECL) are shown as soon as the team is enrolled (in save.cups).
  const INVITATION_GATED = new Set(['dfb_supercup','supercopa','supercoppa','trophee_des_champions']);
  const cupIds = Object.keys(cups).filter(cupId => {
    const meta = CUP_META[cupId];
    if (!meta) return false; // unknown cup, skip
    if (!INVITATION_GATED.has(cupId)) return true; // domestic + european cups always shown when enrolled
    const st = cups[cupId];
    if (!st) return false;
    const hasPlayed    = (st.results ?? []).length > 0;
    const hasProgress  = (st.roundIndex ?? 0) > 0;
    const hasMatchdays = (st.leaguePhase?.matchday ?? 0) > 0;
    return hasPlayed || hasProgress || hasMatchdays;
  });

  if (!cupIds.length) {
    el.innerHTML = `<div class="no-data" style="grid-column:1/-1;padding:40px">No cup competitions. Start a new game to get cups.</div>`;
    return;
  }

  el.innerHTML = cupIds.map(cupId => {
    const meta  = CUP_META[cupId];
    if (!meta) return '';
    const state = cups[cupId];
    const badgeCls = state.status==='winner'?'won':state.status==='eliminated'?'out':'active';
    const badgeTxt = state.status==='winner'?'WON 🏆':state.status==='eliminated'?'OUT':'ACTIVE';

    let progressSection = '';
    let resultsSection  = '';

    // UCL league phase display
    if (cupId === 'ucl' && meta.isGroupStage && !state.leaguePhaseComplete) {
      const lp  = state.leaguePhase ?? {};
      const md  = lp.matchday ?? 0;
      const pts = lp.points  ?? 0;
      progressSection = `
        <div style="margin-bottom:8px">
          <div style="font-size:10px;color:var(--tx2);font-family:var(--fm);letter-spacing:1px;margin-bottom:4px">LEAGUE PHASE</div>
          <div style="display:flex;justify-content:space-between;font-size:13px">
            <span>MD ${md}/8</span>
            <span style="font-family:var(--fm);color:var(--acc2)"><strong>${pts}</strong> pts</span>
            <span style="color:var(--tx2);font-size:11px">GD: ${lp.gd >= 0 ? '+' : ''}${lp.gd ?? 0}</span>
          </div>
          <div class="cup-pw" style="margin-top:6px"><div class="cup-pb" style="width:${(md/8)*100}%;background:${meta.color}"></div></div>
          <div style="font-size:10px;color:var(--tx2);margin-top:4px">
            ${pts >= 12 ? '✅ On course to qualify directly' : pts >= 8 ? '🔶 Likely playoff spot' : md < 4 ? 'Season underway' : '⚠ Need points to qualify'}
          </div>
        </div>`;
    } else {
      const roundIdx  = state.roundIndex ?? 0;
      const roundName = state.status === 'winner' ? 'Trophy Won!' : state.status === 'eliminated' ? `Out (${meta.rounds[Math.max(0,roundIdx-1)]??'Early'})` : (meta.rounds[roundIdx] ?? 'Final');
      const progress  = Math.round((roundIdx / meta.rounds.length) * 100);
      progressSection = `
        <div class="cup-pw"><div class="cup-pb" style="width:${progress}%;background:${meta.color}"></div></div>
        <div class="cup-round">📍 ${roundName}</div>`;
    }

    const results = state.results ?? [];
    if (results.length) {
      resultsSection = `<div class="cup-results">
        ${results.slice(-4).map(r => {
          const isUCLMD = r.isUCLMatchday;
          const won = isUCLMD ? r.result === 'W' : r.userWon;
          const lbl = isUCLMD ? `MD${r.matchday}: ${r.result} vs ${r.opponentName} (${r.userGoals}-${r.oppGoals}) [${r.points} pts]`
                               : `${r.roundName}: ${won ? '✅' : '❌'} vs ${r.opponentName} (${r.userGoals}-${r.oppGoals})`;
          return `<div class="cup-res-row ${won?'won':'lost'}">${lbl}</div>`;
        }).join('')}
      </div>`;
    }

    return `<div class="cup-card cup-${cupId}">
      <div class="cup-bdg ${badgeCls}">${badgeTxt}</div>
      <div class="cup-icon">${meta.icon}</div>
      <div class="cup-name">${meta.name}</div>
      <div class="cup-desc">${meta.description}</div>
      ${progressSection}
      ${resultsSection}
    </div>`;
  }).join('');
}
