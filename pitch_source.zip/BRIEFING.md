# PITCH v3.5 — AI Agent Briefing

> Paste as first message in every new session.

## Commands
| Action | Command |
|--------|---------|
| Build | `python3 /home/claude/pitch2/build.py` |
| Validate | `node /home/claude/pitch2/validate.js` (1180 checks, **0 failures**) |
| Output | `/mnt/user-data/outputs/index.html` (~733KB) |
| Intermediate | `/tmp/bundle_final.js` |

### Build & Delivery Rules
1. `build.py` writes the final HTML directly to `/mnt/user-data/outputs/index.html`. **Never** `cp` a local `index.html` over the output — the zip may contain a stale copy from extraction that lacks all session fixes.
2. Delete any local `/home/claude/pitch2/index.html` at the start of every session (`rm -f /home/claude/pitch2/index.html`) so it cannot accidentally overwrite the build output.
3. After `build.py` completes, verify fixes are present in `/mnt/user-data/outputs/index.html` (not just in `/tmp/bundle_final.js`) before delivering.
4. The source zip must exclude `index.html`: `zip -r ... -x "index.html"`.

**❌** `cp index.html /mnt/user-data/outputs/` · trusting bundle contents without checking final HTML · shipping a stale extracted `index.html`

## Project
Single-file football career manager. Vanilla JS + IndexedDB + CSS. No framework. `build.py` concatenates 22 source files in strict order, strips ES modules, emits one HTML file.

## Source Map
```
/home/claude/pitch2/
├── build.py               # Bundle → validate → assemble
├── csv_to_league.py       # CSV→JS converter ★
├── validate.js            # 1190 checks / 21 sections + 11 regression suites
├── shell.html             # HTML/CSS only (73KB)
├── data/
│   ├── plTeams.js         # 20 PL clubs, 2025/26 squads ★ AUTO-GENERATED
│   ├── extraLeagues.js    # La Liga, Bundesliga, Serie A, Ligue 1 (77KB)
│   ├── championship.js    # 24 clubs ★ AUTO-GENERATED
│   ├── leagueOne.js       # 24 clubs ★ AUTO-GENERATED
│   ├── leagueTwo.js       # 24 clubs ★ AUTO-GENERATED
│   ├── eredivisie.js      # 18 clubs ★ AUTO-GENERATED
│   └── csv/               # Source CSVs ★
├── modules/               # Game logic (no DOM)
│   ├── db.js              # IndexedDB: openDB, bulkPut, clearAndBulkPut, deleteDB
│   ├── matchEngine.js     # Simulation core ★
│   ├── standings.js       # sortTable, applyResult, recomputePositions
│   ├── fixtures.js        # generateLeagueFixtures (circle-method + H/A opt.)
│   ├── cups.js            # CUP_META, LEAGUE_DOMESTIC_CUPS, INVITATION_ONLY_CUPS ★
│   ├── transfers.js       # buyPlayer, sellPlayer, generateAIOffers, formAdjustedValue
│   ├── potential.js       # assignPotentials, applyDevelopment, getPotentialStars
│   ├── promotion.js       # getEuropeanQualifiers, processLeagueChanges, runPlayoffs ★
│   ├── youthAcademy.js    # generateCohort, runYouthIntake, promoteYouthPlayer
│   ├── save.js            # startNewGame ★
│   ├── season.js          # processEndOfSeason, calculatePrizeMoney, reputationBudget ★
│   └── gameweek.js        # buildPendingEvents, advanceOneFixture, getEffectiveTotalGW ★
└── ui/
    ├── helpers.js          # fmt.money/wage/date, toast, showModal, navigateTo
    ├── home_transfers.js   # renderHome, showMatchReport, handleEndOfSeason ★
    ├── renderers.js        # renderCompetitions, renderNewGame, renderHonours, boot ★
    ├── squad_tactics_offers.js  # renderSquad, renderTactics, renderOffers, renderCups ★
    ├── academy.js          # renderAcademy, buildYouthCard, handleYouthAction
    ├── prematch.js         # showPreMatchModal, handleAdvanceOneFixture ★
    └── watchmatch.js       # showWatchMatchModal, live tick, subs, tactics ★
```
★ = changed this session

## Build Order (never reorder — globals)
```
plTeams → extraLeagues → championship → db → matchEngine → standings → fixtures
→ cups → transfers → potential → promotion → youthAcademy → save → season
→ gameweek → helpers → home_transfers → renderers → squad_tactics_offers
→ academy → prematch → watchmatch
```

---

## Critical Invariants

### Event Queue
```js
save.pendingEvents = [{type:'league',fixtureId,gw}, {type:'ucl_md',...}, {type:'cup',...}]
```
- `buildPendingEvents(gw, userTeamId, fixtures, cups, allTeams)` rebuilds each GW
- One button press → pop ONE event → pre-match modal → simulate → result modal
- Cup opponents pre-drawn at queue build time
- GW advances **only when pendingEvents is empty**
- AI fixtures for same GW resolved silently after user's match

**❌** `processCupRounds()` · `finaliseGW()` · silent cup sim inside `advanceOneFixture`

### Lineup Flow
```
Tactics → save.formation (string) + save.lineup ([11 IDs] | null)
  → Pre-match modal (READ-ONLY)
  → Quick Sim: advanceOneFixture() → simulateMatch(..., hLineup, aLineup)
  → Watch Match: _launchWatchMatch() → buildLiveMatchState(..., homeLineup, awayLineup)
```
**❌** Formation picker in pre-match · `showModal()` inside `showModal()`

### Watch Match — Inline Panel Architecture
`#modal-bd` IS the watch match modal. `showModal()` from inside it destroys the live match.

All intervention panels: `_openInlinePanel(title, bodyHtml, onClose)`
- Appends `position:fixed` overlay to `document.body` (z-index 10500 > modal 10000)
- Auto-pauses match, resumes on close

Sub rules: GK↔GK only, outfield↔outfield only (`_applyUserSub`). 3-sub limit.

### Cup System
```
LEAGUE_DOMESTIC_CUPS (knockout, all teams enter):
  PL/Championship/L1/L2 → fa_cup + league_cup
  La Liga → copa_del_rey | Bundesliga → dfb_pokal
  Serie A → coppa_italia | Ligue 1 → coupe_de_france | Eredivisie → knvb_beker

FA Cup — nation-wide draw (any English team can face any other):
  League Two / League One → enter R1 (roundIndex 0, GW 7)
  Championship            → enter R2 (roundIndex 1, GW 13)
  Premier League          → enter R3 (roundIndex 2, GW 20)
  8 rounds: R1·R2·R3·R4·R5·QF·SF·Final
  Prize per round won (2024/25 FA figures):
    R1:£4.5k · R2:£9k · R3:£82.4k · R4:£90k · R5:£180k · QF:£360k · SF:£450k
    Final winner:£2m · Runner-up:£1m

INVITATION_ONLY_CUPS (never assigned blindly):
  dfb_supercup, supercopa, supercoppa, trophee_des_champions

European (by rep): ≥90→UCL · ≥82→UEL · ≥76→UECL · below→none
```
- `renderCups` uses `ACTIVITY_GATED` — hides European/invitation cups unless ≥1 result, non-zero roundIndex, or UCL matchdays played
- `processEndOfSeason` → `buildInitialCupState(newCupIds, userTeamId, userNewLeague)` — **not** `resetCups`
- `buildInitialCupState(cupIds, userTeamId, userLeague)` — 3rd arg required for FA Cup entry round

**❌** Super cups in `LEAGUE_DOMESTIC_CUPS` · `resetCups()` on rollover · European/invitation cups with zero activity · `buildInitialCupState` without `userLeague` · domestic cup opponents from wrong nation

### Match Engine
| Attribute | Drives |
|-----------|--------|
| `attack` | Goals (ST/CF/RW/LW/CAM) |
| `midfield` | Possession, chances, assists |
| `defence` + `goalkeeping` | Resistance (70/30 split) |
| `mentality` | Overall shape |

- 120 phases/game; `midShareBoost` + mentality → phase distribution
- GK weight = 0 in `pickScorer` (can never score)
- Fitness drain: ~0.18/attacking phase, ~0.12/defending (~18 total/game age 24)
- Age drain: 30+→1.10× · 33+→1.20× · 36+→1.35× (`ageDrain()`)
- Recovery: played +20 (30+→−2, 33+→−4, 36+→−6, floor 8); rested→100%
- **Drain rates identical** in `simulateMatch` and `simulateMatchSegment`

### Injury System
- Target: ~20 injuries per team per season (~0.4/match across ~50 games)
- Per-phase rate: outfield 0.000333, GK 0.000120 — **identical** in `simulateMatch` and `simulateMatchSegment`
- Duration skewed short: `Math.min(roll1, roll2)` biases toward `minGW`
- `injuryDurationLabel(gwsLeft)`: exact multiples of 4 weeks → months (e.g. "1 month", "2 months"); everything else → weeks. **All** UI injury displays must call this function — never inline `week${…}` formatting.
- `processInjuryRecovery()`: must **always** `putPlayersBulk` when any player was injured, not just when someone fully recovers — otherwise GW decrements are lost and injuries never end.
- `updateCache()`: must read **fresh** from DB via `getAllPlayers()`, never use the stale `allPlayers` ref from the top of `advanceOneFixture` — otherwise recovered players get re-injured.
- `startNewGame()`: must auto-generate `save.lineup` via `selectEleven()` before `putSave()` — null lineup blocks pre-match modal.

**❌** Inline `week${…}` in UI · `processInjuryRecovery` saving only on recovery · `updateCache` using stale player data · `startNewGame` with `lineup: null`

### Aging, Decline & Retirement
`processEndOfSeason`:
1. `applyAgingDecline(player)` — decay past `peakAge+1`:
   - Chance: 15%(1yr) · 30%(2-3yr) · 50%(4-5yr) · 70%(6-7yr) · 85%(8+yr)
   - Primary −1–3/yr; secondary half rate; floors 30/20
2. `agingValueAdjust(player)`: <28 appreciates · 28-29:0.97× · 30-31:0.92× · 32-33:0.85× · 34-35:0.75× · 36+:0.60× · floor £500K
3. Retirement: 36+ deleted at season end (15% reprieve if rating ≥80; 8% if ≥75)

Live match API:
```js
buildLiveMatchState() → liveState
simulateMatchSegment(home, away, liveState, startPhase, endPhase) → {segEvents, updatedState}
finaliseLiveMatch(home, away, liveState, allEvents) → standard result shape
```

---

## Mentality System
```js
save.mentality = 'defensive'|'balanced'|'possession'|'attacking'
```
`getMentalityMods(mentality)` → `{ goalProbMult, defResistMult, midShareBoost, phasesBoostOpp, shotsMultSelf, shotsMultOpp }`

| Mentality | goalProbMult | defResistMult | midShareBoost | shotsMultSelf |
|-----------|-------------|---------------|---------------|---------------|
| defensive | 0.72 | 1.30 | −0.07 | 0.80 |
| balanced  | 1.00 | 1.00 |  0.00 | 1.00 |
| possession| 0.88 | 1.08 | +0.09 | 0.90 |
| attacking | 1.32 | 0.78 | +0.06 | 1.20 |

Wiring — mentality through every path:
- `simulateMatch` — params 9+10: `homeMentality`, `awayMentality`
- `buildLiveMatchState` — same; stores `hMods`/`aMods` in `liveState`
- `simulateMatchSegment` — reads `hMods`/`aMods` from `liveState`
- `finaliseLiveMatch` — passes mods into `computeMatchStats`
- `simulateCupRound` — reads `event.userMentality`
- `simulateUCLMatchday` — 4th param `userMentality`
- `gameweek.js` — injects `save.mentality` at all call sites

**❌** `simulateMatch`/`buildLiveMatchState` without mentality · mentality logic outside `getMentalityMods`

---

## Data Schemas

### Player
```js
{ id, name, position, age, attack, midfield, defence, goalkeeping,
  value, wage, teamId, fitness, potentialRating, growthPoints, peakAge,
  goals, assists, cleanSheets, form, injured, suspended, inSquad, transferListed,
  isYouth, isWonderkid, youthTeamId, season }
```

### Save State
```js
{ userTeamId, userLeague, currentGameweek, totalGameweeks, currentDate, season,
  formation,  // string '4-3-3'
  mentality,  // 'defensive'|'balanced'|'possession'|'attacking'
  lineup,     // [11 player IDs] | null
  cups, pendingEvents, inboundOffers, youthCohort }
```

### liveState (Watch Match)
```js
{ hActive, aActive, hBenchLeft, aBenchLeft, hFitness(Map), aFitness(Map),
  hSubsLeft, aSubsLeft, hGoals, aGoals, hPhases, aPhases,
  hStr, aStr, hMidShare, homeFormation, awayFormation, hElev, aElev, hBench, aBench }
```

---

## Cup & League Schedule

| Competition | Entry | Round GWs |
|-------------|-------|-----------|
| FA Cup | All English | 20,24,27,30,33,37 |
| League Cup | PL+Champ | 3,6,12,17,20,30 |
| Copa del Rey | La Liga | 8,14,22,28,32,37 |
| DFB-Pokal | Bundesliga | 3,8,16,24,30,37 |
| Coppa Italia | Serie A | 5,12,22,27,31,37 |
| Coupe de France | Ligue 1 | 5,10,16,22,27,33,37 |
| KNVB Beker | Eredivisie | 6,14,22,30,37 |
| DFL-Supercup | Invitation | 2 |
| Supercopa | Invitation | 4,5 |
| Supercoppa | Invitation | 3 |
| Trophée des Champions | Invitation | 2 |
| UCL League Phase | rep≥90 | 5,7,9,11,13,15,17,19 |
| UCL Knockouts | ≥7pts | 26,30,34,**40** |
| UEL | rep≥82 | 6,23,27,31,35,**39** |
| UECL | rep≥76 | 6,27,31,35,**40** |

European finals post-season (GW 39–40). `getEffectiveTotalGW(save)` extends season when user is active in Europe.

**PL zones:** Top 4→UCL · 5–6→UEL · 7→UECL · 18–20→Relegated

---

## Promotion, Relegation & Playoffs

`processLeagueChanges()` in `promotion.js`:

| Tier | Auto Up | Playoffs | Relegated |
|------|---------|----------|-----------|
| Premier League | — | — | Bottom 3→Championship |
| Championship | Top 2→PL | 3–6→PL | Bottom 3→L1 |
| League One | Top 2→Champ | 3–6→Champ | Bottom 3→L2 |
| League Two | Top 2→L1 | 3–6→L1 | None |

`runPlayoffs`: 3v6 + 4v5 semis (2-leg, higher seed hosts 2nd leg) → neutral final. Tiebreak: aggregate → away goals → pens (50/50).

Reputation on movement:
| Destination | Champions (1st) | Runner-up / Playoff | Relegated | Max/Min |
|-------------|-----------------|---------------------|-----------|---------|
| PL | +10 | +5 | −10 | 85/60 |
| Championship | +10 | +5 | −10 | 74/50 |
| League One | +10 | +5 | −10 | 64/42 |
| League Two | +10 | +5 | −10 | 56/35 |

**❌** Auto-promote 3 teams · playoffs for non-English leagues · skip `runPlayoffs` for Champ/L1/L2

---

## Transfer Market

**Filter bar (`_trFilters`):** Sort · League · Age · Rating · Max Price · Min Potential · Affordable · Reset · Count badge. `_applyAndRenderBuyList(byId, team)` re-runs on every change.

### `formAdjustedValue(player)`
1. Form multiplier (dampened): hot form → up to +50%; dampened at high values: `1-(base/80M)*0.4`
2. Youth/potential premium: ≤23 with 10+ headroom → up to +80% in form; ≤26 with 5+ headroom → up to +25%
3. Age discount: 29-30:0.95× · 31-32:0.90× · 33+:0.80×
4. Floor: £500K

**Buying (rejected):** `generateBuyCounter()` → slider from original offer to 130% asking. Budget cap on slider max.
**Selling (AI bids):** slider from AI offer to 2× form value (step £500K). Likelihood hints at ≤1.05×/≤1.20×/≤1.40×/≤1.70×/>1.70×.

---

## Youth Academy
- New game: `generateCohort()` immediately
- End of season: `runYouthIntake()` — age+1, new intake, AI auto-promotes
- Tiers by rep: elite≥93 · top≥85 · good≥75 · average≥65 · poor<65
- Wonderkid chance: ~4% elite · ~1% top · 0% below
- Age-out: 20+ released if not promoted
- Always pass `userTeamId` to `buildInitialCupState`

---

## CSV Data Pipeline

```
1. Create data/csv/<league>_teams.csv + data/csv/<league>_players.csv
2. python3 csv_to_league.py data/csv/<league>_teams.csv \
                             data/csv/<league>_players.csv \
                             data/<league>.js \
                             <ARRAY_NAME> <helper_fn>
3. python3 build.py  (must pass 0 failures)
```
`build.py` auto-discovers all `data/*.js`. New leagues need a cup mapping in `cups.js`.

**teams.csv:** `team_id, name, short_name, crest, league, stadium, stadium_capacity, budget_millions, reputation, primary_color`
**players.csv:** `team_id, player_id, name, position, age, attack, midfield, defence, goalkeeping, value_millions, wage_thousands`

Validation: 11–30 players/team · ≥1 GK · ratings 1–99 · ages 15–45 · all team_ids valid.

### Generated Files
| File | Array | Teams | Players |
|------|-------|-------|---------|
| plTeams.js | `PL_TEAMS` | 20 | 349 |
| championship.js | `CHAMPIONSHIP_TEAMS` | 24 | 340 |
| leagueOne.js | `LEAGUE_ONE_TEAMS` | 24 | 349 |
| leagueTwo.js | `LEAGUE_TWO_TEAMS` | 24 | 336 |
| eredivisie.js | `EREDIVISIE_TEAMS` | 18 | 250 |

### Ready-to-Add
| League | Array | Helper | JS file |
|--------|-------|--------|---------|
| Segunda | `SEGUNDA_TEAMS` | `sgp` | `segunda.js` |
| 2. Bundesliga | `ZWEITE_LIGA_TEAMS` | `blp` | `zweiteLiga.js` |
| Serie B | `SERIE_B_TEAMS` | `sbp` | `serieB.js` |
| Ligue 2 | `LIGUE_2_TEAMS` | `l2fp` | `ligue2.js` |

### Rating Guide
| Tier | Range |
|------|-------|
| PL elite | 85–95 |
| PL mid | 75–85 |
| PL lower / Champ top | 70–80 |
| Championship mid | 65–75 |
| Championship lower | 60–72 |
| League One top | 65–78 |
| League One mid | 58–72 |
| League One lower | 52–66 |
| League Two top | 56–70 |
| League Two mid | 50–66 |
| League Two lower | 44–60 |

GK: `goalkeeping` 72–95; `attack/midfield/defence` always 10–20.

---

## Data Policy
Always use 2025/26 data (Transfermarkt, ESPN, Wikipedia). Include January 2026 transfers. Ages from DOB as of Aug 2025.

**❌** Outdated squads · fictional players · Championship players at PL ratings · ignoring loans/Jan transfers · hand-editing generated JS (edit CSVs, re-run converter) · hand-editing plTeams.js (edit pl_players.csv / pl_teams.csv, re-run converter with `PL_TEAMS plp`)

---

## Anti-Patterns (never do these)

**Architecture:** skip `build.py` · rewrite whole module when `str_replace` works · add features without validator checks · rename functions without `RENAMES` in `build.py` · reorder modules · `cp index.html` over build output (build.py writes directly to `/mnt/user-data/outputs/`) · deliver without verifying fixes in final HTML

**Event queue:** re-introduce `processCupRounds()`/`finaliseGW()` · silent cup sim in `advanceOneFixture` · advance GW before `pendingEvents` empty

**UI:** `showModal()` from `watchmatch.js` · `showModal()` inside `showModal()` · `position:absolute` inside `.modal-xl` → use `_openInlinePanel()` · formation picker in pre-match

**Match engine:** different drain rates in `simulateMatch` vs `simulateMatchSegment` · GK weight≠0 · cross-position GK subs · filter ALL GKs from bench · pass `homePlayers`/`awayPlayers` positionally

**Cups:** super cups in `LEAGUE_DOMESTIC_CUPS` · `resetCups()` on rollover · European/invitation cups with zero activity · `buildInitialCupState` without `userTeamId` · domestic cup opponents from wrong league

**Data:** homeScorers/awayScorers concatenated · `selectEleven()` without `save.lineup` for user

**Fixtures:** shuffle second-half independently · European finals within GW 1–38 · use `save.totalGameweeks` directly → use `getEffectiveTotalGW(save)` · show "❌ Out" for 1st leg losses → use "❌ Lost"

**Promotion:** auto-promote 3 teams · skip playoffs for English lower leagues · run playoffs for non-English · forget to update team leagues in DB · forget to simulate non-user standings

**Injuries & Recovery:** inline `week${…}` formatting instead of `injuryDurationLabel()` · `processInjuryRecovery` only saving on full recovery (must always save when any player was injured — GW decrements must persist) · `updateCache` using stale `allPlayers` instead of fresh `getAllPlayers()` from DB · `startNewGame` leaving `save.lineup` as `null` (must auto-generate via `selectEleven`) · any display path showing injury durations without calling `injuryDurationLabel()`

---

## Validation
1180 checks / 22 sections + 11 regression suites. Covers: CUP_META · European finals post-season · `getEffectiveTotalGW` · `LEAGUE_DOMESTIC_CUPS` per nation · transfer filters · mentality mods + wiring · goal attribution · GK bench · fitness drain · HOME/AWAY labels · player development · save export/import · promotion/relegation/playoffs · fixture generation · injury system (duration labels, recovery persistence, lineup auto-generation).

**Policy: 0 failures before shipping.**

---

## Open Issues
- [ ] Player morale system
- [ ] Two-legged UCL knockout ties (currently single-leg + AET/pens)
- [ ] News feed / inbox
- [ ] Manager reputation / difficulty tiers
- [ ] Watch Match: player ratings on fitness list
- [ ] Watch Match: live mentality change mid-match
- [ ] Super cups auto-awarded on win
- [ ] Segunda / 2. Bundesliga / Serie B / Ligue 2 data
- [ ] Loan recall mid-season (architecture ready: `loanRecallable` field reserved)
- [ ] Loan cap per club (architecture ready: `save.loanCap` reserved)

## Loan System (added this session)

### Player schema additions
```js
onLoan              // boolean — true while out on loan
loanedFrom          // teamId of parent club (set on the player at loan club)
loanedTo            // reserved (not set on parent-side; player physically moves)
loanOriginalTeamId  // safety copy of parent teamId for season-end return
loanSeason          // season string e.g. '2025/26'
loanRecallable      // boolean — reserved for future mid-season recall support
```

### Financial model (upfront at point of signing)
- **Loan fee:** 10% of player's base `value`
- **Loan club pays:** `loanFee + (wage × gwsRemaining)` deducted immediately from budget
- **Parent club (user loaning out):** receives `loanFee + wageCost` credited immediately (full wage relief)
- **Parent club (AI):** receives `loanFee` only

### Key functions (`modules/transfers.js`)
| Function | Purpose |
|----------|---------|
| `loanOutPlayer(playerId)` | User loans out own player — finds AI taker, credits budget |
| `loanInPlayer(playerId)` | User loans in AI player — deducts total cost upfront |
| `getLoanableInPlayers(save)` | Returns AI players eligible for loan-in (age ≤22, fringe, not already loaned) |
| `simulateAILoans(save)` | Per-GW AI-to-AI loan sim (15% activity/club/GW during open windows) |
| `_loanFee(player)` | 10% of base value |
| `_loanWageCost(player, save)` | wage × gwsRemaining |
| `loanTotalCost(player, save)` | fee + wageCost |
| `_aiWillingToLoanOut(player, team)` | Returns true only for fringe youth (age ≤22 or isYouth) |

### AI loan logic
- Runs each GW alongside `simulateAITransfers` (all 3 call sites in `gameweek.js`)
- 15% activity chance per lending club per GW — gradual drip preserves loan targets for user
- Lender criteria: rep ≥ 70, squad ≥ 20 players
- Loan candidates: outside top-11 by rating, age ≤ 22, not already loaned/transferred
- Receiving club: must be lower rep than lender, squad < 28, can afford total cost

### Season-end return (`modules/season.js`)
- Runs inside `processEndOfSeason` **before** the aging step
- All `onLoan` players returned to `loanOriginalTeamId`
- All loan metadata cleared (`onLoan`, `loanedFrom`, `loanOriginalTeamId`, `loanSeason`, `loanRecallable`)
- Returned players merged back into `players` array so aging runs at correct club
- Development (growthPoints, stat boosts) fully preserved — `applyDevelopment` runs throughout season on loan players normally

### UI (`ui/home_transfers.js`, `shell.html`)
- **Loans tab** added to Transfer Market screen (alongside Buy / Sell)
- **Loan In** sub-tab: lists loanable AI players sorted by age/potential, shows total upfront cost, confirm modal with full cost breakdown
- **Loan Out** sub-tab: lists user squad eligible for loan, shows budget relief calculation, confirm modal
- Both sub-tabs respect transfer window status (show closed message when window shut)

### Invariants
- Loan players can never face a closed window — `WINDOW_CLOSED` error thrown in both `loanInPlayer` and `loanOutPlayer`
- A player with `onLoan: true` or `loanedFrom` set cannot be loaned again (`ALREADY_ON_LOAN`)
- `signedThisSeason` gate applies to loans same as permanent transfers
- AI only loans fringe youth — top-11 never loaned, age > 22 never loaned by AI
- Loans only flow DOWN in reputation (receiving club rep must be < lending club rep)

**❌** Loaning a player already on loan · loaning outside a transfer window · AI loaning top-11 players · AI loaning players aged 23+ · receiving club with equal/higher rep than lender

## Completed in v3.5
Promotion/relegation full English pyramid · playoff system (Poisson, away goals, 2-leg semis) · non-user league simulation · end-of-season modal · reputation changes · League One + League Two + Eredivisie via CSV · aging/decline/retirement · 4-factor valuation · slider counter-offers (buy+sell) · wonderkid tax · advanced transfer filters · mentality system (4 modes) · xG fix · European cup visibility fix · correct domestic cups per nation · super cups invitation-only · season rollover `buildInitialCupState` · fixture mirroring + back-to-back elimination · European finals post-season + `getEffectiveTotalGW` · save export/import (base64 + hash) · potential system · modal z-index fixes · Watch Match inline panel architecture · injury system (~20/season, skewed short durations, weeks/months labels, recovery persistence, auto-lineup on new game) · **loan system** (season-long loans, 10% fee + upfront wages, AI-to-AI per-GW drip, Loans tab UI, season-end return with development preserved)
