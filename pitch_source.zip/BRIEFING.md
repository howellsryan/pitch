# PITCH v3.3 — AI Session Briefing

> **Paste this file as your FIRST message in a new Claude conversation.**
> Replaces ~200k tokens of history with ~3k tokens of precise, actionable context.

## Quick Reference

| Action | Command |
|--------|---------|
| **Build** | `python3 /home/claude/pitch2/build.py` |
| **Validate** | `node /home/claude/pitch2/validate.js` (1004 checks, 0 failures required) |
| **Output** | `/mnt/user-data/outputs/index.html` (single-file, ~570KB) |
| **Bundle** | `/tmp/bundle_final.js` (intermediate, read by validate.js) |

## Project: What Is PITCH

Single-file football career manager. Vanilla JS + IndexedDB + CSS. No framework, no bundler at runtime — `build.py` concatenates 22 source files, strips ES module syntax, runs validation, and emits one HTML file.

## Source Map

```
/home/claude/pitch2/
├── build.py                 # Build pipeline (bundle → validate → assemble → structural checks)
├── csv_to_league.py         # CSV→JS converter for adding new leagues/updating squads ★
├── validate.js              # 912 checks across 21 sections + 10 regression suites
├── shell.html               # HTML/CSS shell (no JS) — 73KB
├── BRIEFING.md              # This file
│
├── data/                    # Static team/player data (read-only at runtime)
│   ├── plTeams.js           # 20 PL clubs, 2025/26 squads (30KB)
│   ├── extraLeagues.js      # La Liga, Bundesliga, Serie A, Ligue 1 (77KB)
│   ├── championship.js      # 24 Championship clubs, full squads — AUTO-GENERATED ★
│   ├── leagueOne.js         # 24 League One clubs, full squads — AUTO-GENERATED ★
│   ├── leagueTwo.js         # 24 League Two clubs, full squads — AUTO-GENERATED ★
│   ├── eredivisie.js        # 18 Eredivisie clubs, full squads — AUTO-GENERATED ★
│   └── csv/                 # Source CSVs for auto-generated leagues ★
│       ├── championship_teams.csv    # 24 team metadata rows
│       ├── championship_players.csv  # ~337 player rows
│       ├── league_one_teams.csv      # 24 team metadata rows
│       ├── league_one_players.csv    # ~349 player rows
│       ├── league_two_teams.csv      # 24 team metadata rows
│       └── league_two_players.csv    # ~336 player rows
│
├── modules/                 # Game logic (no DOM access)
│   ├── db.js                # IndexedDB: openDB, bulkPut, clearAndBulkPut, deleteDB
│   ├── matchEngine.js       # Simulation core (see §Match Engine below) ★
│   ├── standings.js         # sortTable, applyResult, recomputePositions, blankStandingRow
│   ├── fixtures.js          # generateLeagueFixtures (circle-method + H/A optimisation)
│   ├── cups.js              # CUP_META, LEAGUE_DOMESTIC_CUPS, INVITATION_ONLY_CUPS, UCL_CLUBS ★
│   ├── transfers.js         # buyPlayer, sellPlayer, generateAIOffers, formAdjustedValue
│   ├── potential.js         # assignPotentials, applyDevelopment, getPotentialStars
│   ├── promotion.js         # getEuropeanQualifiers, processLeagueChanges, assignCupsFromPosition
│   ├── youthAcademy.js      # generateCohort, runYouthIntake, promoteYouthPlayer
│   ├── save.js              # startNewGame (seeds teams+players+fixtures+standings+youth) ★
│   ├── season.js            # processEndOfSeason, calculatePrizeMoney, reputationBudget
│   └── gameweek.js          # Event queue: buildPendingEvents, advanceOneFixture (see §Event Queue) ★
│
└── ui/                      # DOM rendering (reads modules, writes to DOM)
    ├── helpers.js            # fmt.money/wage/date, toast, showModal, showLoader, navigateTo
    ├── home_transfers.js     # renderHome, showMatchReport, handleEndOfSeason, renderTransfers★
    ├── renderers.js          # renderCompetitions, renderNewGame, renderHonours★, renderSettings, boot
    ├── squad_tactics_offers.js  # renderSquad, renderTactics★, renderOffers, renderCups★
    ├── academy.js            # renderAcademy, buildYouthCard, handleYouthAction
    ├── prematch.js           # showPreMatchModal★, handleAdvanceOneFixture, _launchWatchMatch
    └── watchmatch.js         # showWatchMatchModal★, live tick engine, subs, tactics
```

★ = changed this session

## Build Order (dependencies flow top→bottom)

```
data/plTeams → data/extraLeagues → data/championship
  → db → matchEngine → standings → fixtures → cups → transfers
  → potential → promotion → youthAcademy → save → season → gameweek
  → helpers → home_transfers → renderers → squad_tactics_offers
  → academy → prematch → watchmatch
```

**Never reorder modules in build.py** — later modules reference earlier ones as globals.

---

## Critical Invariants

### §Event Queue — One Event Per Button Press

```
save.pendingEvents = [{type:'league', fixtureId, gw}, {type:'ucl_md', ...}, {type:'cup', ...}]
```

- `buildPendingEvents(gw, userTeamId, fixtures, cups, allTeams)` builds the queue each GW
- Each press pops ONE event → pre-match modal → simulate → result modal
- Cup opponents are **pre-drawn at queue build time** (name/crest/home-away stored on event)
- GW counter advances **only when pendingEvents is empty**
- AI league fixtures for the same GW are resolved silently after the user's league match

**Forbidden**: `processCupRounds()`, `finaliseGW()`, silent cup simulation inside `advanceOneFixture`

### §Lineup Flow — Tactics Screen Is Source of Truth

```
Tactics screen (renderTactics)
  → writes save.formation (string, e.g. '4-3-3')
  → writes save.lineup (array of 11 player IDs, or null for auto-pick)
        ↓
Pre-match modal (READ-ONLY — displays formation/lineup, no override)
        ↓
Quick Sim:   advanceOneFixture() → simulateMatch(..., hLineup, aLineup)
Watch Match: _launchWatchMatch() → buildLiveMatchState(..., homeLineup, awayLineup)
```

**Forbidden**: formation picker in pre-match modal, calling `showModal()` inside `showModal()`

### §Watch Match — Inline Panel Architecture

The watch match modal IS `#modal-bd`. Calling `showModal()` from inside it **destroys the live match**.

All intervention panels use `_openInlinePanel(title, bodyHtml, onClose)`:
- Appends a `position:fixed` overlay to `document.body` (z-index 600)
- Auto-pauses match, resumes on close

Substitution rules: GK↔GK only, outfield↔outfield only (`_applyUserSub` enforces). 3-sub limit.

### §Cup System — Correct National Competitions Per League

```
LEAGUE_DOMESTIC_CUPS (cups.js) — open knockout cups only (every team in the league enters):
  Premier League / Championship → fa_cup + league_cup
  La Liga    → copa_del_rey
  Bundesliga → dfb_pokal
  Serie A    → coppa_italia
  Ligue 1    → coupe_de_france
  Eredivisie → knvb_beker

INVITATION_ONLY_CUPS (cups.js) — never assigned blindly, only shown if team has activity:
  dfb_supercup, supercopa, supercoppa, trophee_des_champions

European cups — assigned by assignCups() only above rep thresholds:
  rep >= 90 → ucl  |  rep >= 82 → uel  |  rep >= 76 → uecl  |  below → none
```

`renderCups` uses `ACTIVITY_GATED` set to hide European + invitation-only cups unless the team
has ≥1 result, non-zero roundIndex, or UCL matchdays played.

`processEndOfSeason` rebuilds cups via `buildInitialCupState(newCupIds, userTeamId)` — not `resetCups`.

**Forbidden**:
- ❌ Adding super cups to `LEAGUE_DOMESTIC_CUPS`
- ❌ Calling `resetCups(save.cups)` on season rollover (loses correct cup assignment)
- ❌ Showing European/invitation cups with zero activity

### §Match Engine

| Attribute | Drives |
|-----------|--------|
| `attack` | Goal scoring (ST/CF/RW/LW/CAM) |
| `midfield` | Possession, chance creation, assists |
| `defence` + `goalkeeping` | Defensive resistance (70/30 split) |
| `mentality` | Overall shape — see §Mentality System |

- **120 phases/game**, midfield ratio + mentality midShareBoost determines phase distribution
- GK can **NEVER** score (weight=0 in `pickScorer`)
- Fitness drain: ~0.22/attacking phase, ~0.15/defending → ~22 total/game
- Recovery between matches: played +15, non-played +20
- Drain rates **identical** in `simulateMatch` and `simulateMatchSegment`

Live match API:
```
buildLiveMatchState() → liveState (mutable)
simulateMatchSegment(home, away, liveState, startPhase, endPhase) → {segEvents, updatedState}
finaliseLiveMatch(home, away, liveState, allEvents) → standard result shape
```

---

## §Mentality System

```
save.mentality = 'defensive' | 'balanced' | 'possession' | 'attacking'
```

Set in Tactics screen, persisted in save state, read by all simulation entry points.

`getMentalityMods(mentality)` (exported from `matchEngine.js`) returns a modifier object:

```js
{
  goalProbMult,    // multiplies per-phase goal probability for the attacking team
  defResistMult,   // divides into goal probability for the defending team
  midShareBoost,   // added to hMidShare (phase distribution) — positive = more possession
  phasesBoostOpp,  // informational; reflected via opponent's midShareBoost
  shotsMultSelf,   // applied in computeMatchStats to total shots for this team
  shotsMultOpp,    // applied to opponent's shots (captured via their own mods)
}
```

| Mentality | goalProbMult | defResistMult | midShareBoost | shotsMultSelf |
|---|---|---|---|---|
| defensive  | 0.72 | 1.30 | −0.07 | 0.80 |
| balanced   | 1.00 | 1.00 |  0.00 | 1.00 |
| possession | 0.88 | 1.08 | +0.09 | 0.90 |
| attacking  | 1.32 | 0.78 | +0.06 | 1.20 |

**Wiring**: mentality flows through every simulation path:
- `simulateMatch` — accepts `homeMentality`, `awayMentality` (9th + 10th params)
- `buildLiveMatchState` — same params; stores `hMods`/`aMods` in `liveState`
- `simulateMatchSegment` — reads `hMods`/`aMods` from `liveState`
- `finaliseLiveMatch` — passes mods into `computeMatchStats`
- `simulateCupRound` — reads `event.userMentality`
- `simulateUCLMatchday` — accepts `userMentality` as 4th param
- `gameweek.js` — injects `save.mentality` at all call sites

**UI**: Tactics screen (`renderTactics`) shows 4 buttons in a 2×2 grid with icon, label and description. Active mentality highlighted in accent colour. Pre-match modal shows current mentality with icon + label below formation.

**Forbidden**:
- ❌ Calling `simulateMatch` / `buildLiveMatchState` without considering mentality (defaults to `'balanced'` safely, but user mentality should be passed)
- ❌ Adding mentality logic outside `getMentalityMods` — keep all tuning in one place



### Player
```js
{ id, name, position, age, attack, midfield, defence, goalkeeping,
  value, wage, teamId, fitness, potentialRating, growthPoints, peakAge,
  goals, assists, cleanSheets, form, injured, suspended, inSquad, transferListed,
  isYouth, isWonderkid, youthTeamId, season }
```

### Save State
```js
{ userTeamId, userLeague, currentGameweek, totalGameweeks, currentDate, season,
  formation,       // string '4-3-3' — set by Tactics screen only
  mentality,       // 'defensive' | 'balanced' | 'possession' | 'attacking' — set by Tactics screen
  lineup,          // [11 player IDs] or null — set by Tactics screen only
  cups, pendingEvents, inboundOffers, youthCohort }
```

### liveState (Watch Match)
```js
{ hActive, aActive, hBenchLeft, aBenchLeft, hFitness(Map), aFitness(Map),
  hSubsLeft, aSubsLeft, hGoals, aGoals, hPhases, aPhases,
  hStr, aStr, hMidShare, homeFormation, awayFormation, hElev, aElev, hBench, aBench }
```

---

## Cup & League Structure

| Competition | Entry criterion | Round GWs |
|---|---|---|
| FA Cup | All English clubs | 22, 25, 28, 31, 34, 37 |
| League Cup (Carabao) | All PL/Champ clubs | 3, 7, 12, 17, 20, 24 |
| Copa del Rey | All La Liga clubs | 8, 14, 22, 28, 32, 37 |
| DFB-Pokal | All Bundesliga clubs | 3, 8, 16, 24, 30, 37 |
| Coppa Italia | All Serie A clubs | 5, 12, 22, 27, 31, 36 |
| Coupe de France | All Ligue 1 clubs | 5, 10, 16, 22, 27, 33, 37 |
| KNVB Beker | All Eredivisie clubs | 6, 14, 22, 30, 37 |
| DFL-Supercup | Invitation only (champion vs cup winner) | 2 |
| Supercopa de España | Invitation only | 4, 5 |
| Supercoppa Italiana | Invitation only | 3 |
| Trophée des Champions | Invitation only | 2 |
| UCL League Phase | rep ≥ 90 | GWs 5,7,9,11,13,15,17,19 |
| UCL Knockouts | After league phase (≥7 pts) | 22, 27, 31, 35 |
| UEL | rep ≥ 82 | 6, 21, 25, 29, 33, 36 |
| UECL | rep ≥ 76 | 6, 22, 27, 31, 35 |

**PL zones**: Top 4→UCL · 5–6→UEL · 7→UECL · 18–20→Relegated  
**Championship**: 1–2→Auto promoted · 3→Playoff promoted · 22–24→League One

---

## Transfer Market (v3.2)

Advanced filter bar in the Buy panel (`_trFilters` state object in `home_transfers.js`):

| Control | Description |
|---|---|
| Sort | Rating / Value / Age / Potential / Goals / Assists |
| League | Filter by nation (dynamically populated) |
| Age slider | Dual-handle range 15–40 |
| Rating slider | Dual-handle range 40–99 |
| Max Price slider | Capped at 1.5× budget, live label |
| Min Potential | 1–5 star buttons |
| Affordable toggle | Hides players you can't afford (fee × 0.88 > budget) |
| Reset | Restores all defaults |
| Count badge | Live "N players" matching filters |

Player detail panel: potential stars + label + raw /99 rating, league flag emoji, fitness, form stats, value change vs base, weekly + annual wage, offer likelihood hint updating live with slider.

`_applyAndRenderBuyList(byId, team)` re-filters and re-sorts on every control change.

---

## Youth Academy

- New game: `generateCohort()` called immediately for user's team
- End of season: `runYouthIntake()` — ages youth +1, generates new intake, AI auto-promotes
- Tier scales with reputation: elite(93+) / top(85+) / good(75+) / average(65+) / poor(<65)
- Wonderkid chance: ~4% elite, ~1% top, 0% below
- Age-out: 20+ released automatically if not promoted
- `buildInitialCupState(cupIds, userTeamId)` — **always pass userTeamId** to exclude self from UCL opponents

---

## §CSV Data Pipeline — Adding & Updating Leagues

### Overview

League data is managed through a **CSV → JS** pipeline rather than hand-editing JS files.
This allows efficient bulk data loading, easy AI-assisted updates, and human-readable source files.

### Workflow: Adding a New League

```
1. Create  data/csv/<league>_teams.csv    (team metadata — 1 row per team)
2. Create  data/csv/<league>_players.csv  (player data — 1 row per player, ~14 per team)
3. Run:    python3 csv_to_league.py data/csv/<league>_teams.csv \
                                     data/csv/<league>_players.csv \
                                     data/<league>.js \
                                     <ARRAY_NAME> <helper_fn>
4. Run:    python3 build.py   (must pass 0 failures)
```

**Steps 4–6 from the old workflow are now automatic:**
- `build.py` auto-discovers all `data/*.js` files (sorted alphabetically, loaded before modules)
- `getAllTeamData()` in save.js and `ALL_TEAMS_DATA` in renderers.js both pre-register
  slots for future league arrays: `LEAGUE_ONE_TEAMS`, `LEAGUE_TWO_TEAMS`, `SEGUNDA_TEAMS`,
  `ZWEITE_LIGA_TEAMS`, `SERIE_B_TEAMS`, `LIGUE_2_TEAMS` — all safely no-op if undefined.
- The league filter icons in `renderNewGame` cover all English, Spanish, German, Italian,
  and French tiers. Unknown leagues fall back to 🌐.

**Only manual step needed for a truly new league system:** add cup mappings in `cups.js`
if the new league has domestic cups not yet defined in `LEAGUE_DOMESTIC_CUPS`.

### CSV Schemas

**teams.csv** — one row per team:
```
team_id, name, short_name, crest, league, stadium, stadium_capacity,
budget_millions, reputation, primary_color
```

**players.csv** — one row per player:
```
team_id, player_id, name, position, age, attack, midfield, defence,
goalkeeping, value_millions, wage_thousands
```

### Validation Rules (enforced by csv_to_league.py)

- Every team must have 11–30 players and at least 1 GK
- All ratings must be 1–99
- Valid positions: GK, RB, LB, CB, CDM, CM, CAM, LM, RM, RW, LW, CF, ST
- Ages must be 15–45
- Every player must reference a valid team_id

### Updating Existing League Data

To update a league (e.g. January transfer window):
1. Edit the CSV files in `data/csv/`
2. Re-run `csv_to_league.py` with the same arguments
3. Run `python3 build.py` — validates and rebuilds

### Current Generated Files

| File | Array | Teams | Players | Source CSVs |
|------|-------|-------|---------|-------------|
| `data/championship.js` | `CHAMPIONSHIP_TEAMS` | 24 | 340 | `csv/championship_teams.csv` + `csv/championship_players.csv` |
| `data/leagueOne.js` | `LEAGUE_ONE_TEAMS` | 24 | 349 | `csv/league_one_teams.csv` + `csv/league_one_players.csv` |
| `data/leagueTwo.js` | `LEAGUE_TWO_TEAMS` | 24 | 336 | `csv/league_two_teams.csv` + `csv/league_two_players.csv` |
| `data/eredivisie.js` | `EREDIVISIE_TEAMS` | 18 | 250 | `csv/eredivisie_teams.csv` + `csv/eredivisie_players.csv` |

### Ready-to-Add Leagues (pre-registered in save.js + renderers.js)

To add any of these, just create the CSVs, run the converter, and build. No code changes needed.

| League | Array Name | Helper | Exact command |
|--------|-----------|--------|---------------|
| Segunda División | `SEGUNDA_TEAMS` | `sgp` | `python3 csv_to_league.py data/csv/segunda_teams.csv data/csv/segunda_players.csv data/segunda.js SEGUNDA_TEAMS sgp` |
| 2. Bundesliga | `ZWEITE_LIGA_TEAMS` | `blp` | `python3 csv_to_league.py data/csv/zweite_teams.csv data/csv/zweite_players.csv data/zweiteLiga.js ZWEITE_LIGA_TEAMS blp` |
| Serie B | `SERIE_B_TEAMS` | `sbp` | `python3 csv_to_league.py data/csv/serie_b_teams.csv data/csv/serie_b_players.csv data/serieB.js SERIE_B_TEAMS sbp` |
| Ligue 2 | `LIGUE_2_TEAMS` | `l2fp` | `python3 csv_to_league.py data/csv/ligue_2_teams.csv data/csv/ligue_2_players.csv data/ligue2.js LIGUE_2_TEAMS l2fp` |

**Important for AI assistants adding leagues:**
1. **Always web-search** for current 2025/26 squad data — use ESPN squad pages, Transfermarkt, Wikipedia season articles
2. **Cross-reference** top scorers, clean sheet leaders, and table position to calibrate ratings
3. **Check January 2026 transfers** — players may have moved clubs mid-season
4. Use the championship CSVs as a template for format and rating calibration
5. League string in teams CSV must **exactly match** the key in `LEAGUE_DOMESTIC_CUPS` (cups.js)
6. Run `python3 build.py` — must pass with 0 failures before shipping

### Rating Guide (for data accuracy)

Ratings are 1–99. Position-appropriate stats should be high; others low.

| Tier | Example clubs | Typical range |
|------|--------------|---------------|
| PL elite | City, Arsenal, Liverpool | 85–95 key stats |
| PL mid | West Ham, Wolves | 75–85 |
| PL lower / Champ top | Southampton, Coventry | 70–80 |
| Championship mid | Derby, Stoke, Watford | 65–75 |
| Championship lower | Oxford, Charlton | 60–72 |
| League One top / relegated Champ | Cardiff, Luton, Huddersfield | 65–78 |
| League One mid | Bolton, Stockport, Plymouth | 58–72 |
| League One lower | Port Vale, Northampton | 52–66 |
| League Two top | Bromley, MK Dons, Swindon | 56–70 |
| League Two mid | Chesterfield, Grimsby | 50–66 |
| League Two lower | Harrogate, Newport | 44–60 |

GK special rules: `goalkeeping` 72–95, `attack/midfield/defence` always 10–20.

---

## §Data Accuracy Policy

**All player/team data must reflect the most current real-world information for the 2025/26 season.**

When creating or updating league data:
1. **Use latest transfer data** — reflect all completed transfers including January 2026 window
2. **Accurate squad composition** — players should be at their current club, not previous
3. **Realistic ratings** — based on current form and real-world ability, not historical peak
4. **Correct metadata** — stadium names, capacities, crests, league assignments must be current
5. **Budget & reputation** — scale appropriately to the club's real-world standing
6. **Ages** — calculate from real DOB as of start of 2025/26 season (August 2025)

When in doubt, cross-reference: Transfermarkt, ESPN squad pages, Wikipedia season articles.

**Forbidden**:
- ❌ Using outdated squad data from previous seasons
- ❌ Inventing fictional players to fill squads
- ❌ Rating Championship players at PL levels (Championship top ~80, not ~90)
- ❌ Ignoring loan moves or January transfers

---

## Anti-Patterns (DO NOT)

**Architecture**:
- ❌ Skip `build.py` and manually assemble HTML
- ❌ Rewrite a whole module when `str_replace` works
- ❌ Add features without adding `validate.js` checks
- ❌ Rename functions without adding to `RENAMES` in `build.py`
- ❌ Reorder modules in `build.py` (dependency chain breaks)

**Event queue**:
- ❌ Re-introduce `processCupRounds()` or `finaliseGW()`
- ❌ Simulate cups silently inside `advanceOneFixture()`
- ❌ Advance `currentGameweek` before `pendingEvents` is empty

**UI modals**:
- ❌ Call `showModal()` from inside `watchmatch.js` (destroys live match)
- ❌ Call `showModal()` inside another `showModal()` handler (destroys parent)
- ❌ Use `position:absolute` inside `.modal-xl` — use `_openInlinePanel()`
- ❌ Add formation picker to pre-match modal (Tactics screen is source of truth)

**Match engine**:
- ❌ Different fitness drain rates in `simulateMatch` vs `simulateMatchSegment`
- ❌ Allow GK to score (weight must be 0)
- ❌ Allow cross-position GK subs in `_applyUserSub`
- ❌ Filter ALL GKs from bench (backup GK needed for GK↔GK subs)
- ❌ Pass `homePlayers`/`awayPlayers` positionally — resolve from `userIsHome`

**Cups**:
- ❌ Add super cups to `LEAGUE_DOMESTIC_CUPS` (they are invitation-only)
- ❌ Use `resetCups(save.cups)` on season rollover — use `buildInitialCupState(newCupIds, userTeamId)`
- ❌ Show European/invitation cups with zero match activity
- ❌ Call `buildInitialCupState` without passing `userTeamId`
- ❌ Let domestic cup opponents draw from all leagues (filter by `userLeague`)

**Data**:
- ❌ Put all UCL scorers in `homeScorers` (respect `userIsHome`)
- ❌ Call `selectEleven()` without `save.lineup` for the user's team
- ❌ Use variables in template literals without defining them first in scope
- ❌ Hand-edit generated JS data files — edit the CSVs and re-run `csv_to_league.py`
- ❌ Use outdated squad data — always verify against current 2025/26 season
- ❌ Rate Championship players at PL levels (Championship top should peak ~80, not ~90)
- ❌ Invent fictional players — use real squad data from Transfermarkt/ESPN

---

## Validation Suite (1004 checks)

21 sections + section 22 (Mentality System) + 10 regression suites. Includes checks for:
- All 13 cup entries in `CUP_META` (including 4 national super cups and 4 national knockouts)
- `LEAGUE_DOMESTIC_CUPS` correctness per nation, super cups excluded
- `INVITATION_ONLY_CUPS` set present and populated
- `assignCups` never adding super cups for mid-rep clubs
- Non-English `buildInitialCupState` smoke tests (Spanish / German / Italian / French)
- Advanced transfer filter state and `_applyAndRenderBuyList` function
- `getMentalityMods` shape and correct values for all 4 mentalities
- `simulateMatch` accepting and returning mentality params
- Mentality UI elements present in bundle (mentality-pill, data-mentality, MENTALITIES)
- All existing regressions: goal attribution, GK bench, fitness drain, HOME/AWAY labels, etc.

**Policy: 0 failures required before shipping.**

---

## Open Issues

_Update at end of each session._

- [ ] Player morale system (affects match performance)
- [ ] Two-legged UCL knockout ties (currently single-leg + AET/pens)
- [ ] Player injury generation (fields exist, always false)
- [ ] News feed / inbox for transfers, cup draws
- [ ] Manager reputation / difficulty tiers
- [ ] Watch Match: player ratings on fitness list
- [ ] Watch Match: tactical instructions mid-match (press high, sit deep) — mentality changeable live
- [ ] Super cups awarded automatically when team wins league/domestic cup
- [x] League One data — 24 teams, 349 players added via CSV pipeline (2025/26 squads)
- [x] League Two data — 24 teams, 336 players added via CSV pipeline (2025/26 squads)
- [x] Eredivisie data — 18 teams, 250 players added via CSV pipeline (2025/26 squads) + KNVB Beker cup
- [ ] Segunda División / 2. Bundesliga / Serie B / Ligue 2 data
- [x] CSV→JS data pipeline for efficient league importing (csv_to_league.py)
- [x] Championship expanded from 6 to 24 clubs with full 2025/26 squads (337 players)
- [x] Data accuracy policy documented — always use latest transfers & real-world ratings
- [x] Mentality system: Defensive / Balanced / Possession / Attacking — affects goals, shots, possession, counter exposure
- [x] xG values fixed — now 0.20–0.38 per shot on target (was 0.12–0.18, too low)
- [x] European cups (UCL/UEL/UECL) visible in Cups modal as soon as team is enrolled, not gated behind activity
- [x] Transfers: advanced filter bar (sort, league, age, rating, price, potential, affordable)
- [x] Transfers: enhanced player detail panel (potential stars, league flag, offer likelihood)
- [x] Cups: correct national competitions per league (Copa del Rey, DFB-Pokal, Coppa Italia, Coupe de France)
- [x] Cups: super cups removed from automatic assignment (INVITATION_ONLY_CUPS)
- [x] Cups: European + invitation cups hidden unless team has match activity (ACTIVITY_GATED)
- [x] Cups: season rollover uses buildInitialCupState — not resetCups — league-correct cups preserved
- [x] Honours: trophy cabinet shows correct domestic cups for user's nation
- [x] Tactics screen is source of truth for lineup
- [x] Watch Match: mobile substitution bug fixed
- [x] Watch Match: skip match button
- [x] Fitness rebalanced: ~22/game drain, +15/+20 recovery
- [x] Goal attribution bug fixed
- [x] GK↔GK subs; cross-position blocked
- [x] Fitness drain synced across simulateMatch and simulateMatchSegment
- [x] HOME/AWAY labels always reflect venue
- [x] v3.1: Token-optimised source
