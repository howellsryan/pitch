/** modules/transfers.js — buyPlayer, sellPlayer, generateAIOffers, formAdjustedValue */

// ─── Form-adjusted value ──────────────────────────────────────
// Computes a realistic market value factoring in: base value, current form,
// age, and potential. Higher-value players get smaller % boosts from form
// to prevent £100M players becoming £250M. Young high-potential players
// in form get outsized premiums (the "wonderkid tax").
function formAdjustedValue(player) {
  const base  = Number(player.value) || 10_000_000;
  const age   = player.age ?? 24;
  const pot   = player.potentialRating ?? 70;
  const cur   = _fav_primaryRating(player) || 70; // fallback 70 if position/ratings missing
  const headroom = Math.max(0, pot - cur);

  // ── Form score: uses the player's actual form field (50 = average, 80+ = hot) ──
  // Form is updated each GW: rises when playing (boosted by goals/assists/CS), decays when benched
  const cappedForm = Math.min(99, Math.max(1, player.form ?? 50));

  // ── Form multiplier: scales DOWN for expensive players ──
  // Base form effect: hot form = up to +50%, cold = down to -25%
  let formMult;
  if (cappedForm >= 80)      formMult = 1.25 + (cappedForm - 80) * 0.013; // 80→1.25, 99→1.50
  else if (cappedForm >= 65) formMult = 1.08 + (cappedForm - 65) * 0.011; // 65→1.08, 79→1.24
  else if (cappedForm >= 50) formMult = 1.0;                               // average
  else if (cappedForm >= 35) formMult = 0.92 - (50 - cappedForm) * 0.004;  // 35→0.86
  else                       formMult = 0.75;

  // Dampen form effect for high-value players (diminishing returns)
  const valueTier = Math.min(1, base / 80_000_000);
  const dampening = 1 - valueTier * 0.4;

  // ALSO dampen form for low-rated players — a 55-rated player on a hot streak
  // shouldn't inflate as much as an 80-rated player on the same streak
  // Rating dampening: 0.4 at rating 50, 0.7 at 65, 1.0 at 78+
  const ratingDamp = Math.min(1, Math.max(0.4, (cur - 50) / 28));
  const dampenedFormMult = 1 + (formMult - 1) * dampening * ratingDamp;

  // ── Youth/potential premium ──
  // Young players with high potential command outsized premiums when in form
  // But scale by current rating — a 55-rated youth with high potential gets
  // a moderate premium, not the same as a 70-rated wonderkid
  let potentialMult = 1.0;
  if (age <= 23 && headroom > 10) {
    // Potential premium scales with headroom but is moderated by current rating
    // A 70-rated player with pot 90 (headroom 20): 0.03*20 = 0.60
    // A 55-rated player with pot 85 (headroom 30): 0.03*30 = 0.90 → capped 0.60
    const rawPremium = headroom * 0.03;
    // Cap harder for low-rated players: max premium scales from 30% at rating 50 to 80% at 75+
    const ratingCap = Math.min(0.80, 0.30 + Math.max(0, (cur - 50) / 25) * 0.50);
    const potPremium = Math.min(ratingCap, rawPremium);
    // Potential premium is a stable valuation factor — form has only a small
    // influence (±10%) so it doesn't compound with the form multiplier above
    const formFactor = Math.max(0, (cappedForm - 50) / 40);
    potentialMult = 1 + potPremium * (0.9 + 0.1 * formFactor);
  } else if (age <= 26 && headroom > 5) {
    potentialMult = 1 + Math.min(0.25, headroom * 0.015);
  }

  // ── Age discount for older players ──
  const ageMult = age >= 33 ? 0.80 : age >= 31 ? 0.90 : age >= 29 ? 0.95 : 1.0;

  // ── Final cap: prevent total multiplier from exceeding sensible bounds ──
  // For low-rated players (< 65), cap total boost at 2.0× base value
  // For mid-rated (65-75), cap at 2.5×; for high-rated (75+), no extra cap
  const rawResult = base * dampenedFormMult * potentialMult * ageMult;
  let maxMult;
  if (cur < 65)      maxMult = 2.0;
  else if (cur < 75) maxMult = 2.5;
  else               maxMult = 4.0;
  const capped = Math.min(rawResult, base * maxMult);

  return Math.max(500_000, Math.round(capped));
}

function _fav_primaryRating(p) {
  const pos = p.position;
  if (['ST','CF','RW','LW','CAM'].includes(pos)) return p.attack;
  if (['CM','CDM','RM','LM'].includes(pos))       return p.midfield;
  if (['CB','RB','LB'].includes(pos))             return p.defence;
  return p.goalkeeping;
}

function minimumOffer(player) {
  return Math.floor(formAdjustedValue(player) * 0.88);
}

// ─── Reputation gate ──────────────────────────────────────────
// Returns the minimum club reputation required to sign a player based on
// their CURRENT rating (not potential). High-potential/low-rated youth are
// not blocked — their potential is fine to develop at any club level.
// A club growing through promotions naturally gains rep to unlock better signings.
//
// Thresholds (current rating → min club rep):
//  90+  elite world-class  → need rep ≥ 88  (UCL-level clubs only)
//  85+  top-tier           → need rep ≥ 80
//  80+  very good          → need rep ≥ 72
//  75+  above average      → need rep ≥ 64
//  70+  solid              → need rep ≥ 56
//  65+  decent             → need rep ≥ 48
//  60+  league-standard    → need rep ≥ 40
//  <60  anyone can sign
function playerMinRepToSign(player) {
  const rating = _fav_primaryRating(player);
  if (rating >= 90) return 88;
  if (rating >= 85) return 80;
  if (rating >= 80) return 72;
  if (rating >= 75) return 64;
  if (rating >= 70) return 56;
  if (rating >= 65) return 48;
  if (rating >= 60) return 40;
  return 0;
}

// Returns true if a club is allowed to sign this player.
// Potential is explicitly excluded from the gate — a player with a low current
// rating but high potential can move to any club (developing wonderkids at
// small clubs is a valid and realistic strategy).
//
// Soft bypass: transfer-listed players are slightly more flexible (-4 rep)
// because they actively want to leave, giving lower-rep clubs a small window.
function canClubSignPlayer(team, player) {
  const minRep = playerMinRepToSign(player);
  if (minRep === 0) return true; // sub-60 rated — anyone can sign
  const clubRep = team.reputation ?? 60;
  const adjustedMin = player.transferListed ? Math.max(0, minRep - 4) : minRep;
  return clubRep >= adjustedMin;
}

// Human-readable reason why a signing is blocked (shown in UI).
function repGateReason(team, player) {
  const minRep = playerMinRepToSign(player);
  const needed = player.transferListed ? Math.max(0, minRep - 4) : minRep;
  const clubRep = team.reputation ?? 60;
  const gap = needed - clubRep;
  if (gap <= 0) return null;
  return `${player.name} (rated ${_fav_primaryRating(player)}) won't join — your club reputation (${clubRep}) is too low. Need ${needed}+.`;
}

// ─── Buy a player ─────────────────────────────────────────────
async function buyPlayer(playerId, offerAmount) {
  const save   = await getSave();
  const player = await getPlayer(playerId);
  if (!player)                           throw new Error('PLAYER_NOT_FOUND');
  if (player.teamId === save.userTeamId) throw new Error('ALREADY_IN_SQUAD');

  const userTeam   = await getTeam(save.userTeamId);
  if (!userTeam || userTeam.budget < offerAmount) throw new Error('INSUFFICIENT_FUNDS');

  // Reputation gate: player's current rating must be achievable for the club's rep level.
  // Potential is NOT gated — wonderkids can still develop at any club.
  if (!canClubSignPlayer(userTeam, player)) throw new Error('REP_TOO_LOW');

  // Capture BEFORE any writes
  const fromTeamId = player.teamId;
  const fromTeam   = await getTeam(fromTeamId);

  const threshold = minimumOffer(player);
  if (offerAmount < threshold) throw new Error('OFFER_REJECTED');
  if (offerAmount < formAdjustedValue(player) && Math.random() < 0.10) throw new Error('OFFER_REJECTED');

  await putTeam({ ...userTeam, budget: userTeam.budget - offerAmount });
  if (fromTeam) await putTeam({ ...fromTeam, budget: fromTeam.budget + offerAmount });
  const updated = { ...player, teamId: save.userTeamId };
  await putPlayer(updated);
  await addTransfer({ playerId, playerName: player.name, fromTeamId, toTeamId: save.userTeamId, fee: offerAmount, type: 'buy', date: save.currentDate });
  return { success: true, player: updated, fee: offerAmount };
}

// ─── Reputation-weighted team picker ─────────────────────────
// Higher-rep clubs are more likely to buy expensive/high-rated players.
// This means PL clubs realistically poach stars from Championship etc.
function _pickBuyerWeighted(teams, playerValue, playerRating) {
  // Weight = reputation^2 * budget-adequacy bonus
  // High-value players attract higher-rep clubs disproportionately
  const valueTier = Math.min(1, playerValue / 50_000_000); // 0-1, 1 at £50M+
  const ratingTier = Math.min(1, Math.max(0, (playerRating - 55) / 30)); // 0-1, peaks at 85+
  const attractiveness = Math.max(valueTier, ratingTier); // how "big" is this signing

  const weights = teams.map(t => {
    const rep = t.reputation ?? 60;
    const canAfford = t.budget >= playerValue * 0.8 ? 1.5 : (t.budget >= playerValue * 0.5 ? 0.8 : 0.2);
    // Base weight from reputation — higher rep clubs much more likely for attractive players
    const repWeight = attractiveness > 0.4
      ? Math.pow(rep / 60, 2.5)   // big signings: top clubs dominate
      : Math.pow(rep / 60, 1.2);  // modest signings: more even spread
    return repWeight * canAfford;
  });

  const total = weights.reduce((s, w) => s + w, 0);
  if (total === 0) return teams[Math.floor(Math.random() * teams.length)];
  let r = Math.random() * total;
  for (let i = 0; i < teams.length; i++) {
    r -= weights[i];
    if (r <= 0) return teams[i];
  }
  return teams[teams.length - 1];
}

// ─── Sell a player ────────────────────────────────────────────
async function sellPlayer(playerId) {
  const save   = await getSave();
  const player = await getPlayer(playerId);
  if (!player || player.teamId !== save.userTeamId) throw new Error('PLAYER_NOT_IN_SQUAD');

  const allTeams  = await getAllTeams();
  const aiTeams   = allTeams.filter(t => t.id !== save.userTeamId);
  const fee       = Math.round(formAdjustedValue(player) * (0.9 + Math.random() * 0.22));
  const rating    = _fav_primaryRating(player);

  // Try up to 5 times to find a buyer that can afford the fee AND meets rep gate
  let buyerTeam = null;
  for (let attempt = 0; attempt < 5; attempt++) {
    const candidate = _pickBuyerWeighted(aiTeams, fee, rating);
    if (candidate && candidate.budget >= fee && canClubSignPlayer(candidate, player)) { buyerTeam = candidate; break; }
  }
  if (!buyerTeam) throw new Error('NO_BUYERS');

  const userTeam = await getTeam(save.userTeamId);
  await putTeam({ ...buyerTeam, budget: buyerTeam.budget - fee });
  await putTeam({ ...userTeam,  budget: userTeam.budget  + fee });
  await putPlayer({ ...player, teamId: buyerTeam.id });
  await addTransfer({ playerId, playerName: player.name, fromTeamId: save.userTeamId, toTeamId: buyerTeam.id, fee, type: 'sell', date: save.currentDate });
  return { success: true, fee, buyerName: buyerTeam.name };
}

// ─── Generate AI inbound offers ───────────────────────────────
/**
 * Each gameweek, AI clubs may bid on your players.
 * Stored in save.inboundOffers = [{playerId, clubId, clubName, fee, date, status}]
 */
async function generateAIOffers() {
  const save      = await getSave();
  const myPlayers = await getAllPlayers();
  const userSquad = myPlayers.filter(p => p.teamId === save.userTeamId);
  const allTeams  = await getAllTeams();
  const aiTeams   = allTeams.filter(t => t.id !== save.userTeamId);

  const existing = save.inboundOffers?.filter(o => o.status === 'pending') ?? [];

  // Limit to 2 new offers per gameweek
  const newOffers = [];
  const shuffled  = [...userSquad].sort(() => Math.random() - 0.5);
  for (const player of shuffled.slice(0, 4)) {
    if (existing.find(o => o.playerId === player.id)) continue;
    if (Math.random() > 0.25) continue; // 25% chance per player per GW
    const fav    = formAdjustedValue(player);
    const rating = _fav_primaryRating(player);
    const club   = _pickBuyerWeighted(aiTeams, fav, rating);
    const fee    = Math.round(fav * (0.85 + Math.random() * 0.35));
    if (club.budget < fee) continue;
    // Only clubs that meet the rep threshold can bid on the player
    if (!canClubSignPlayer(club, player)) continue;
    newOffers.push({ playerId: player.id, playerName: player.name, clubId: club.id, clubName: club.name, fee, date: save.currentDate, status: 'pending' });
    if (newOffers.length >= 2) break;
  }

  const allOffers = [...existing, ...newOffers];
  await putSave({ ...save, inboundOffers: allOffers });
  return newOffers;
}

// ─── Accept an inbound offer ──────────────────────────────────
async function acceptOffer(playerId) {
  const save   = await getSave();
  const offer  = save.inboundOffers?.find(o => o.playerId === playerId && o.status === 'pending');
  if (!offer) throw new Error('OFFER_NOT_FOUND');

  const player   = await getPlayer(playerId);
  const buyerTeam = await getTeam(offer.clubId);
  const userTeam  = await getTeam(save.userTeamId);
  if (!buyerTeam || buyerTeam.budget < offer.fee) throw new Error('BUYER_CANT_AFFORD');

  await putTeam({ ...buyerTeam, budget: buyerTeam.budget - offer.fee });
  await putTeam({ ...userTeam,  budget: userTeam.budget  + offer.fee });
  await putPlayer({ ...player, teamId: offer.clubId });
  await addTransfer({ playerId, playerName: player.name, fromTeamId: save.userTeamId, toTeamId: offer.clubId, fee: offer.fee, type: 'accepted_offer', date: save.currentDate });

  const updated = save.inboundOffers.map(o => o.playerId === playerId ? { ...o, status: 'accepted' } : o);
  await putSave({ ...save, inboundOffers: updated });
  return { success: true, fee: offer.fee, buyerName: offer.clubName };
}

// ─── Reject an offer ──────────────────────────────────────────
async function rejectOffer(playerId) {
  const save  = await getSave();
  const updated = (save.inboundOffers ?? []).map(o => o.playerId === playerId && o.status === 'pending' ? { ...o, status: 'rejected' } : o);
  await putSave({ ...save, inboundOffers: updated });
}

// ─── Counter an offer — instant negotiation ─────────────────
async function counterOffer(playerId, askingPrice) {
  const save   = await getSave();
  const player = await getPlayer(playerId);
  const fav    = player ? formAdjustedValue(player) : askingPrice;
  let result   = { outcome: 'rejected' };

  const updated = (save.inboundOffers ?? []).map(o => {
    if (o.playerId !== playerId || o.status !== 'pending') return o;

    // AI decision logic:
    // If asking <= 105% of their original offer, they just accept at your asking price
    if (askingPrice <= o.fee * 1.05) {
      result = { outcome: 'accepted', fee: askingPrice, clubName: o.clubName };
      return { ...o, fee: askingPrice, status: 'pending' };
    }

    // If asking is reasonable (within 130% of their offer), chance they meet in the middle
    const stretch = askingPrice / o.fee;
    if (stretch <= 1.30 && Math.random() < 0.55) {
      const meetFee = Math.round(o.fee + (askingPrice - o.fee) * (0.4 + Math.random() * 0.4));
      result = { outcome: 'accepted', fee: meetFee, clubName: o.clubName };
      return { ...o, fee: meetFee, status: 'pending' };
    }

    // Otherwise they come back with a revised (higher) counter, or walk away
    if (Math.random() < 0.6) {
      // AI bumps their offer up but not to your asking price
      const bump = Math.round(o.fee * (1.05 + Math.random() * 0.15));
      const newFee = Math.min(bump, askingPrice - 1);
      result = { outcome: 'counter', fee: newFee, clubName: o.clubName, originalFee: o.fee };
      return { ...o, fee: newFee, status: 'pending' };
    }

    // Walk away
    result = { outcome: 'rejected', clubName: o.clubName };
    return { ...o, counterAsking: askingPrice, status: 'counter_rejected' };
  });

  await putSave({ ...save, inboundOffers: updated });
  return result;
}

// ─── Buy-side counter: club comes back with price after rejection ──
function generateBuyCounter(player, offerAmount) {
  const fav       = formAdjustedValue(player);
  const threshold = minimumOffer(player);

  // If offer was way too low, they don't negotiate
  if (offerAmount < threshold * 0.7) return null;

  // Club counters at somewhere between form value and 115% of form value
  const counterFee = Math.round(fav * (1.0 + Math.random() * 0.15));
  // Small chance they just won't sell at all
  if (Math.random() < 0.15) return null;

  return { fee: counterFee, playerName: player.name, playerId: player.id };
}

