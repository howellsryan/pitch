/** modules/season.js — End-of-season: aging, honors, prize money, season rollover */

// ─── Real-life trophy tallies (as of 2025) ───────────────────
const REAL_LIFE_HONORS = {
  // English
  fa_cup:         { arsenal:14, man_utd:12, chelsea:8, tottenham:8, liverpool:8, man_city:7, aston_villa:7, newcastle:6 },
  league_cup:     { man_city:8, liverpool:10, aston_villa:5, chelsea:5, man_utd:6, tottenham:4, arsenal:2 },
  premier_league: { man_city:10, man_utd:13, chelsea:5, arsenal:3, liverpool:1 },
  // Spanish
  copa_del_rey:   { barcelona:31, athletic_bilbao:23, real_madrid:20, atletico:10, real_sociedad:3, valencia:8 },
  supercopa:      { real_madrid:12, barcelona:14, atletico:2 },
  // German
  dfb_pokal:      { bayern:20, dortmund:5, leverkusen:1, frankfurt:5, bremen:6 },
  dfb_supercup:   { bayern:9, dortmund:6, leverkusen:1 },
  // Italian
  coppa_italia:   { juventus:15, inter:9, roma:9, lazio:7, napoli:7, ac_milan:5, fiorentina:6, atalanta:1 },
  supercoppa:     { juventus:9, inter:8, ac_milan:7, lazio:5, roma:2, napoli:2 },
  // French
  coupe_de_france:{ psg:15, marseille:10, lyon:5, monaco:5, lille:6, rennes:2 },
  trophee_des_champions: { psg:11, lyon:5, marseille:3, monaco:3, lille:2 },
  // European
  ucl:            { real_madrid:15, barcelona:5, ac_milan:7, liverpool:6, man_utd:3, inter:3, chelsea:2, man_city:1, dortmund:1, juventus:2, ajax:4, benfica:2, porto:2 },
  uel:            { sevilla:7, inter:3, chelsea:2, atletico:3, liverpool:3, man_utd:1, juventus:3, ajax:1, porto:2, fiorentina:1 },
  uecl:           { roma:1, west_ham:1, chelsea:1, fiorentina:0, atalanta:1 },
};

// ─── Prize money ─────────────────────────────────────────────
// Domestic cup winners mapped to approximate prize equivalent
const CUP_WIN_PRIZE = {
  ucl:50_000_000, uel:20_000_000, uecl:10_000_000,
  fa_cup:3_600_000, league_cup:2_000_000,
  copa_del_rey:3_000_000, supercopa:1_500_000,
  dfb_pokal:3_000_000, dfb_supercup:500_000,
  coppa_italia:3_000_000, supercoppa:500_000,
  coupe_de_france:2_800_000, trophee_des_champions:500_000,
};
const CUP_RUN_PRIZE = {
  ucl:15_000_000, uel:6_000_000, uecl:2_000_000,
  fa_cup:900_000, league_cup:400_000,
  copa_del_rey:700_000, supercopa:200_000,
  dfb_pokal:700_000, dfb_supercup:0,
  coppa_italia:700_000, supercoppa:0,
  coupe_de_france:700_000, trophee_des_champions:0,
};

function calculatePrizeMoney(leaguePosition, cupState, userLeague) {
  // League-specific prize/distribution money (realistic rough guides)
  // Sources: EFL distributions, PL solidarity payments, 2024/25 season estimates
  let leaguePrize = 0;

  if (!userLeague || userLeague === 'Premier League') {
    // Premier League: ~£2m per position from bottom (facility fees) + merit tiers
    // Bottom club ~£100m, top ~£180m total revenue; we model the variable portion
    const plPrize = 2_000_000 * (21 - leaguePosition);
    const merit   =
      leaguePosition === 1 ? 60_000_000 :
      leaguePosition <= 4  ? 40_000_000 :
      leaguePosition <= 6  ? 20_000_000 :
      leaguePosition <= 10 ? 10_000_000 : 5_000_000;
    leaguePrize = plPrize + merit;

  } else if (userLeague === 'Championship') {
    // Championship: ~£8m EFL basic award + ~£3m PL solidarity = ~£11m base
    // Minimal position-based variation (~£100k winner, ~£7k bottom)
    const positionBonus = Math.max(0, Math.round(100_000 * (25 - leaguePosition) / 23));
    leaguePrize = 11_000_000 + positionBonus;

  } else if (userLeague === 'League One') {
    // League One: ~£1m EFL basic + ~£0.8m PL solidarity ≈ £1.8m–£2m
    leaguePrize = 1_900_000;

  } else if (userLeague === 'League Two') {
    // League Two: ~£0.9m EFL basic + ~£0.6m PL solidarity ≈ £1.5m
    leaguePrize = 1_500_000;

  } else {
    // Other leagues (La Liga, Bundesliga, etc.) — rough guide, no real data modelled
    leaguePrize = 5_000_000;
  }

  let cupPrize = 0;
  if (cupState) {
    for (const [cupId, state] of Object.entries(cupState)) {
      if (state.status === 'winner') {
        cupPrize += CUP_WIN_PRIZE[cupId] ?? 0;
      } else if ((state.roundIndex ?? 0) >= 3) {
        cupPrize += CUP_RUN_PRIZE[cupId] ?? 0;
      }
    }
  }
  return leaguePrize + cupPrize;
}

// ─── End-of-season processing ─────────────────────────────────
async function processEndOfSeason() {
  const save      = await getSave();
  const standings = await getAllStandings();
  const players   = await getAllPlayers();
  const allTeams  = await getAllTeams();

  const sorted       = [...standings].sort((a, b) => b.points - a.points || b.goalDifference - a.goalDifference);
  const leagueWinner = sorted[0];
  const userPosition = sorted.findIndex(r => r.teamId === save.userTeamId) + 1;
  const summary      = buildSeasonSummary(save, sorted, players, userPosition);

  // ── Award prize money to user ────────────────────────────
  const prizeMoney = calculatePrizeMoney(userPosition, save.cups, save.userLeague);
  const userTeamRec = await getTeam(save.userTeamId);
  if (userTeamRec) {
    await putTeam({ ...userTeamRec, budget: userTeamRec.budget + prizeMoney });
    summary.prizeMoney = prizeMoney;
  }

  // ── Award honors ─────────────────────────────────────────
  if (leagueWinner?.teamId === save.userTeamId) {
    await addHonor({ trophy: 'premier_league', season: save.season, teamId: save.userTeamId });
  }
  if (save.cups) {
    for (const [cupId, cupState] of Object.entries(save.cups)) {
      if (cupState.status === 'winner') {
        await addHonor({ trophy: cupId, season: save.season, teamId: save.userTeamId });
      }
    }
  }

  await addSeason(summary);

  // ── Refresh AI team budgets by reputation ────────────────
  const nonUserTeams = allTeams.filter(t => t.id !== save.userTeamId);
  for (const t of nonUserTeams) {
    const freshBudget = reputationBudget(t.reputation ?? 70, false);
    await putTeam({ ...t, budget: freshBudget });
  }

  // ── Age all players ───────────────────────────────────────
  const agedPlayers = players.map(p => {
    // Apply stat decline for aging players before bumping age
    const declined = applyAgingDecline(p);
    return {
      ...declined,
      age:            (declined.age ?? 22) + 1,
      value:          agingValueAdjust(declined),
      goals:          0,
      assists:        0,
      cleanSheets:    0,
      form:           50,
      fitness:        100,
      // Clear all injury state between seasons
      injured:        false,
      injuryGWsLeft:  0,
      injuryGWsTotal: 0,
      injuryName:     null,
      injuryType:     null,
    };
  });
  await putPlayersBulk(agedPlayers);

  // ── Retire players aged 36+ ─────────────────────────────────
  // Players who have turned 36 after aging retire from the game.
  // A small chance (15%) lets legendary players (rating 80+) hang on one more year.
  const retirees = agedPlayers.filter(p => {
    if (p.age < 36) return false;
    // Elite veterans can delay retirement by 1 year
    const rating = _retirePrimaryRating(p);
    if (p.age === 36 && rating >= 80 && Math.random() < 0.15) return false;
    if (p.age === 36 && rating >= 75 && Math.random() < 0.08) return false;
    return true;
  });
  const retireIds = retirees.map(p => p.id);
  if (retireIds.length > 0) {
    await deletePlayersBulk(retireIds);
  }
  // Track retirements for user's team
  const userRetirees = retirees.filter(p => p.teamId === save.userTeamId);
  summary.retirements = userRetirees.map(p => ({ name: p.name, age: p.age, position: p.position }));

  // ── Youth academy intake ───────────────────────────────────
  const allTeamsForAcademy = await getAllTeams();
  const newYouthCohort = await runYouthIntake(save, allTeamsForAcademy);
  // Cohort will be stored in the newSave below

  // ── Process promotion/relegation and European qualification ─
  const leagueChanges = await processLeagueChanges(sorted, [], save.userTeamId);
  summary.leagueChanges = leagueChanges;

  // ── Refresh all teams post after league changes ─────────────
  const allTeamsRefreshed = await getAllTeams();

  // ── Setup next season ─────────────────────────────────────
  const nextYear   = parseInt(save.season.split('/')[0]) + 1;
  const nextSeason = `${nextYear}/${String(nextYear + 1).slice(2)}`;

  // User's new league (may have changed due to relegation/promotion)
  const userTeamUpdated = allTeamsRefreshed.find(t => t.id === save.userTeamId);
  const userNewLeague   = userTeamUpdated?.league ?? save.userLeague ?? 'Premier League';
  const leagueTeamsNext = allTeamsRefreshed.filter(t => (t.league ?? 'Premier League') === userNewLeague);
  const nextLeagueSize  = leagueTeamsNext.length;
  const nextTotalGWs    = (nextLeagueSize - 1) * 2;

  const newFixtures  = generateLeagueFixtures(leagueTeamsNext.map(t => t.id), nextYear);
  const newStandings = leagueTeamsNext.map(t => blankStandingRow(t));

  await replaceAllFixtures(newFixtures);
  await replaceAllStandings(newStandings);

  // Determine cups from correct national competition for new league + position
  // If the user changed leagues (promotion/relegation), they don't qualify for
  // European cups based on their old league position — only domestic cups.
  const leagueChanged = userNewLeague !== (save.userLeague ?? 'Premier League');
  const userPosForCups = leagueChanged ? 99 : sorted.findIndex(r => r.teamId === save.userTeamId) + 1;
  const newCupIds      = assignCupsFromPosition(userPosForCups, userNewLeague, save.cups ?? {});
  const newCups        = buildInitialCupState(newCupIds, save.userTeamId);

  const newSave = {
    ...save,
    currentGameweek: 1,
    totalGameweeks:  nextTotalGWs,
    currentDate:     new Date(nextYear, 7, 9).toISOString(),
    season:          nextSeason,
    userLeague:      userNewLeague,
    cups:            newCups,
    lineup:          save.lineup ?? null,
    formation:       save.formation ?? '4-3-3',
    youthCohort:     newYouthCohort,
    inboundOffers:   [],
    collapsedDeals:  [],
  };
  await putSave(newSave);

  return { summary, leagueWinner, newSave, prizeMoney, leagueChanges };
}

// agingValueAdjust is provided by potential.js (imported as agingValueAdjust)
// applyAgingDecline is provided by potential.js (imported as applyAgingDecline)

// ─── Inline primary rating for retirement check ──────────────
function _retirePrimaryRating(p) {
  const pos = p.position;
  if (['ST','CF','RW','LW','CAM'].includes(pos)) return p.attack;
  if (['CM','CDM','RM','LM'].includes(pos))       return p.midfield;
  if (['CB','RB','LB'].includes(pos))             return p.defence;
  return p.goalkeeping;
}

function buildSeasonSummary(save, sorted, players, userPosition) {
  return {
    season:     save.season,
    userLeague: save.userLeague ?? 'Premier League',
    champion:   sorted[0]?.teamId,
    relegated:  sorted.slice(-3).map(r => r.teamId),
    table:      sorted.map(r => ({ teamId: r.teamId, points: r.points, gd: r.goalDifference })),
    topScorers: [...players].filter(p => p.goals > 0).sort((a,b) => b.goals - a.goals).slice(0, 5).map(p => ({ id: p.id, name: p.name, goals: p.goals, teamId: p.teamId })),
    topAssists: [...players].filter(p => p.assists > 0).sort((a,b) => b.assists - a.assists).slice(0, 5).map(p => ({ id: p.id, name: p.name, assists: p.assists, teamId: p.teamId })),
    userFinish: userPosition,
    cups:       save.cups ?? {},
    prizeMoney: 0,
  };
}

function resetCups(old) {
  const fresh = {};
  Object.keys(old).forEach(id => { fresh[id] = { id, roundIndex: 0, status: 'active', results: [] }; });
  return fresh;
}

// ─── Get honors for a team ────────────────────────────────────
async function getHonorsForTeam(teamId) {
  const earned   = await getAllHonors();
  const myEarned = earned.filter(h => h.teamId === teamId);
  const combined = {};
  Object.entries(REAL_LIFE_HONORS).forEach(([trophy, tallies]) => { combined[trophy] = tallies[teamId] ?? 0; });
  myEarned.forEach(h => { combined[h.trophy] = (combined[h.trophy] ?? 0) + 1; });
  return { combined, earned: myEarned };
}

// ─── Budget refresh at season start ──────────────────────────
/**
 * Each season, AI teams get a reputation-scaled transfer budget.
 * Higher reputation = bigger budget. Prize money already added
 * to user. Here we refresh AI budgets so the market stays liquid.
 */
function reputationBudget(reputation, isUserTeam = false) {
  // Scale: rep 99 → ~£200m, rep 70 → ~£30m, rep 60 → ~£12m
  const base = Math.round(
    reputation >= 95 ? 180_000_000 + (reputation - 95) * 10_000_000 :
    reputation >= 90 ? 120_000_000 + (reputation - 90) * 12_000_000 :
    reputation >= 85 ? 75_000_000  + (reputation - 85) *  9_000_000 :
    reputation >= 80 ? 45_000_000  + (reputation - 80) *  6_000_000 :
    reputation >= 75 ? 28_000_000  + (reputation - 75) *  3_400_000 :
    reputation >= 70 ? 18_000_000  + (reputation - 70) *  2_000_000 :
    reputation >= 65 ? 10_000_000  + (reputation - 65) *  1_600_000 :
                        5_000_000  + reputation * 77_000
  );
  // Add some variance so not every team has exactly the same budget
  const variance = base * (Math.random() * 0.12 - 0.06);
  return Math.round(base + variance);
}

