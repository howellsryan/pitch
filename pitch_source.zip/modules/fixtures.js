/** modules/fixtures.js — Circle-method round-robin fixture generation with H/A optimization */

import { getAllFixtures, putFixture } from './db.js';

export function generateLeagueFixtures(teamIds, seasonYear) {
  // 1. Shuffle to prevent any team always being "pinned" at index 0
  const shuffled = [...teamIds].sort(() => Math.random() - 0.5);
  const teams    = [...shuffled];
  if (teams.length % 2 !== 0) teams.push('BYE');
  const n = teams.length;

  // 2. First half: circle-method round-robin
  const firstHalf = [];
  const wt = [...teams];
  for (let r = 0; r < n - 1; r++) {
    const pairs = [];
    for (let i = 0; i < n / 2; i++) {
      if (wt[i] !== 'BYE' && wt[n-1-i] !== 'BYE')
        pairs.push({ home: wt[i], away: wt[n-1-i] });
    }
    firstHalf.push(pairs);
    wt.splice(1, 0, wt.pop());
  }

  // 2b. Balance H/A: each team should have ~half home, ~half away in first half.
  //     The circle method gives the pinned team (index 0) all-home, so flip
  //     selected pairs to balance. Target: each team ≤ ceil(19/2) = 10 home.
  const homeCount = new Map(teams.map(t => [t, 0]));
  const maxHome = Math.ceil((n - 1) / 2);  // 10 for 20 teams
  for (const round of firstHalf) {
    for (let i = 0; i < round.length; i++) {
      homeCount.set(round[i].home, (homeCount.get(round[i].home) ?? 0) + 1);
    }
  }
  // Greedily flip pairs where home team has too many home games
  for (const round of firstHalf) {
    for (let i = 0; i < round.length; i++) {
      const p = round[i];
      const hc = homeCount.get(p.home) ?? 0;
      const ac = homeCount.get(p.away) ?? 0;
      if (hc > maxHome && ac < maxHome) {
        // Flip this pair
        homeCount.set(p.home, hc - 1);
        homeCount.set(p.away, ac + 1);
        round[i] = { home: p.away, away: p.home };
      }
    }
  }

  // 3. Second half: swap H/A, shuffle round order independently
  const secondHalf = firstHalf
    .map(r => r.map(({ home, away }) => ({ home: away, away: home })))
    .sort(() => Math.random() - 0.5);

  function countBadRuns(rounds) {
    const tms = new Set(rounds.flatMap(r => r.flatMap(p => [p.home, p.away])));
    let bad = 0;
    for (const t of tms) {
      let run = 0, last = '';
      for (const r of rounds) {
        const m = r.find(p => p.home === t || p.away === t);
        if (!m) continue;
        const v = m.home === t ? 'H' : 'A';
        run = v === last ? run + 1 : 1;
        last = v;
        if (run >= 4) bad += run - 3; // Penalise runs > 3
      }
    }
    return bad;
  }

  // 4. Greedy optimisation: swap rounds WITHIN each half to reduce long consecutive H/A runs
  //    Keeping halves separate ensures each team plays every other team once before reverse fixtures.
  function optimiseHalf(rounds) {
    let best = [...rounds];
    let bestScore = countBadRuns(best);
    for (let iter = 0; iter < 200 && bestScore > 0; iter++) {
      const i = Math.floor(Math.random() * best.length);
      const j = Math.floor(Math.random() * best.length);
      if (i === j) continue;
      [best[i], best[j]] = [best[j], best[i]];
      const newScore = countBadRuns(best);
      if (newScore > bestScore) [best[i], best[j]] = [best[j], best[i]];
      else bestScore = newScore;
    }
    return best;
  }

  const optFirst = optimiseHalf(firstHalf);
  const optSecond = optimiseHalf(secondHalf);
  let allRounds = [...optFirst, ...optSecond];

  // 5. Final full pass: only swap rounds within the SAME half to preserve
  //    the two-half structure (each team faces every opponent once per half).
  let fullScore = countBadRuns(allRounds);
  const halfLen = optFirst.length;
  for (let iter = 0; iter < 600 && fullScore > 0; iter++) {
    // Pick a random half, swap two rounds within it
    const half = Math.random() < 0.5 ? 0 : halfLen;
    const i = half + Math.floor(Math.random() * halfLen);
    const j = half + Math.floor(Math.random() * halfLen);
    if (i === j) continue;
    [allRounds[i], allRounds[j]] = [allRounds[j], allRounds[i]];
    const newScore = countBadRuns(allRounds);
    if (newScore > fullScore) [allRounds[i], allRounds[j]] = [allRounds[j], allRounds[i]];
    else fullScore = newScore;
  }

  // 5. Convert to fixture objects
  const startDate = new Date(seasonYear, 7, 9); // Aug 9
  return allRounds.flatMap((round, gwIdx) =>
    round.map(({ home, away }) => ({
      id:          `gw${gwIdx+1}_${home}_${away}`,
      competition: 'league',
      gameweek:    gwIdx + 1,
      homeTeamId:  home,
      awayTeamId:  away,
      date:        new Date(startDate.getTime() + gwIdx * 7 * 86400000).toISOString(),
      played:      false,
      homeGoals:   null,
      awayGoals:   null,
      homeScorers: [],
      awayScorers: [],
      events:      [],
    }))
  );
}

// ─── Query helpers ──────────────────────────────────────────

export async function getUpcomingForTeam(teamId) {
  const all = await getAllFixtures();
  return all
    .filter(f => !f.played && (f.homeTeamId === teamId || f.awayTeamId === teamId))
    .sort((a, b) => a.gameweek - b.gameweek);
}

export async function getLastResultForTeam(teamId) {
  const all = await getAllFixtures();
  return all
    .filter(f => f.played && (f.homeTeamId === teamId || f.awayTeamId === teamId))
    .sort((a, b) => b.gameweek - a.gameweek)[0] ?? null;
}

export async function getNextFixtureForTeam(teamId) {
  const upcoming = await getUpcomingForTeam(teamId);
  return upcoming[0] ?? null;
}

export async function getRecentResults(limit = 30) {
  const all = await getAllFixtures();
  return all
    .filter(f => f.played)
    .sort((a, b) => b.gameweek - a.gameweek)
    .slice(0, limit);
}
