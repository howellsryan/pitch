# PITCH v3.5 — AI Agent Briefing

> Paste as first message. Replaces ~200k tokens of history with precise context.

## Commands
| Action | Command |
|--------|---------|
| Build | `python3 /home/claude/pitch2/build.py` |
| Validate | `node /home/claude/pitch2/validate.js` (1190 checks, **0 failures required**) |
| Output | `/mnt/user-data/outputs/index.html` (~616KB single file) |
| Bundle | `/tmp/bundle_final.js` (intermediate, read by validate.js) |

## What Is PITCH
Single-file football career manager. Vanilla JS + IndexedDB + CSS. No framework. `build.py` concatenates 22 source files, strips ES modules, validates, emits one HTML file.

## Source Map
```
/home/claude/pitch2/
├── build.py               # Bundle → validate → assemble → structural checks
├── csv_to_league.py       # CSV→JS converter for leagues ★
├── validate.js            # 1190 checks / 21 sections + 11 regression suites
├── shell.html             # HTML/CSS shell, no JS (73KB)
├── data/
│   ├── plTeams.js         # 20 PL clubs, 2025/26 squads (30KB)
│   ├── extraLeagues.js    # La Liga, Bundesliga, Serie A, Ligue 1 (77KB)
│   ├── championship.js    # 24 clubs, AUTO-GENERATED ★
│   ├── leagueOne.js       # 24 clubs, AUTO-GENERATED ★
│   ├── leagueTwo.js       # 24 clubs, AUTO-GENERATED ★
│   ├── eredivisie.js      # 18 clubs, AUTO-GENERATED ★
│   └── csv/               # Source CSVs for generated leagues ★
├── modules/               # Game logic (no DOM)
│   ├── db.js              # IndexedDB: openDB, bulkPut, clearAndBulkPut, deleteDB
│   ├── matchEngine.js     # Simulation core ★
│   ├── standings.js       # sortTable, applyResult, recomputePositions
│   ├── fixtures.js        # generateLeagueFixtures (circle-method + H/A opt.)
│   ├── cups.js            # CUP_META, LEAGUE_DOMESTIC_CUPS, INVITATION_ONLY_CUPS ★
│   ├── transfers.js       # buyPlayer, sellPlayer, generateAIOffers, formAdjustedValue
│   ├── potential.js       # assignPotentials, applyDevelopment, getPotentialStars
│   ├── promotion.js       # getEuropeanQualifiers, processLeagueChanges, runPlayoffs ★
│   ├── youthAcademy.js    # generateCohort, runYouthIntake, promoteYouthPlayer
│   ├── save.js            # startNewGame (seeds teams+players+fixtures+standings+youth) ★
│   ├── season.js          # processEndOfSeason, calculatePrizeMoney, reputationBudget ★
│   └── gameweek.js        # buildPendingEvents, advanceOneFixture, getEffectiveTotalGW ★
└── ui/                    # DOM rendering
    ├── helpers.js          # fmt.money/wage/date, toast, showModal, navigateTo
    ├── home_transfers.js   # renderHome, showMatchReport, handleEndOfSeason ★
    ├── renderers.js        # renderCompetitions, renderNewGame, renderHonours, boot ★
    ├── squad_tactics_offers.js  # renderSquad, renderTactics, renderOffers, renderCups ★
    ├── academy.js          # renderAcademy, buildYouthCard, handleYouthAction
    ├── prematch.js         # showPreMatchModal, handleAdvanceOneFixture ★
    └── watchmatch.js       # showWatchMatchModal, live tick engine, subs, tactics ★
```
★ = changed this session

## Build Order
```
plTeams → extraLeagues → championship → db → matchEngine → standings → fixtures
→ cups → transfers → potential → promotion → youthAcademy → save → season
→ gameweek → helpers → home_transfers → renderers → squad_tactics_offers
→ academy → prematch → watchmatch
```
**Never reorder** — later modules reference earlier ones as globals.

---

## Critical Invariants

### Event Queue
```js
save.pendingEvents = [{type:'league', fixtureId, gw}, {type:'ucl_md',...}, {type:'cup',...}]
```
- `buildPendingEvents(gw, userTeamId, fixtures, cups, allTeams)` builds queue each GW
- Each button press pops ONE event → pre-match modal → simulate → result modal
- Cup opponents pre-drawn at queue build time (name/crest/home-away on event)
- GW advances **only when pendingEvents is empty**
- AI league fixtures for the same GW resolved silently after user's match

**❌ Forbidden:** `processCupRounds()`, `finaliseGW()`, silent cup simulation inside `advanceOneFixture`

### Lineup Flow
```
Tactics screen → writes save.formation (string '4-3-3') + save.lineup ([11 IDs] or null)
  → Pre-match modal (READ-ONLY display, no override)
  → Quick Sim: advanceOneFixture() → simulateMatch(..., hLineup, aLineup)
  → Watch Match: _launchWatchMatch() → buildLiveMatchState(..., homeLineup, awayLineup)
```
**❌ Forbidden:** formation picker in pre-match modal, calling `showModal()` inside `showModal()`

### Watch Match — Inline Panel Architecture
`#modal-bd` IS the watch match modal. `showModal()` from inside it **destroys the live match**.

All intervention panels use `_openInlinePanel(title, bodyHtml, onClose)`:
- Appends `position:fixed` overlay to `document.body` (z-index 10500 > modal 10000)
- Auto-pauses match, resumes on close

Sub rules: GK↔GK only, outfield↔outfield only (`_applyUserSub` enforces). 3-sub limit.

### Cup System
```
LEAGUE_DOMESTIC_CUPS (knockout, all teams enter):
  PL / Championship → fa_cup + league_cup
  La Liga → copa_del_rey | Bundesliga → dfb_pokal
  Serie A → coppa_italia | Ligue 1 → coupe_de_france | Eredivisie → knvb_beker

INVITATION_ONLY_CUPS (never assigned blindly):
  dfb_supercup, supercopa, supercoppa, trophee_des_champions

European (assignCups by rep):
  rep ≥ 90 → ucl | ≥ 82 → uel | ≥ 76 → uecl | below → none
```
`renderCups` uses `ACTIVITY_GATED` — hides European + invitation cups unless ≥1 result, non-zero roundIndex, or UCL matchdays played.
`processEndOfSeason` rebuilds via `buildInitialCupState(newCupIds, userTeamId)` — **not** `resetCups`.

**❌ Forbidden:** super cups in `LEAGUE_DOMESTIC_CUPS` · `resetCups()` on season rollover · European/invitation cups shown with zero activity

### Match Engine
| Attribute | Drives |
|-----------|--------|
| `attack` | Goal scoring (ST/CF/RW/LW/CAM) |
| `midfield` | Possession, chance creation, assists |
| `defence` + `goalkeeping` | Defensive resistance (70/30 split) |
| `mentality` | Overall shape |

- 120 phases/game; midfield ratio + mentality `midShareBoost` → phase distribution
- GK weight = 0 in `pickScorer` (can never score)
- Fitness drain: ~0.18/attacking phase, ~0.12/defending (~18 total/game age 24)
- Age drain multiplier: 30+ → 1.10×, 33+ → 1.20×, 36+ → 1.35× (`ageDrain()`)
- Recovery: played +20 (age penalty: 30+ −2, 33+ −4, 36+ −6, floor 8); rested → 100%
- Drain rates **identical** in `simulateMatch` and `simulateMatchSegment`

### Aging, Decline & Retirement
End-of-season (`processEndOfSeason`):
1. `applyAgingDecline(player)` — stat decay past `peakAge + 1`:
   - Decline chance: 15% (1yr) → 30% (2-3yr) → 50% (4-5yr) → 70% (6-7yr) → 85% (8+yr)
   - Primary stat −1–3/yr; secondary at half rate; floors 30/20
2. `agingValueAdjust(player)` — value multiplier: <28 appreciates · 28-29: 0.97× · 30-31: 0.92× · 32-33: 0.85× · 34-35: 0.75× · 36+: 0.60× · floor £500K
3. Retirement: 36+ deleted at season end (15% reprieve if rating ≥ 80 at 36; 8% if ≥ 75 at 36)

Live match API:
```js
buildLiveMatchState() → liveState
simulateMatchSegment(home, away, liveState, startPhase, endPhase) → {segEvents, updatedState}
finaliseLiveMatch(home, away, liveState, allEvents) → standard result shape
```

---

## Mentality System
```js
save.mentality = 'defensive' | 'balanced' | 'possession' | 'attacking'
```
`getMentalityMods(mentality)` in `matchEngine.js` returns:
```js
{ goalProbMult, defResistMult, midShareBoost, phasesBoostOpp, shotsMultSelf, shotsMultOpp }
```

| Mentality | goalProbMult | defResistMult | midShareBoost | shotsMultSelf |
|---|---|---|---|---|
| defensive | 0.72 | 1.30 | −0.07 | 0.80 |
| balanced | 1.00 | 1.00 | 0.00 | 1.00 |
| possession | 0.88 | 1.08 | +0.09 | 0.90 |
| attacking | 1.32 | 0.78 | +0.06 | 1.20 |

Wiring — mentality flows through every simulation path:
- `simulateMatch` — 9th + 10th params: `homeMentality`, `awayMentality`
- `buildLiveMatchState` — same; stores `hMods`/`aMods` in `liveState`
- `simulateMatchSegment` — reads `hMods`/`aMods` from `liveState`
- `finaliseLiveMatch` — passes mods into `computeMatchStats`
- `simulateCupRound` — reads `event.userMentality`
- `simulateUCLMatchday` — 4th param `userMentality`
- `gameweek.js` — injects `save.mentality` at all call sites

**❌ Forbidden:** calling `simulateMatch`/`buildLiveMatchState` without mentality · adding mentality logic outside `getMentalityMods`

---

## Data Schemas

### Player
```js
{ id, name, position, age, attack, midfield, defence, goalkeeping,
  value, wage, teamId, fitness, potentialRating, growthPoints, peakAge,
  goals, assists, cleanSheets, form, injured, suspended, inSquad, transferListed,
  isYouth, isWonderkid, youthTeamId, season }
```

### Save State
```js
{ userTeamId, userLeague, currentGameweek, totalGameweeks, currentDate, season,
  formation,   // string '4-3-3' — Tactics screen only
  mentality,   // 'defensive'|'balanced'|'possession'|'attacking' — Tactics screen only
  lineup,      // [11 player IDs] | null — Tactics screen only
  cups, pendingEvents, inboundOffers, youthCohort }
```

### liveState (Watch Match)
```js
{ hActive, aActive, hBenchLeft, aBenchLeft, hFitness(Map), aFitness(Map),
  hSubsLeft, aSubsLeft, hGoals, aGoals, hPhases, aPhases,
  hStr, aStr, hMidShare, homeFormation, awayFormation, hElev, aElev, hBench, aBench }
```

---

## Cup & League Structure

| Competition | Entry | Round GWs |
|---|---|---|
| FA Cup | All English clubs | 20,24,27,30,33,37 |
| League Cup | All PL/Champ clubs | 3,6,12,17,20,30 |
| Copa del Rey | All La Liga | 8,14,22,28,32,37 |
| DFB-Pokal | All Bundesliga | 3,8,16,24,30,37 |
| Coppa Italia | All Serie A | 5,12,22,27,31,37 |
| Coupe de France | All Ligue 1 | 5,10,16,22,27,33,37 |
| KNVB Beker | All Eredivisie | 6,14,22,30,37 |
| DFL-Supercup | Invitation | 2 |
| Supercopa | Invitation | 4,5 |
| Supercoppa | Invitation | 3 |
| Trophée des Champions | Invitation | 2 |
| UCL League Phase | rep ≥ 90 | 5,7,9,11,13,15,17,19 |
| UCL Knockouts | After phase (≥7 pts) | 26,30,34,**40** |
| UEL | rep ≥ 82 | 6,23,27,31,35,**39** |
| UECL | rep ≥ 76 | 6,27,31,35,**40** |

European finals are **post-season** (GW 39–40). `getEffectiveTotalGW(save)` extends season when user is active in Europe.

**PL zones:** Top 4→UCL · 5–6→UEL · 7→UECL · 18–20→Relegated
**Championship/L1:** 1–2 auto-promoted · 3–6 playoffs (2-leg semis + neutral final) · 22–24→Relegated
**League Two:** 1–2 auto · 3–6 playoffs · No relegation

---

## Promotion, Relegation & Playoffs

`processLeagueChanges()` in `promotion.js`:

| Tier | Auto Promoted | Playoffs | Relegated |
|------|--------------|----------|-----------|
| Premier League | — | — | Bottom 3 → Championship |
| Championship | Top 2 → PL | 3rd–6th → PL | Bottom 3 → L1 |
| League One | Top 2 → Champ | 3rd–6th → Champ | Bottom 3 → L2 |
| League Two | Top 2 → L1 | 3rd–6th → L1 | None |

`runPlayoffs`: 3v6 + 4v5 semis (2-leg, higher seed hosts 2nd leg) → neutral final. Tiebreak: aggregate → away goals → pens (50/50).

Reputation changes on movement:
| Destination | Promotion | Relegation | Max/Min |
|---|---|---|---|
| PL | +4 | −3 | 82/60 |
| Championship | +3 | −2 | 72/50 |
| League One | +2 | −2 | 62/42 |
| League Two | +2 | −1 | 55/35 |

**❌ Forbidden:** auto-promoting 3 teams · playoffs for non-English leagues · skipping `runPlayoffs` for Champ/L1/L2

---

## Transfer Market

### Filter Bar (`_trFilters` in `home_transfers.js`)
Sort · League · Age range · Rating range · Max Price · Min Potential · Affordable toggle · Reset · Count badge

`_applyAndRenderBuyList(byId, team)` re-runs on every control change.

### Valuation — `formAdjustedValue(player)`
1. **Form multiplier** (dampened by value): hot form → up to +50%, dampened at high values. Formula: `1 - (base/80M) * 0.4`
2. **Youth/potential premium**: ≤23 with 10+ headroom → up to +80% when in form (score >50); ≤26 with 5+ headroom → up to +25%
3. **Age discount**: 29-30: 0.95× · 31-32: 0.90× · 33+: 0.80×
4. **Floor**: £500K minimum

### Negotiation
**Buying (rejected):** `generateBuyCounter()` → slider from original offer to 130% asking price. Live hints. Budget cap on slider max.
**Selling (AI bids):** slider from AI offer to 2× form value (step £500K). Likelihood hints at ≤1.05×/≤1.20×/≤1.40×/≤1.70×/>1.70×. `counterOffer()` accepts/meets/bumps/walks.

---

## Youth Academy
- New game: `generateCohort()` called immediately
- End of season: `runYouthIntake()` — age +1, new intake, AI auto-promotes
- Tiers by rep: elite ≥93 · top ≥85 · good ≥75 · average ≥65 · poor <65
- Wonderkid chance: ~4% elite, ~1% top, 0% below
- Age-out: 20+ released if not promoted
- Always pass `userTeamId` to `buildInitialCupState` (excludes self from UCL opponents)

---

## CSV Data Pipeline

### Workflow
```
1. Create data/csv/<league>_teams.csv + data/csv/<league>_players.csv
2. python3 csv_to_league.py data/csv/<league>_teams.csv \
                             data/csv/<league>_players.csv \
                             data/<league>.js \
                             <ARRAY_NAME> <helper_fn>
3. python3 build.py  (must pass 0 failures)
```
`build.py` auto-discovers all `data/*.js`. New leagues need only a cup mapping in `cups.js` if not already defined.

### CSV Schemas
**teams.csv:** `team_id, name, short_name, crest, league, stadium, stadium_capacity, budget_millions, reputation, primary_color`
**players.csv:** `team_id, player_id, name, position, age, attack, midfield, defence, goalkeeping, value_millions, wage_thousands`

Validation: 11–30 players/team, ≥1 GK, ratings 1–99, positions valid, ages 15–45, all team_ids valid.

### Current Generated Files
| File | Array | Teams | Players |
|------|-------|-------|---------|
| championship.js | `CHAMPIONSHIP_TEAMS` | 24 | 340 |
| leagueOne.js | `LEAGUE_ONE_TEAMS` | 24 | 349 |
| leagueTwo.js | `LEAGUE_TWO_TEAMS` | 24 | 336 |
| eredivisie.js | `EREDIVISIE_TEAMS` | 18 | 250 |

### Ready-to-Add (pre-registered)
| League | Array | Helper | Command |
|--------|-------|--------|---------|
| Segunda División | `SEGUNDA_TEAMS` | `sgp` | `csv_to_league.py ... data/segunda.js SEGUNDA_TEAMS sgp` |
| 2. Bundesliga | `ZWEITE_LIGA_TEAMS` | `blp` | `csv_to_league.py ... data/zweiteLiga.js ZWEITE_LIGA_TEAMS blp` |
| Serie B | `SERIE_B_TEAMS` | `sbp` | `csv_to_league.py ... data/serieB.js SERIE_B_TEAMS sbp` |
| Ligue 2 | `LIGUE_2_TEAMS` | `l2fp` | `csv_to_league.py ... data/ligue2.js LIGUE_2_TEAMS l2fp` |

### Rating Guide
| Tier | Typical range |
|------|--------------|
| PL elite (City, Arsenal) | 85–95 |
| PL mid | 75–85 |
| PL lower / Champ top | 70–80 |
| Championship mid | 65–75 |
| Championship lower | 60–72 |
| League One top | 65–78 |
| League One mid | 58–72 |
| League One lower | 52–66 |
| League Two top | 56–70 |
| League Two mid | 50–66 |
| League Two lower | 44–60 |

GK: `goalkeeping` 72–95; `attack/midfield/defence` always 10–20.

---

## Data Accuracy Policy
Always use 2025/26 season data. Sources: Transfermarkt, ESPN squad pages, Wikipedia season articles.
- Reflect all transfers including January 2026 window
- Ages calculated from DOB as of August 2025
- Budgets/reputations match real-world standing
- **❌ Forbidden:** outdated squads · fictional players · Championship players rated at PL levels · ignoring loans/January transfers

---

## Anti-Patterns

**Architecture:** skip `build.py` · rewrite whole module when `str_replace` works · add features without `validate.js` checks · rename functions without `RENAMES` in `build.py` · reorder modules

**Event queue:** re-introduce `processCupRounds()` / `finaliseGW()` · simulate cups silently in `advanceOneFixture` · advance GW before `pendingEvents` is empty

**UI modals:** `showModal()` from `watchmatch.js` · `showModal()` inside another `showModal()` · `position:absolute` inside `.modal-xl` (use `_openInlinePanel()`) · formation picker in pre-match

**Match engine:** different drain rates in `simulateMatch` vs `simulateMatchSegment` · GK weight ≠ 0 · cross-position GK subs · filter ALL GKs from bench · pass `homePlayers`/`awayPlayers` positionally

**Cups:** super cups in `LEAGUE_DOMESTIC_CUPS` · `resetCups()` on season rollover · European/invitation cups with zero activity · `buildInitialCupState` without `userTeamId` · domestic cup opponents from wrong league

**Data:** homeScorers/awayScorers concatenated into one array · `selectEleven()` without `save.lineup` for user · hand-edit generated JS files (edit CSVs, re-run converter)

**Fixtures/scheduling:** shuffle second-half independently · European finals within GW 1–38 · use `save.totalGameweeks` directly (use `getEffectiveTotalGW(save)`) · show "❌ Out" for 1st leg losses (use "❌ Lost")

**Promotion:** auto-promote 3 teams · skip playoffs for English lower leagues · run playoffs for non-English leagues · forget to update team leagues in DB · forget to simulate non-user standings

---

## Validation Suite
1190 checks across 21 sections + section 22 (Mentality) + 11 regression suites. Key coverage:
- All 13 `CUP_META` entries · European finals post-season (GW > 38) · `getEffectiveTotalGW` cases
- `LEAGUE_DOMESTIC_CUPS` per nation · `INVITATION_ONLY_CUPS` present · `assignCups` never adds super cups
- Transfer filter state · `getMentalityMods` values · `simulateMatch` mentality params · mentality UI elements
- Goal attribution · GK bench · fitness drain · HOME/AWAY labels · player development · save export/import
- Promotion/relegation/playoffs: `getLeagueOutcome24`, `runPlayoffs`, semi/final structure, all 24 positions, multi-tier, UI
- Fixture generation: mirrored double round-robin, zero back-to-back violations, H/A balance

**Policy: 0 failures required before shipping.**

---

## Open Issues

**Pending:**
- [ ] Player morale system
- [ ] Two-legged UCL knockout ties (currently single-leg + AET/pens)
- [ ] Player injury generation (fields exist, always false)
- [ ] News feed / inbox for transfers, cup draws
- [ ] Manager reputation / difficulty tiers
- [ ] Watch Match: player ratings on fitness list
- [ ] Watch Match: tactical instructions mid-match (live mentality change)
- [ ] Super cups awarded automatically on league/cup win
- [ ] Segunda División / 2. Bundesliga / Serie B / Ligue 2 data

**Completed this version (v3.5):** Promotion/relegation full English pyramid · playoff system (Poisson, away goals, 2-leg semis) · non-user league simulation · end-of-season modal with full playoff results · reputation changes by destination · League One + League Two + Eredivisie data via CSV pipeline · aging/decline/retirement system · 4-factor valuation model · slider-based counter offers (buy + sell) · wonderkid tax · advanced transfer filters · mentality system (4 modes, full wiring) · xG fix · European cup visibility fix · correct domestic cups per nation · super cups invitation-only · season rollover `buildInitialCupState` · fixture mirroring + back-to-back elimination · European finals post-season + `getEffectiveTotalGW` · save export/import (base64 + integrity hash) · potential system (all participants develop, position-specific boosts) · modal z-index fixes · Watch Match inline panel architecture
