# PITCH — Football Career Simulator

A single-file football career manager built with vanilla JS, CSS, and IndexedDB. No framework, no runtime bundler — just one HTML file you open in a browser.

## Features

- **5 leagues** — Premier League, La Liga, Bundesliga, Serie A, Ligue 1 (100+ clubs)
- **Correct national cups** — FA Cup, Copa del Rey, DFB-Pokal, Coppa Italia, Coupe de France
- **European football** — Champions League (league phase + knockouts), Europa League, Conference League
- **Mentality system** — choose Defensive, Balanced, Possession, or Attacking; affects goals, shots, possession and how exposed you are to counter-attacks
- **Transfer market** — advanced filtering by position, league, age, rating, potential, price; offer slider with acceptance likelihood
- **Watch Match** — live tick-by-tick simulation with substitutions, formation changes, speed controls
- **Tactics** — lineup builder, 7 formations, click-to-swap pitch slots, mentality picker
- **Squad management** — potential stars, transfer listing, fitness tracking
- **Youth academy** — tiered intake by club reputation, wonderkid system, promote/release
- **Season rollover** — promotion/relegation, prize money, aging, cup reallocation by league position
- **Honours cabinet** — real historical tallies + in-save wins, localised per nation

## Getting Started

1. Download `index.html` from [Releases](../../releases)
2. Open in any modern browser (Chrome / Firefox / Safari / Edge)
3. Choose your club — works offline, saves to browser IndexedDB

## Development

Source lives in `/pitch2/`. The build system concatenates 22 JS modules into a single HTML file.

```bash
# Build
python3 /home/claude/pitch2/build.py

# Output
/mnt/user-data/outputs/index.html
```

See [`BRIEFING.md`](pitch2/BRIEFING.md) for full architecture documentation, invariants, and anti-patterns.

### Tech Stack

- **Vanilla JS** — no framework, no dependencies
- **IndexedDB** — persistent game state via a thin async wrapper (`modules/db.js`)
- **CSS custom properties** — dark theme design tokens, responsive layout
- **build.py** — Python concatenation pipeline with JS syntax validation
- **validate.js** — 950 automated checks run on every build

## Version History

| Version | Highlights |
|---|---|
| v3.3 | Mentality system (Defensive/Balanced/Possession/Attacking), xG fix, European cups visible on enrolment |
| v3.2 | National cups per league, super cup fix, advanced transfer filters, honour cabinet localisation |
| v3.1 | Token-optimised source, multi-league support, Watch Match live viewer |
| v3.0 | Multi-season, cups, potential system, youth academy |
