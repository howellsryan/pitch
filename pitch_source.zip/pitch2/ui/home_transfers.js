// ══════════════════════════════════════════════════════════════
// HOME SCREEN
// ══════════════════════════════════════════════════════════════
async function renderHome(){
  const save=await getSave(), team=await getTeam(save.userTeamId);
  const players=await getPlayersByTeam(save.userTeamId);
  const allTeams=await getAllTeams(), byId=new Map(allTeams.map(t=>[t.id,t]));
  const [prev,next,slice]=await Promise.all([
    getLastResultForTeam(save.userTeamId),
    getNextFixtureForTeam(save.userTeamId),
    getTableSliceAroundTeam(save.userTeamId,2),
  ]);
  const dateEl=document.getElementById('h-date');
  if(dateEl) dateEl.textContent=fmt.date(save.currentDate);
  const seasonEl=document.getElementById('h-season');
  if(seasonEl) seasonEl.textContent=`Season ${save.season}`;
  // Update sidebar avatar initials
  const mgrName = save.managerName || 'The Manager';
  const mgrInitials = mgrName.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
  const mgrAvEl = document.getElementById('mgr-av');
  if(mgrAvEl) mgrAvEl.textContent = mgrInitials;
  const heroEl=document.getElementById('h-hero');
  if(heroEl&&team) heroEl.innerHTML=`
    <div class="hero-crest">${team.crest}</div>
    <div class="hero-info">
      <div class="hero-name">${team.name}</div>
      <div class="hero-sub">
        <span>${team.league||'Premier League'}</span><span class="hero-dot"></span>
        <span>${team.stadium||''}</span>
      </div>
    </div>
    <div class="mgr-card"><div class="mgr-lbl">Manager</div><div class="mgr-name">${mgrName}</div><div class="mgr-since">Season ${save.season}</div></div>`;
  const prevEl=document.getElementById('h-prev');
  if(prevEl){
    if(!prev){prevEl.innerHTML=`<div class="mc-lbl">Previous Result</div><div class="no-data">No matches played yet</div>`;}
    else{
      const ht=byId.get(prev.homeTeamId),at=byId.get(prev.awayTeamId);
      const isHome=prev.homeTeamId===save.userTeamId;
      const ug=isHome?prev.homeGoals:prev.awayGoals,og=isHome?prev.awayGoals:prev.homeGoals;
      const cls=ug>og?'win':ug<og?'loss':'';
      const hs=(prev.homeScorers||[]).map(s=>`${s.playerName||''} ${s.minute}'`).join(', ');
      const as=(prev.awayScorers||[]).map(s=>`${s.playerName||''} ${s.minute}'`).join(', ');
      prevEl.innerHTML=`<div class="mc-lbl">Previous Result</div>
        <div class="mc-fix"><div class="mc-team">${ht?.name||prev.homeTeamId}</div>
        <div class="mc-score ${cls}">${prev.homeGoals}-${prev.awayGoals}</div>
        <div class="mc-team aw">${at?.name||prev.awayTeamId}</div></div>
        <div class="mc-meta"><div class="mc-comp"><span class="mc-dot"></span>GW${prev.gameweek}</div><div>${fmt.dateShort(prev.date)}</div></div>
        ${hs||as?`<div class="mc-scorers"><div>${hs}</div><div class="aw">${as}</div></div>`:''}`;
    }
  }
  const nextEl=document.getElementById('h-next');
  if(nextEl){
    if(!next){nextEl.innerHTML=`<div class="mc-lbl">Next Fixture</div><div class="no-data" style="color:var(--acc2)">Season Complete!</div>`;}
    else{
      const ht=byId.get(next.homeTeamId),at=byId.get(next.awayTeamId);
      nextEl.innerHTML=`<div class="mc-lbl">Next Fixture</div>
        <div class="mc-fix"><div class="mc-team">${ht?.name||next.homeTeamId}</div>
        <div class="mc-score vs">vs</div><div class="mc-team aw">${at?.name||next.awayTeamId}</div></div>
        <div class="mc-meta"><div class="mc-comp"><span class="mc-dot" style="background:var(--acc2)"></span>GW${next.gameweek}</div><div>${fmt.dateShort(next.date)}</div></div>`;
    }
  }
  const tblEl=document.getElementById('h-table');
  if(tblEl) tblEl.innerHTML=slice.map(r=>`
    <div class="tbl-row ${r.isUserTeam?'hl':''}">
      <div class="rc">${r.displayPosition||r.position}</div>
      <div class="tc">${r.teamName}</div>
      <div class="sc">${r.won}</div><div class="sc">${r.drawn}</div><div class="sc">${r.lost}</div>
      <div class="pc">${r.points}</div>
    </div>`).join('');
  const statsEl=document.getElementById('h-stats');
  if(statsEl) statsEl.innerHTML=`
    <div class="stat-card"><div class="sl">Gameweek</div><div class="sv" style="color:var(--acc)">${save.currentGameweek}</div><div class="ss">of ${getEffectiveTotalGW(save)}</div></div>
    <div class="stat-card"><div class="sl">Budget</div><div class="sv" style="color:#7c83e8">${fmt.money(team?.budget||0)}</div><div class="ss">Transfer funds</div></div>
    <div class="stat-card"><div class="sl">Squad</div><div class="sv" style="color:var(--acc2)">${players.length}</div><div class="ss">players</div></div>
    <div class="stat-card"><div class="sl">Season</div><div class="sv" style="color:var(--acc3)">${save.season}</div><div class="ss">${team?.league||'League'}</div></div>`;
  const formEl=document.getElementById('h-form'),myRow=slice.find(r=>r.isUserTeam);
  if(formEl){
    const form=myRow?.form||[];
    const pills=form.length?form.map(r=>`<div class="fp ${r}">${r}</div>`).join(''):`<span style="color:var(--txd);font-size:12px">No matches played</span>`;
    const wr=myRow?.played>0?myRow.won/myRow.played:0;
    const mt=wr>0.7?'Excellent':wr>0.5?'High':wr>0.35?'Good':myRow?.played>0?'Low':'Neutral';
    const mp=Math.min(100,myRow?.points?myRow.points*3:50);
    formEl.innerHTML=`<div class="fr-title">Recent Form</div><div class="fr-pills">${pills}</div><div class="fr-spc"></div>
      <div class="morale-blk"><div class="morale-lbl">Morale</div>
      <div class="morale-w"><div class="morale-bar" style="width:${mp}%"></div></div>
      <div class="morale-txt">${mt}</div></div>`;
  }
  await renderCharts();
  const isEnd=save.currentGameweek>getEffectiveTotalGW(save);

  // Wire the VISIBLE header buttons (btn-adv-header / btn-eoy-header)
  const hdrPlay = document.getElementById('btn-adv-header');
  const hdrEOY  = document.getElementById('btn-eoy-header');
  if (hdrPlay) {
    hdrPlay.disabled = false;
    hdrPlay.onclick  = null;
    hdrPlay.style.display = isEnd ? 'none' : 'flex';
    if (!isEnd) hdrPlay.onclick = () => showPreMatchModal();
  }
  if (hdrEOY) {
    hdrEOY.disabled = false;
    hdrEOY.onclick  = null;
    hdrEOY.style.display = isEnd ? 'flex' : 'none';
    if (isEnd) hdrEOY.onclick = handleEndOfSeason;
  }

  // Keep hidden fallback buttons (used by some paths) in sync too
  const advBtn = document.getElementById('btn-adv');
  const eoyBtn = document.getElementById('btn-eoy');
  if (advBtn) { advBtn.disabled=false; advBtn.onclick=null; if(!isEnd) advBtn.onclick=()=>showPreMatchModal(); }
  if (eoyBtn) { eoyBtn.disabled=false; eoyBtn.onclick=null; if(isEnd)  eoyBtn.onclick=handleEndOfSeason; }
}

async function renderCharts(){
  const el=document.getElementById('h-charts');
  if(!el) return;
  const all=await getAllPlayers();
  const sc=[...all].filter(p=>(p.goals||0)>0).sort((a,b)=>b.goals-a.goals).slice(0,7);
  const as=[...all].filter(p=>(p.assists||0)>0).sort((a,b)=>b.assists-a.assists).slice(0,7);
  const maxG=sc[0]?.goals||1, maxA=as[0]?.assists||1;
  const bars=(arr,attr,color,max)=>arr.length
    ?arr.map(p=>`<div class="cbl-row"><div class="cbl-name">${p.name}</div><div class="cbl-bw"><div class="cbl-b" style="width:${Math.round((p[attr]/max)*100)}%;background:${color}"></div></div><div class="cbl-v">${p[attr]}</div></div>`).join('')
    :`<div class="no-data" style="padding:10px;font-size:11px">Play matches to see stats</div>`;
  el.innerHTML=`
    <div class="chart-card"><div class="chart-title">⚽ Top Scorers</div><div class="cbl">${bars(sc,'goals','linear-gradient(90deg,var(--acc),#7fff9a)',maxG)}</div></div>
    <div class="chart-card"><div class="chart-title">🎯 Top Assists</div><div class="cbl">${bars(as,'assists','linear-gradient(90deg,#7c83e8,#b8bcf7)',maxA)}</div></div>`;
}

// ── SIMULATE ONE FIXTURE
// handleAdvanceOneFixture is defined in prematch.js
async function _handleAdvanceOneFixtureStub(){
  const btn=document.getElementById('btn-adv');
  if(!btn||btn.disabled) return;
  const save=await getSave();
  btn.disabled=true; btn.textContent='Simulating…';
  showLoader('Simulating match…');
  try{
    const res=await advanceOneFixture();
    hideLoader();
    if(res.finished){await renderHome();return;}
    const r=res.singleResult;
    if(r) showMatchReport(r,save);
    if(res.cupResults?.length){
      for(const cr of res.cupResults){
        if(cr.isUCLMatchday){
          toast(`⭐ UCL MD${cr.matchday}: ${cr.result} vs ${cr.opponentName} (${cr.userGoals}-${cr.oppGoals}) +${cr.points}pts`,cr.result==='W'?'success':cr.result==='D'?'info':'error',6000);
        } else if(!cr.eliminated){
          const meta=CUP_META[cr.cupId];
          const isFirstLeg=(cr.roundName||'').includes('1st leg');
          const lossLabel=isFirstLeg?'❌ Lost':'❌ Out';
          toast(`${meta?.icon||'🏆'} ${meta?.name} ${cr.roundName}: ${cr.userWon?'✅ Won':lossLabel} vs ${cr.opponentName} (${cr.userGoals}-${cr.oppGoals})`,cr.userWon?'success':'error',6000);
        }
      }
    }
    await renderHome();
  }catch(err){
    hideLoader(); toast(`Error: ${err.message}`,'error'); console.error(err);
    btn.disabled=false;
    const sv=await getSave();
    btn.textContent=`▶ Play My Match (GW ${sv.currentGameweek})`;
  }
}

// ── MATCH REPORT
// Layout: HOME team always on LEFT, AWAY always on RIGHT (real football convention)
// User's team highlighted. Stats bar: home=left/green, away=right/red.
function showMatchReport(r,save){
  const isHome = r.homeTeamId === save.userTeamId;
  const userResult = r.homeTeamId===save.userTeamId
    ? (r.homeGoals>r.awayGoals?'WIN':r.homeGoals<r.awayGoals?'LOSS':'DRAW')
    : (r.awayGoals>r.homeGoals?'WIN':r.awayGoals<r.homeGoals?'LOSS':'DRAW');
  const resCol = userResult==='WIN'?'var(--acc)':userResult==='LOSS'?'var(--acc3)':'var(--acc2)';

  // Always home on left, away on right
  const hCrest = r.homeTeamCrest || '⚽';
  const aCrest = r.awayTeamCrest || '⚽';
  const hName  = r.homeTeamName;
  const aName  = r.awayTeamName;
  const hG = r.homeGoals, aG = r.awayGoals;
  const hScorers = r.homeScorers || [];
  const aScorers = r.awayScorers || [];

  const s  = r.stats || {};
  const P  = s.possession    || {home:50,away:50};
  const S  = s.shots         || {home:0,away:0};
  const OT = s.shotsOnTarget || {home:0,away:0};
  const XG = s.xG            || {home:0,away:0};
  const YC = s.yellowCards   || {home:0,away:0};
  const FL = s.fouls         || {home:0,away:0};
  const CO = s.corners       || {home:0,away:0};

  const isUserHome = r.homeTeamId === save.userTeamId;
  const evts = (r.events||[]).sort((a,b)=>a.minute-b.minute);
  const userSubs = evts.filter(e=>e.type==='sub'&&e.teamId===save.userTeamId);

  // Score row badges: show goal scorers under each team
  const scorerBadges = (arr, teamId) => arr.length
    ? arr.map(e=>`<div class="mr-scorer">⚽ <strong>${e.playerName||'?'}</strong> <span style="color:var(--txd)">${e.minute}'</span>${e.assistName?` <span style="opacity:.55;font-size:10px">▸${e.assistName}</span>`:''}</div>`).join('')
    : '';

  // Timeline shows all goal/card events, user events highlighted
  const timeline = evts.filter(e=>e.type==='goal'||e.type==='yellow').map(e=>{
    const isU = e.teamId===save.userTeamId;
    const isH = e.teamId===r.homeTeamId;
    return`<div class="mr-ev ${isU?'mr-ev-us':'mr-ev-op'}" style="align-self:${isH?'flex-start':'flex-end'}">
      ${isH?`<span class="mr-ev-min">${e.minute}'</span>`:''}<span>${e.type==='goal'?'⚽':'🟨'}</span><span class="mr-ev-nm">${e.playerName||'?'}</span>${!isH?`<span class="mr-ev-min">${e.minute}'</span>`:''}
    </div>`;
  }).join('');

  // Stat rows: home stat on LEFT, label in centre, away stat on RIGHT
  const sr = (lbl, hv, av, bar=true) => {
    const tot = (parseFloat(hv)||0)+(parseFloat(av)||0)||1;
    const hp  = Math.round(((parseFloat(hv)||0)/tot)*100);
    const userHighH = isUserHome ? 'color:var(--acc)' : '';
    const userHighA = !isUserHome ? 'color:var(--acc)' : '';
    return`<div class="mr-sr">
      <span class="mr-sv" style="${userHighH}">${hv}</span>
      <div class="mr-sm">
        <span class="mr-sl">${lbl}</span>
        ${bar?`<div class="mr-bw"><div class="mr-bu" style="width:${hp}%"></div><div class="mr-bo" style="width:${100-hp}%"></div></div>`:''}
      </div>
      <span class="mr-sv" style="${userHighA}">${av}</span>
    </div>`;
  };

  // Home/away indicator with user highlight
  const hIsUser = r.homeTeamId===save.userTeamId;
  const aIsUser = r.awayTeamId===save.userTeamId;
  const hBorder = hIsUser?'border-bottom:2px solid var(--acc)':'';
  const aBorder = aIsUser?'border-bottom:2px solid var(--acc)':'';

  showModal(`GW${r.gameweek||''} Match Report`,`
    <div class="mr-wrap">
      <div class="mr-header">
        <div class="mr-side" style="padding-bottom:6px;${hBorder}">
          <div class="mr-crest">${hCrest}</div>
          <div class="mr-tname" style="${hIsUser?'color:var(--acc)':''}">${hName}</div>
          <div style="font-size:10px;color:var(--txd);font-family:var(--fm);margin-bottom:4px">HOME</div>
          <div class="mr-scorers">${scorerBadges(hScorers)}</div>
        </div>
        <div class="mr-centre">
          <div class="mr-result" style="color:${resCol}">${userResult}</div>
          <div class="mr-score">${hG}<span style="opacity:.35;margin:0 8px">–</span>${aG}</div>
        </div>
        <div class="mr-side mr-side-r" style="padding-bottom:6px;${aBorder}">
          <div class="mr-crest">${aCrest}</div>
          <div class="mr-tname" style="${aIsUser?'color:var(--acc)':''}">${aName}</div>
          <div style="font-size:10px;color:var(--txd);font-family:var(--fm);margin-bottom:4px">AWAY</div>
          <div class="mr-scorers">${scorerBadges(aScorers)}</div>
        </div>
      </div>
      ${timeline?`<div class="mr-timeline" style="flex-direction:column;gap:4px">${timeline}</div>`:''}
      <div class="mr-stats-lbl" style="display:flex;justify-content:space-between;font-size:10px;color:var(--txd);font-family:var(--fm);padding:0 2px;margin-bottom:2px">
        <span>${hName.split(' ')[0]}</span><span>${aName.split(' ')[0]}</span>
      </div>
      <div class="mr-stats-grid">
        ${sr('Possession %',P.home,P.away)}
        ${sr('Shots',S.home,S.away)}
        ${sr('On Target',OT.home,OT.away)}
        ${sr('xG',typeof XG.home==='number'?XG.home.toFixed(2):XG.home, typeof XG.away==='number'?XG.away.toFixed(2):XG.away,false)}
        ${sr('Corners',CO.home,CO.away)}
        ${sr('Fouls',FL.home,FL.away)}
        ${sr('Yellow Cards',YC.home,YC.away)}
      </div>
      ${userSubs.length?`<div class="mr-subs"><div class="mr-subs-title">🔄 Your Substitutions</div>${userSubs.map(s=>`<div class="mr-sub">↑ <strong>${s.inName}</strong> ↓ ${s.outName} <span style="color:var(--txd)">(${s.minute}')</span></div>`).join('')}</div>`:''}
    </div>`,
    [{id:'close',label:'Continue →',cls:'btn-p'}]
  );
}

// ── END OF SEASON
async function handleEndOfSeason(){
  const btn=document.getElementById('btn-eoy');
  if(btn) btn.disabled=true;
  showLoader('Processing end of season…');
  try{
    const {summary,leagueWinner,newSave,prizeMoney,leagueChanges}=await processEndOfSeason();
    hideLoader();
    const trophies=[];
    if(leagueWinner?.teamId===newSave.userTeamId) trophies.push('🏆 League Champions!');
    if(summary.cups) for(const[cid,st]of Object.entries(summary.cups)){
      if(st.status==='winner') trophies.push(`${CUP_META[cid]?.icon||'🏆'} ${CUP_META[cid]?.name||cid} Winners!`);
    }
    const tHtml=trophies.length?`<div style="background:rgba(245,200,66,.1);border:1px solid rgba(245,200,66,.3);border-radius:8px;padding:12px;margin-bottom:12px">${trophies.map(t=>`<div style="color:var(--acc2);font-size:14px;font-weight:600">${t}</div>`).join('')}</div>`:'';
    const ord=n=>n+(['st','nd','rd'][n-1]||'th');

    // Build league changes HTML (promotion/relegation/playoffs)
    let lcHtml='';
    if(leagueChanges){
      const uri=leagueChanges.userRelInfo||{};
      if(uri.promoted&&uri.promotedViaPlayoff){
        lcHtml+=`<div style="background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.3);border-radius:8px;padding:10px;margin-bottom:8px">
          <div style="font-size:13px;font-weight:700;color:#3b82f6">🎉 PROMOTED via Play-offs!</div>
          <div style="font-size:11px;color:var(--tx2);margin-top:4px">Your team won the play-off final and earned promotion!</div>
        </div>`;
      } else if(uri.promoted){
        lcHtml+=`<div style="background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.3);border-radius:8px;padding:10px;margin-bottom:8px">
          <div style="font-size:13px;font-weight:700;color:#3b82f6">⬆️ PROMOTED! Automatic promotion secured!</div>
        </div>`;
      } else if(uri.relegated){
        lcHtml+=`<div style="background:rgba(232,72,85,.1);border:1px solid rgba(232,72,85,.3);border-radius:8px;padding:10px;margin-bottom:8px">
          <div style="font-size:13px;font-weight:700;color:var(--acc3)">⬇️ RELEGATED</div>
          <div style="font-size:11px;color:var(--tx2);margin-top:4px">Your team has been relegated to the division below.</div>
        </div>`;
      }

      // Show playoff results for the user's league
      const userLeague=summary.userLeague||(await getSave())?.userLeague||'';
      const po=leagueChanges.playoffResults?.[userLeague];
      if(po){
        const sf1=po.semi1, sf2=po.semi2, fin=po.final;
        lcHtml+=`<div style="background:var(--sur2);border:1px solid var(--bdr);border-radius:8px;padding:10px;margin-bottom:8px">
          <div style="font-size:12px;font-weight:700;color:var(--tx);margin-bottom:6px">🏟️ Play-off Results</div>
          <div style="font-size:11px;color:var(--tx2);margin-bottom:4px"><strong>Semi-Final 1:</strong> ${sf1.team1.name} vs ${sf1.team2.name}</div>
          <div style="font-size:10px;color:var(--txd);margin-bottom:2px;padding-left:8px">Leg 1: ${sf1.team1.name} ${sf1.leg1.home}-${sf1.leg1.away} ${sf1.team2.name}</div>
          <div style="font-size:10px;color:var(--txd);margin-bottom:4px;padding-left:8px">Leg 2: ${sf1.team2.name} ${sf1.leg2.home}-${sf1.leg2.away} ${sf1.team1.name} (Agg: ${sf1.agg.team1}-${sf1.agg.team2}${sf1.penalties?' pens':''})</div>
          <div style="font-size:11px;color:var(--tx2);margin-bottom:4px"><strong>Semi-Final 2:</strong> ${sf2.team1.name} vs ${sf2.team2.name}</div>
          <div style="font-size:10px;color:var(--txd);margin-bottom:2px;padding-left:8px">Leg 1: ${sf2.team1.name} ${sf2.leg1.home}-${sf2.leg1.away} ${sf2.team2.name}</div>
          <div style="font-size:10px;color:var(--txd);margin-bottom:4px;padding-left:8px">Leg 2: ${sf2.team2.name} ${sf2.leg2.home}-${sf2.leg2.away} ${sf2.team1.name} (Agg: ${sf2.agg.team1}-${sf2.agg.team2}${sf2.penalties?' pens':''})</div>
          <div style="font-size:11px;color:var(--acc);margin-top:4px"><strong>Final:</strong> ${fin.team1.name} ${fin.score.team1}-${fin.score.team2} ${fin.team2.name}${fin.penalties?' (pens)':''}</div>
          <div style="font-size:11px;color:#3b82f6;font-weight:600;margin-top:4px">🏆 ${(fin.winnerId===fin.team1.id?fin.team1.name:fin.team2.name)} promoted!</div>
        </div>`;
      }

      // Show movements summary
      const mvs=(leagueChanges.movements||[]).filter(m=>m.teamId!==newSave.userTeamId);
      if(mvs.length>0){
        const promos=mvs.filter(m=>m.reason.includes('Promoted')||m.reason.includes('Playoff'));
        const rels=mvs.filter(m=>m.reason==='Relegated');
        let mvHtml='';
        if(promos.length) mvHtml+=`<div style="margin-bottom:4px"><span style="color:#3b82f6;font-weight:600;font-size:10px">⬆️ PROMOTED:</span> <span style="font-size:10px;color:var(--tx2)">${promos.map(m=>{const allT=typeof getAllTeams==='function';return m.teamId;}).join(', ')}</span></div>`;
        if(rels.length) mvHtml+=`<div><span style="color:var(--acc3);font-weight:600;font-size:10px">⬇️ RELEGATED:</span> <span style="font-size:10px;color:var(--tx2)">${rels.map(m=>m.teamId).join(', ')}</span></div>`;
        if(mvHtml) lcHtml+=`<div style="background:var(--sur2);border:1px solid var(--bdr);border-radius:8px;padding:8px;margin-bottom:8px">${mvHtml}</div>`;
      }
    }

    showModal('Season Complete! 🎉',`<div>${tHtml}
      <div style="font-size:13px;color:var(--tx2);margin-bottom:8px">Finished <strong style="color:var(--tx)">${ord(summary.userFinish)}</strong> in the league.</div>
      ${prizeMoney?`<div style="font-size:13px;color:var(--acc);margin-bottom:8px">💰 Prize money: <strong>${fmt.money(prizeMoney)}</strong></div>`:''}
      ${lcHtml}
      ${summary.retirements&&summary.retirements.length?`<div style="background:rgba(232,72,85,.08);border:1px solid rgba(232,72,85,.2);border-radius:8px;padding:10px;margin-bottom:8px">
        <div style="font-size:12px;font-weight:600;color:var(--acc3);margin-bottom:4px">👋 Retirements</div>
        ${summary.retirements.map(r=>`<div style="font-size:12px;color:var(--tx2)">${r.name} (${r.position}, ${r.age}) has retired</div>`).join('')}
      </div>`:''}
      <div style="font-size:12px;color:var(--tx2)">All players aged +1 year. New season fixtures generated.</div>
    </div>`,
    [{id:'ok',label:'Start Next Season →',cls:'btn-p',handler:async()=>{await renderHome();}}]);
    if(typeof renderSettings==='function') renderSettings().catch(()=>{});
  }catch(err){
    hideLoader(); toast(`Error: ${err.message}`,'error'); console.error(err);
    const b=document.getElementById('btn-eoy'); if(b) b.disabled=false;
  }
}

// ── TRANSFERS
let _buyTargets=[],_selPid=null;
// Active filter state
const _trFilters = {
  pos:'ALL', league:'ALL', sort:'rating',
  minAge:15, maxAge:40, minRat:40, maxRat:99,
  maxPrice:0, // 0 = no limit
  minPot:1,   // 1-5 stars
  query:'',
  affordable: false,
};

async function renderTransfers(){
  const save=await getSave(), team=await getTeam(save.userTeamId);
  const allTeams=await getAllTeams(), byId=new Map(allTeams.map(t=>[t.id,t]));
  const bh=document.getElementById('tr-budget-hdr');
  if(bh&&team) bh.innerHTML=`<span style="display:flex;align-items:center;gap:8px"><span style="font-size:11px;color:var(--tx2)">Budget</span><span style="font-family:var(--fd);font-size:20px;color:var(--acc)">${fmt.money(team.budget)}</span></span>`;

  const allPl=await getAllPlayers();
  _buyTargets=allPl.filter(p=>p.teamId!==save.userTeamId&&p.teamId!=='free_agents');
  // Reset price ceiling to budget on first load
  _trFilters.maxPrice = team?.budget || 0;

  // Gather unique leagues from buy targets
  const leagueSet = [...new Set(allTeams.map(t=>t.league||'Premier League'))].sort();

  _renderAdvancedFilters(byId, team, leagueSet);
  _applyAndRenderBuyList(byId, team);
  await renderSellList(save.userTeamId);

  const tbBuy=document.getElementById('tt-buy'),tbSell=document.getElementById('tt-sell');
  const pBuy=document.getElementById('tp-buy'),pSell=document.getElementById('tp-sell');
  if(tbBuy) tbBuy.onclick=()=>{tbBuy.classList.add('on');tbSell.classList.remove('on');pBuy.classList.add('on');pSell.classList.remove('on')};
  if(tbSell) tbSell.onclick=()=>{tbSell.classList.add('on');tbBuy.classList.remove('on');pSell.classList.add('on');pBuy.classList.remove('on')};

  // Wire Offers button → opens modal
  const tbOffers=document.getElementById('tt-offers');
  if(tbOffers) tbOffers.onclick=()=>showOffersModal();
  // Update the badge count
  if(typeof _updateOffersBadge==='function') _updateOffersBadge();
}

function _renderAdvancedFilters(byId, team, leagueSet){
  // Position tabs
  document.querySelectorAll('#tr-filters .ftab').forEach(tab=>{
    tab.onclick=()=>{
      document.querySelectorAll('#tr-filters .ftab').forEach(t=>t.classList.remove('on'));
      tab.classList.add('on');
      _trFilters.pos=tab.dataset.f||'ALL';
      _applyAndRenderBuyList(byId, team);
    };
  });

  // Search
  const si=document.getElementById('tr-search');
  if(si){ si.oninput=()=>{ _trFilters.query=si.value.toLowerCase(); _applyAndRenderBuyList(byId, team); }; }

  // Build the advanced filter bar if not already built
  const buyPnl=document.getElementById('tp-buy');
  if(!buyPnl||buyPnl.querySelector('#tr-adv-bar')) return;

  const budget=team?.budget||200_000_000;
  const bar=document.createElement('div');
  bar.id='tr-adv-bar';
  bar.style.cssText='padding:8px 14px 10px;border-bottom:1px solid var(--bdr);display:flex;flex-direction:column;gap:7px;background:var(--sur2);flex-shrink:0';

  // Row 1: sort + affordable toggle + league
  const leagueOpts=['ALL',...leagueSet].map(l=>`<option value="${l}">${l==='ALL'?'All Leagues':l}</option>`).join('');
  const sortOpts=[
    ['rating','⭐ Rating'],['value','💰 Value'],['age','🎂 Age'],
    ['potential','✨ Potential'],['goals','⚽ Goals'],['assists','🎯 Assists'],
  ].map(([v,l])=>`<option value="${v}">${l}</option>`).join('');

  bar.innerHTML=`
    <div style="display:flex;gap:7px;flex-wrap:wrap;align-items:center">
      <label style="font-size:10px;color:var(--tx2);font-family:var(--fm);letter-spacing:.5px;white-space:nowrap">SORT</label>
      <select id="tr-sort" style="background:var(--sur3);border:1px solid var(--bdr);color:var(--tx);border-radius:5px;padding:3px 7px;font-size:11px;cursor:pointer;flex:1;min-width:100px">${sortOpts}</select>
      <select id="tr-league" style="background:var(--sur3);border:1px solid var(--bdr);color:var(--tx);border-radius:5px;padding:3px 7px;font-size:11px;cursor:pointer;flex:1;min-width:90px">${leagueOpts}</select>
      <button id="tr-affordable" class="ftab" style="padding:3px 10px;font-size:10px;white-space:nowrap" title="Only show players you can afford">💰 Affordable</button>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
      <div>
        <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--tx2);font-family:var(--fm);margin-bottom:3px">
          <span>AGE</span><span id="tr-age-lbl">${_trFilters.minAge}–${_trFilters.maxAge}</span>
        </div>
        <div style="display:flex;gap:5px;align-items:center">
          <input type="range" id="tr-age-min" min="15" max="40" value="${_trFilters.minAge}" style="flex:1">
          <input type="range" id="tr-age-max" min="15" max="40" value="${_trFilters.maxAge}" style="flex:1">
        </div>
      </div>
      <div>
        <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--tx2);font-family:var(--fm);margin-bottom:3px">
          <span>RATING</span><span id="tr-rat-lbl">${_trFilters.minRat}–${_trFilters.maxRat}</span>
        </div>
        <div style="display:flex;gap:5px;align-items:center">
          <input type="range" id="tr-rat-min" min="40" max="99" value="${_trFilters.minRat}" style="flex:1">
          <input type="range" id="tr-rat-max" min="40" max="99" value="${_trFilters.maxRat}" style="flex:1">
        </div>
      </div>
    </div>
    <div>
      <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--tx2);font-family:var(--fm);margin-bottom:3px">
        <span>MAX PRICE</span><span id="tr-price-lbl">${_trFilters.maxPrice>0?fmt.money(_trFilters.maxPrice):'No limit'}</span>
      </div>
      <input type="range" id="tr-price" min="0" max="${Math.round(budget*1.5/1e6)*1e6}" step="1000000" value="${Math.min(_trFilters.maxPrice||budget,Math.round(budget*1.5/1e6)*1e6)}" style="width:100%">
    </div>
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      <span style="font-size:10px;color:var(--tx2);font-family:var(--fm);letter-spacing:.5px">MIN POTENTIAL</span>
      <div style="display:flex;gap:4px" id="tr-pot-stars">
        ${[1,2,3,4,5].map(n=>`<button class="ftab ${n<=_trFilters.minPot?'on':''}" data-pot="${n}" style="padding:2px 7px;font-size:11px" title="${['Average','Good','Great','World Class','Legendary'][n-1]}">${'★'.repeat(n)}</button>`).join('')}
      </div>
      <button id="tr-reset" class="ftab" style="margin-left:auto;padding:3px 9px;font-size:10px;color:var(--acc3);border-color:rgba(232,72,85,.3)">↺ Reset</button>
    </div>`;

  // Insert before buy-list
  const buyList=buyPnl.querySelector('.pl-list');
  if(buyList) buyPnl.insertBefore(bar, buyList);

  // Wire controls
  const $ = id => document.getElementById(id);

  $('tr-sort').value=_trFilters.sort;
  $('tr-sort').onchange=()=>{ _trFilters.sort=$('tr-sort').value; _applyAndRenderBuyList(byId,team); };

  $('tr-league').onchange=()=>{ _trFilters.league=$('tr-league').value; _applyAndRenderBuyList(byId,team); };

  $('tr-affordable').onclick=()=>{
    _trFilters.affordable=!_trFilters.affordable;
    $('tr-affordable').classList.toggle('on',_trFilters.affordable);
    _applyAndRenderBuyList(byId,team);
  };

  const syncAge=()=>{
    let mn=parseInt($('tr-age-min').value), mx=parseInt($('tr-age-max').value);
    if(mn>mx){ const t=mn; mn=mx; mx=t; }
    _trFilters.minAge=mn; _trFilters.maxAge=mx;
    $('tr-age-lbl').textContent=`${mn}–${mx}`;
    _applyAndRenderBuyList(byId,team);
  };
  $('tr-age-min').oninput=$('tr-age-max').oninput=syncAge;

  const syncRat=()=>{
    let mn=parseInt($('tr-rat-min').value), mx=parseInt($('tr-rat-max').value);
    if(mn>mx){ const t=mn; mn=mx; mx=t; }
    _trFilters.minRat=mn; _trFilters.maxRat=mx;
    $('tr-rat-lbl').textContent=`${mn}–${mx}`;
    _applyAndRenderBuyList(byId,team);
  };
  $('tr-rat-min').oninput=$('tr-rat-max').oninput=syncRat;

  $('tr-price').oninput=()=>{
    const v=parseInt($('tr-price').value);
    _trFilters.maxPrice=v;
    $('tr-price-lbl').textContent=v>0?fmt.money(v):'No limit';
    _applyAndRenderBuyList(byId,team);
  };

  document.querySelectorAll('#tr-pot-stars [data-pot]').forEach(btn=>{
    btn.onclick=()=>{
      const n=parseInt(btn.dataset.pot);
      _trFilters.minPot=n;
      document.querySelectorAll('#tr-pot-stars [data-pot]').forEach(b=>b.classList.toggle('on',parseInt(b.dataset.pot)<=n));
      _applyAndRenderBuyList(byId,team);
    };
  });

  $('tr-reset').onclick=()=>{
    Object.assign(_trFilters,{pos:'ALL',league:'ALL',sort:'rating',minAge:15,maxAge:40,minRat:40,maxRat:99,maxPrice:budget,minPot:1,query:'',affordable:false});
    // Reset all controls
    $('tr-sort').value='rating';
    $('tr-league').value='ALL';
    $('tr-affordable').classList.remove('on');
    $('tr-age-min').value=15; $('tr-age-max').value=40; $('tr-age-lbl').textContent='15–40';
    $('tr-rat-min').value=40; $('tr-rat-max').value=99; $('tr-rat-lbl').textContent='40–99';
    $('tr-price').value=budget; $('tr-price-lbl').textContent=fmt.money(budget);
    document.querySelectorAll('#tr-filters .ftab').forEach(t=>t.classList.remove('on'));
    document.querySelector('#tr-filters .ftab')?.classList.add('on');
    document.querySelectorAll('#tr-pot-stars [data-pot]').forEach(b=>b.classList.toggle('on',parseInt(b.dataset.pot)<=1));
    const si=document.getElementById('tr-search'); if(si) si.value='';
    _applyAndRenderBuyList(byId,team);
  };
}

function _applyAndRenderBuyList(byId, team){
  const f=_trFilters;
  const allTeams=Array.from(byId.values());
  const leagueByTeam=new Map(allTeams.map(t=>[t.id, t.league||'Premier League']));
  const budget=team?.budget||0;

  let fil=[..._buyTargets];

  // Position filter
  if(f.pos!=='ALL') fil=fil.filter(p=>posGroup(p.position)===f.pos);
  // League filter
  if(f.league!=='ALL') fil=fil.filter(p=>leagueByTeam.get(p.teamId)===f.league);
  // Age filter
  fil=fil.filter(p=>(p.age||25)>=f.minAge&&(p.age||25)<=f.maxAge);
  // Rating filter
  fil=fil.filter(p=>primaryRating(p)>=f.minRat&&primaryRating(p)<=f.maxRat);
  // Price filter
  if(f.maxPrice>0) fil=fil.filter(p=>(formAdjustedValue?formAdjustedValue(p):p.value)<=f.maxPrice);
  // Affordable filter
  if(f.affordable) fil=fil.filter(p=>(formAdjustedValue?formAdjustedValue(p):p.value)*0.88<=budget);
  // Potential filter (stars >= minPot)
  if(f.minPot>1) fil=fil.filter(p=>getPotentialStars(p)>=f.minPot);
  // Text search
  if(f.query) fil=fil.filter(p=>p.name.toLowerCase().includes(f.query)||(byId.get(p.teamId)?.name||'').toLowerCase().includes(f.query));

  // Sort
  const sortFns={
    rating:(a,b)=>primaryRating(b)-primaryRating(a),
    value:(a,b)=>(formAdjustedValue?formAdjustedValue(b):b.value)-(formAdjustedValue?formAdjustedValue(a):a.value),
    age:(a,b)=>(a.age||25)-(b.age||25),
    potential:(a,b)=>getPotentialStars(b)-getPotentialStars(a),
    goals:(a,b)=>(b.goals||0)-(a.goals||0),
    assists:(a,b)=>(b.assists||0)-(a.assists||0),
  };
  fil.sort(sortFns[f.sort]||sortFns.rating);

  // Count badge
  const countEl=document.getElementById('tr-count');
  if(countEl) countEl.textContent=`${fil.length} player${fil.length!==1?'s':''}`;

  renderBuyList(byId, fil);
}

function renderBuyList(byId, filteredPlayers){
  const el=document.getElementById('buy-list');
  if(!el) return;
  if(!filteredPlayers.length){el.innerHTML=`<div class="no-data" style="padding:24px;text-align:center"><div style="font-size:24px;margin-bottom:8px">🔍</div>No players match your filters.<br><span style="font-size:11px;color:var(--txd)">Try adjusting the sliders above.</span></div>`;return;}
  el.innerHTML=filteredPlayers.slice(0,100).map(p=>{
    const g=posGroup(p.position),r=primaryRating(p);
    const teamRec=byId.get(p.teamId);
    const tn=teamRec?.name||'Unknown';
    const league=teamRec?.league||'';
    const shortName=teamRec?.shortName||tn.slice(0,3).toUpperCase();
    const leagueNation={'Premier League':'ENG','Championship':'ENG','League One':'ENG','League Two':'ENG','La Liga':'ESP','Bundesliga':'GER','Serie A':'ITA','Ligue 1':'FRA','Eredivisie':'NED'}[league]||'INT';
    const natFlag=playerNationality(p,league);
    const fv=formAdjustedValue?formAdjustedValue(p):p.value;
    const potStars=getPotentialStars?getPotentialStars(p):0;
    const potColor=['','#8a9ab0','#22c55e','#3b82f6','#f5c842','#e84855'][potStars]??'#8a9ab0';
    const potDisp=potStars?'★'.repeat(potStars):'';
    const tag=(txt,col='var(--sur3)')=>`<span style="background:${col};border:1px solid var(--bdr);padding:0 4px;border-radius:3px;font-size:9px;font-family:var(--fm);color:var(--tx2)">${txt}</span>`;
    return`<div class="pl-row ${p.id===_selPid?'sel':''}" data-pid="${p.id}">
      <div class="pl-av" style="font-size:18px;background:none;border:none">${natFlag}</div>
      <div class="pl-info">
        <div class="pl-name">${p.name}</div>
        <div class="pl-meta"><span class="pos ${g}">${p.position}</span>${tag(shortName)} ${tag(leagueNation)}<span>Age ${p.age}</span>${potDisp?`<span style="color:${potColor};font-size:10px">${potDisp}</span>`:''}</div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:2px;flex-shrink:0">
        <div class="pl-val">${fmt.money(fv)}</div>
        <div class="pl-rat" style="font-size:12px;background:none;color:var(--acc2)">${r}</div>
      </div>
    </div>`;
  }).join('');
  el.querySelectorAll('.pl-row').forEach(row=>{
    row.onclick=()=>{
      _selPid=row.dataset.pid;
      el.querySelectorAll('.pl-row').forEach(r=>r.classList.remove('sel'));
      row.classList.add('sel');
      const player=filteredPlayers.find(p=>p.id===_selPid);
      if(player){
        // On mobile show detail panel; on desktop open squad player modal
        if(window.innerWidth>=900){
          openSquadPlayerModal(player,[],null);
        } else {
          renderPlayerDetail(player,byId);
          document.getElementById('tr-layout')?.classList.add('dp-open');
        }
      }
    };
  });
}
async function renderPlayerDetail(player,byId){
  const el=document.getElementById('det-panel');
  if(!el) return;
  const _sv=await getSave();
  const _isCollapsed=(_sv.collapsedDeals||[]).includes(player.id);
  const teamRec=byId.get(player.teamId);
  const tn=teamRec?.name||'Unknown';
  const league=teamRec?.league||'';
  const teamShort=teamRec?.shortName||tn.slice(0,3).toUpperCase();
  const g=posGroup(player.position),r=primaryRating(player);
  const fv=formAdjustedValue?formAdjustedValue(player):player.value;
  const minOff=Math.floor(fv*0.88), initOff=Math.floor(fv*0.95);
  const fl=formLabel(player);
  const potStars=getPotentialStars?getPotentialStars(player):0;
  const potLabel=getPotentialLabel?getPotentialLabel(player):'';
  const potColor=['','#8a9ab0','#22c55e','#3b82f6','#f5c842','#e84855'][potStars]??'#8a9ab0';
  const potDisp=potStars?'★'.repeat(potStars)+'☆'.repeat(5-potStars):'';
  const isWonderkid=player.isWonderkid===true;
  const fitnessColor=(player.fitness??100)>=75?'var(--acc)':(player.fitness??100)>=50?'var(--acc2)':'var(--acc3)';

  const abar=(lbl,val,pri)=>{
    const pct=Math.round((val/99)*100);
    const col=pri?'linear-gradient(90deg,var(--acc),#7fff9a)':'linear-gradient(90deg,#4a6fa5,#6b8ccc)';
    return`<div>
      <div class="attr-n" style="${pri?'color:var(--acc)':''};">${lbl}</div>
      <div class="attr-bw"><div class="attr-b" style="width:${pct}%;background:${col}"></div></div>
      <div class="attr-v" style="${pri?'color:var(--acc)':''}">${val}</div>
    </div>`;
  };

  // Value comparison bar: form value vs base value
  const baseVal=player.value||fv;
  const valChange=fv-baseVal;
  const valPct=Math.round(Math.min(100,(fv/Math.max(fv,baseVal))*100));

  el.innerHTML=`
    <div class="det-hero">
      <div class="det-rat">${r}</div>
      <div class="det-av" style="font-size:28px;background:none;border:none">${playerNationality(player,league)}</div>
      <div class="det-name">${player.name}</div>
      ${isWonderkid?`<div style="background:linear-gradient(135deg,#f5c842,#f97316);color:#000;font-size:9px;font-weight:700;padding:2px 8px;border-radius:4px;letter-spacing:1.5px;font-family:var(--fm);margin:4px auto 0;display:inline-block">WONDERKID ⚡</div>`:''}
      <div class="det-info" style="margin-top:6px"><span style="background:var(--sur3);border:1px solid var(--bdr);padding:1px 5px;border-radius:3px;font-size:9px;font-family:var(--fm);color:var(--tx2)">${teamShort}</span><span>${tn}</span><span class="pos ${g}">${player.position}</span><span>Age ${player.age}</span></div>
      <div style="margin-top:8px;display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap">
        <span class="fb ${fl.cls}">${fl.text}</span>
        <span style="color:${fitnessColor};font-size:11px;font-family:var(--fm)">🏃 ${Math.round(player.fitness??100)}%</span>
        ${(player.goals||0)>0?`<span style="font-size:11px;color:var(--tx2)">⚽ ${player.goals}</span>`:''}
        ${(player.assists||0)>0?`<span style="font-size:11px;color:var(--tx2)">🎯 ${player.assists}</span>`:''}
        ${(player.cleanSheets||0)>0?`<span style="font-size:11px;color:var(--tx2)">🧤 ${player.cleanSheets}</span>`:''}
      </div>
    </div>

    <!-- Potential -->
    <div class="vrow" style="flex-direction:column;align-items:flex-start;gap:5px">
      <div style="display:flex;justify-content:space-between;width:100%">
        <span class="vlbl">✨ Potential</span>
        <span style="color:${potColor};font-family:var(--fm);font-size:12px;font-weight:700">${potLabel}</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px;width:100%">
        <div style="color:${potColor};font-size:18px;letter-spacing:2px">${potDisp}</div>
        <div style="flex:1;height:4px;background:var(--sur3);border-radius:2px;overflow:hidden">
          <div style="height:100%;width:${(potStars/5)*100}%;background:${potColor};border-radius:2px;transition:width .4s"></div>
        </div>
        <span style="font-family:var(--fm);font-size:10px;color:var(--txd)">${player.potentialRating??r}/99</span>
      </div>
    </div>

    <!-- Value -->
    <div class="vrow">
      <span class="vlbl">Form Value</span>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:2px">
        <span class="vamt">${fmt.money(fv)}</span>
        ${valChange!==0?`<span style="font-size:10px;color:${valChange>0?'var(--acc)':'var(--acc3)'};font-family:var(--fm)">${valChange>0?'+':''}${fmt.money(valChange)} vs base</span>`:''}
      </div>
    </div>
    <div class="vrow" style="border-top:none;padding-top:0">
      <span class="vlbl">Weekly Wage</span>
      <span class="vamt" style="font-size:14px;color:var(--tx2)">${fmt.wage(player.wage)}</span>
    </div>
    <div class="vrow" style="border-top:none;padding-top:0">
      <span class="vlbl">Annual Wage</span>
      <span style="font-size:12px;color:var(--txd);font-family:var(--fm)">${fmt.money((player.wage||0)*52)}/yr</span>
    </div>

    <!-- Attributes -->
    <div class="attr-grid">
      ${abar('Attack',player.attack,g==='ATT')}
      ${abar('Midfield',player.midfield,g==='MID')}
      ${abar('Defence',player.defence,g==='DEF')}
      ${abar('GK',player.goalkeeping,g==='GK')}
    </div>

    <!-- Offer -->
    ${_isCollapsed?`
    <div class="offer-sec" style="opacity:0.6">
      <div style="background:rgba(232,72,85,0.12);border:1px solid var(--acc3);border-radius:8px;padding:12px;text-align:center">
        <div style="font-size:13px;font-weight:700;color:var(--acc3);margin-bottom:4px">🚫 Deal Collapsed</div>
        <div style="font-size:11px;color:var(--tx2)">Negotiations broke down earlier this window. You cannot make another offer until the next transfer window.</div>
      </div>
    </div>
    <div class="tr-acts">
      <button class="btn btn-s" id="btn-det-back" style="display:none">← Back</button>
    </div>`:`
    <div class="offer-sec">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:7px">
        <div class="offer-lbl">Your Offer</div>
        <div style="font-size:10px;color:var(--txd);font-family:var(--fm)">Min ~${fmt.money(minOff)}</div>
      </div>
      <div class="offer-row">
        <input type="range" id="offer-slider" min="${Math.floor(minOff*0.7)}" max="${Math.floor(fv*1.6)}" value="${initOff}" step="500000">
        <div id="offer-val" class="offer-v">${fmt.money(initOff)}</div>
      </div>
      <div id="offer-likelihood" class="offer-hint" style="margin-top:5px;color:var(--acc)">Likely accepted ✓</div>
    </div>
    <div class="tr-acts">
      <button class="btn btn-p" id="btn-offer">Make Offer</button>
      <button class="btn btn-s" id="btn-det-back" style="display:none">← Back</button>
    </div>`}`;


  const back=el.querySelector('#btn-det-back');
  if(back&&window.innerWidth<=768){back.style.display='block';back.onclick=()=>document.getElementById('tr-layout')?.classList.remove('dp-open');}

  if(_isCollapsed) return; // No offer controls when deal collapsed

  const sl=document.getElementById('offer-slider'),dv=document.getElementById('offer-val'),lh=document.getElementById('offer-likelihood');
  const updateOfferHint=()=>{
    const v=Number(sl?.value||fv);
    if(dv) dv.textContent=fmt.money(v);
    if(!lh) return;
    if(v>=fv)          { lh.textContent='🤑 Over value — very likely accepted'; lh.style.color='var(--acc)'; }
    else if(v>=minOff) { lh.textContent='✓ Likely accepted'; lh.style.color='var(--acc)'; }
    else if(v>=minOff*0.88){ lh.textContent='⚠️ May be rejected'; lh.style.color='var(--acc2)'; }
    else               { lh.textContent='✕ Will be rejected'; lh.style.color='var(--acc3)'; }
  };
  if(sl){ sl.oninput=updateOfferHint; updateOfferHint(); }

  const ob=document.getElementById('btn-offer');
  if(ob) ob.onclick=()=>{
    const offer=Number(sl?.value||fv);
    showModal('Confirm Offer',`
      <div class="ctr">
        <div class="ctr-pl"><strong>${player.name}</strong><span class="pos ${g}">${player.position}</span></div>
        <div class="ctr-row"><span>From</span><strong>${teamShort} ${tn}</strong></div>
        <div class="ctr-row"><span>Age</span><strong>${player.age}</strong></div>
        <div class="ctr-row"><span>Rating</span><strong>${r}</strong></div>
        <div class="ctr-row"><span>Potential</span><strong style="color:${potColor}">${potLabel} ${potDisp}</strong></div>
        <div class="ctr-row"><span>Offer</span><strong style="color:var(--acc2)">${fmt.money(offer)}</strong></div>
        <div class="ctr-row"><span>Form Value</span><strong>${fmt.money(fv)}</strong></div>
        <div class="ctr-row"><span>Weekly Wage</span><strong>${fmt.wage(player.wage)}</strong></div>
        ${offer<minOff?`<div class="ctr-warn">⚠️ Below min ~${fmt.money(minOff)} — likely rejected</div>`:''}
      </div>`,
      [{id:'c',label:'Send Offer',cls:'btn-p',handler:async()=>{
        try{
          const cardEl=document.querySelector(`[data-pid="${player.id}"]`);
          if(cardEl) cardEl.closest('.pl-item,.pl-row')?.remove();
          await buyPlayer(player.id,offer);
          toast(`✅ ${player.name} signed for ${fmt.money(offer)}!`,'success',5000);
          _selPid=null; document.getElementById('tr-layout')?.classList.remove('dp-open');
          await renderTransfers();
        }catch(err){
          if(err.message==='OFFER_REJECTED'){
            // Generate an instant counter from the selling club
            const counter=typeof generateBuyCounter==='function'?generateBuyCounter(player,offer):null;
            if(counter){
              const userTeam=await getTeam((await getSave()).userTeamId);
              const budget=userTeam?.budget??0;
              const cMin=Math.floor(offer);
              const cMax=Math.min(budget,Math.floor(counter.fee*1.3));
              const cDef=Math.min(budget,counter.fee);
              showModal(`💬 ${tn} Counter-Offer`,`
                <div class="ctr">
                  <div class="ctr-pl"><strong>${player.name}</strong><span class="pos ${g}">${player.position}</span></div>
                  <div class="ctr-row"><span>Your Offer</span><strong style="color:var(--acc3)">${fmt.money(offer)}</strong></div>
                  <div class="ctr-row"><span>They Want</span><strong style="color:var(--acc2)">${fmt.money(counter.fee)}</strong></div>
                  <div class="ctr-row"><span>Form Value</span><strong>${fmt.money(fv)}</strong></div>
                  <div class="ctr-row"><span>Budget</span><strong>${fmt.money(budget)}</strong></div>
                  ${budget<counter.fee?`<div class="ctr-warn">⚠️ Their asking price exceeds your budget</div>`:''}
                  <div style="margin:14px 0 6px;font-size:12px;font-weight:600;color:var(--tx)">Your Revised Offer</div>
                  <div style="display:flex;align-items:center;gap:10px">
                    <input type="range" id="buy-counter-slider" min="${cMin}" max="${cMax}" value="${cDef}" step="500000" style="flex:1">
                    <div id="buy-counter-val" style="font-family:var(--fd);font-size:18px;color:var(--acc2);min-width:80px;text-align:right">${fmt.money(cDef)}</div>
                  </div>
                  <div id="buy-counter-hint" style="font-size:11px;margin-top:5px"></div>
                </div>`,
                [{id:'acc',label:'Send Revised Offer',cls:'btn-p',handler:async()=>{
                  const revOffer=Number(document.getElementById('buy-counter-slider')?.value||cDef);
                  try{
                    await buyPlayer(player.id,revOffer);
                    toast(`✅ ${player.name} signed for ${fmt.money(revOffer)}!`,'success',5000);
                    _selPid=null; document.getElementById('tr-layout')?.classList.remove('dp-open');
                    await renderTransfers();
                  }catch(e2){
                    if(e2.message==='OFFER_REJECTED'){
                      const _s=await getSave(); const _cd=[...(_s.collapsedDeals||[]),player.id]; await putSave({..._s,collapsedDeals:_cd});
                      toast(`❌ ${tn} still not satisfied — deal collapsed`,'error',4000);
                    }
                    else toast(`❌ ${e2.message}`,'error',4000);
                  }
                }},{id:'x',label:'Walk Away',cls:'btn-s'}]
              );
              // Wire slider
              const bsl=document.getElementById('buy-counter-slider'),bvl=document.getElementById('buy-counter-val'),bhn=document.getElementById('buy-counter-hint');
              if(bsl){
                const updateBuyHint=()=>{
                  const v=Number(bsl.value);
                  if(bvl) bvl.textContent=fmt.money(v);
                  if(bhn){
                    if(v>=counter.fee){ bhn.textContent='🤝 Meets their asking price'; bhn.style.color='var(--acc)'; }
                    else if(v>=counter.fee*0.95){ bhn.textContent='✓ Very close — likely accepted'; bhn.style.color='var(--acc)'; }
                    else if(v>=counter.fee*0.85){ bhn.textContent='⚠️ Below asking — they may accept'; bhn.style.color='var(--acc2)'; }
                    else{ bhn.textContent='✕ Too low — will probably be rejected'; bhn.style.color='var(--acc3)'; }
                  }
                };
                bsl.oninput=updateBuyHint; updateBuyHint();
              }
            } else {
              const _s2=await getSave(); const _cd2=[...(_s2.collapsedDeals||[]),player.id]; await putSave({..._s2,collapsedDeals:_cd2});
              toast(`❌ ${tn} rejected and won't negotiate further`,'error',5000);
            }
          } else {
            const msgs={INSUFFICIENT_FUNDS:'Not enough budget.',ALREADY_IN_SQUAD:'Already in your squad.'};
            toast(`❌ ${msgs[err.message]||err.message}`,'error',5000);
          }
        }
      }},{id:'x',label:'Cancel',cls:'btn-s'}]
    );
  };
}
async function renderSellList(userTeamId){
  const el=document.getElementById('sell-list');
  if(!el) return;
  const players=await getPlayersByTeam(userTeamId);
  el.innerHTML=[...players].sort((a,b)=>primaryRating(b)-primaryRating(a)).map(p=>{
    const g=posGroup(p.position),r=primaryRating(p);
    const fv=typeof formAdjustedValue==='function'?formAdjustedValue(p):p.value;
    const isL=p.transferListed===true;
    return`<div class="pl-row">
      <div class="pl-av" style="background:var(--sur3);font-size:8px;font-family:var(--fm);font-weight:700;color:var(--tx2);letter-spacing:.5px">${posGroup(p.position)}</div>
      <div class="pl-info"><div class="pl-name">${p.name}${isL?` <span class="listed-badge">LISTED</span>`:''}</div><div class="pl-meta"><span class="pos ${g}">${p.position}</span><span>Age ${p.age}</span></div></div>
      <div class="pl-val">${fmt.money(fv)}</div><div class="pl-rat">${r}</div>
      <button class="sell-btn" data-sid="${p.id}">Sell</button>
    </div>`;
  }).join('');
  el.querySelectorAll('.sell-btn').forEach(btn=>{
    btn.onclick=async(e)=>{
      e.stopPropagation();
      const pl=players.find(p=>p.id===btn.dataset.sid); if(!pl) return;
      const fv=typeof formAdjustedValue==='function'?formAdjustedValue(pl):pl.value;
      const est=Math.round(fv*(0.92+Math.random()*0.2));
      showModal('Sell Player',`<div class="ctr">
        <div class="ctr-pl"><strong>${pl.name}</strong><span class="pos ${posGroup(pl.position)}">${pl.position}</span></div>
        <div class="ctr-row"><span>Est. Fee</span><strong style="color:var(--acc2)">~${fmt.money(est)}</strong></div>
        <div class="ctr-row"><span>Form Value</span><strong>${fmt.money(fv)}</strong></div>
      </div>`,
      [{id:'s',label:'Accept Best Offer',cls:'btn-p',handler:async()=>{
        try{
          // Optimistically dim the row immediately
          const rowEl = el.querySelector(`[data-sid="${pl.id}"]`)?.closest('.pl-row');
          if (rowEl) { rowEl.style.opacity = '0.3'; rowEl.style.pointerEvents = 'none'; }
          const{fee,buyerName}=await sellPlayer(pl.id);
          toast(`✅ ${pl.name} sold to ${buyerName} for ${fmt.money(fee)}!`,'success',5000);
          await renderTransfers();
        }
        catch(err){toast(`❌ ${err.message}`,'error',5000);}
      }},{id:'x',label:'Cancel',cls:'btn-s'}]);
    };
  });
}

