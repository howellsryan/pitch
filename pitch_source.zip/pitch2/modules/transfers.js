/** modules/transfers.js — buyPlayer, sellPlayer, generateAIOffers, formAdjustedValue */

import { getSave, getTeam, getPlayer, putTeam, putPlayer, getAllPlayers, getAllTeams, addTransfer, putSave } from './db.js';
import { primaryRating } from './matchEngine.js';

// ─── Form-adjusted value ──────────────────────────────────────
// Computes a realistic market value factoring in: base value, current form,
// age, and potential. Higher-value players get smaller % boosts from form
// to prevent £100M players becoming £250M. Young high-potential players
// in form get outsized premiums (the "wonderkid tax").
export function formAdjustedValue(player) {
  const base  = Number(player.value) || 10_000_000;
  const age   = player.age ?? 24;
  const pot   = player.potentialRating ?? 70;
  const cur   = _fav_primaryRating(player);
  const headroom = Math.max(0, pot - cur);

  // ── Form score: 50 = average, 80+ = hot ──
  const formScore = 50 + (player.goals ?? 0) * 8 + (player.assists ?? 0) * 5 + (player.cleanSheets ?? 0) * 6;
  const cappedForm = Math.min(99, formScore);

  // ── Form multiplier: scales DOWN for expensive players ──
  // Base form effect: hot form = up to +50%, cold = down to -25%
  let formMult;
  if (cappedForm >= 80)      formMult = 1.25 + (cappedForm - 80) * 0.013; // 80→1.25, 99→1.50
  else if (cappedForm >= 65) formMult = 1.08 + (cappedForm - 65) * 0.011; // 65→1.08, 79→1.24
  else if (cappedForm >= 50) formMult = 1.0;                               // average
  else if (cappedForm >= 35) formMult = 0.92 - (50 - cappedForm) * 0.004;  // 35→0.86
  else                       formMult = 0.75;

  // Dampen form effect for high-value players (diminishing returns)
  // A £100M player at 1.50× form mult → dampened to ~1.30× (not £150M)
  // A £10M player at 1.50× form mult → stays closer to 1.45× (£14.5M)
  const valueTier = Math.min(1, base / 80_000_000); // 0-1 scale, 1 at £80M+
  const dampening = 1 - valueTier * 0.4;            // 1.0 for cheap, 0.6 for expensive
  const dampenedFormMult = 1 + (formMult - 1) * dampening;

  // ── Youth/potential premium ──
  // Young players with high potential command outsized premiums when in form
  let potentialMult = 1.0;
  if (age <= 23 && headroom > 10) {
    // Big potential gap + young = "wonderkid tax"
    const potPremium = Math.min(0.8, headroom * 0.03); // up to +80% for 27+ headroom
    // But only fully applies when in form — cold wonderkid doesn't get premium
    const formFactor = Math.max(0, (cappedForm - 50) / 40); // 0 at avg, 1 at 90 form
    potentialMult = 1 + potPremium * (0.3 + 0.7 * formFactor);
  } else if (age <= 26 && headroom > 5) {
    potentialMult = 1 + Math.min(0.25, headroom * 0.015);
  }

  // ── Age discount for older players ──
  const ageMult = age >= 33 ? 0.80 : age >= 31 ? 0.90 : age >= 29 ? 0.95 : 1.0;

  return Math.max(500_000, Math.round(base * dampenedFormMult * potentialMult * ageMult));
}

function _fav_primaryRating(p) {
  const pos = p.position;
  if (['ST','CF','RW','LW','CAM'].includes(pos)) return p.attack;
  if (['CM','CDM','RM','LM'].includes(pos))       return p.midfield;
  if (['CB','RB','LB'].includes(pos))             return p.defence;
  return p.goalkeeping;
}

export function minimumOffer(player) {
  return Math.floor(formAdjustedValue(player) * 0.88);
}

// ─── Buy a player ─────────────────────────────────────────────
export async function buyPlayer(playerId, offerAmount) {
  const save   = await getSave();
  const player = await getPlayer(playerId);
  if (!player)                           throw new Error('PLAYER_NOT_FOUND');
  if (player.teamId === save.userTeamId) throw new Error('ALREADY_IN_SQUAD');

  const userTeam   = await getTeam(save.userTeamId);
  if (!userTeam || userTeam.budget < offerAmount) throw new Error('INSUFFICIENT_FUNDS');

  // Capture BEFORE any writes
  const fromTeamId = player.teamId;
  const fromTeam   = await getTeam(fromTeamId);

  const threshold = minimumOffer(player);
  if (offerAmount < threshold) throw new Error('OFFER_REJECTED');
  if (offerAmount < formAdjustedValue(player) && Math.random() < 0.10) throw new Error('OFFER_REJECTED');

  await putTeam({ ...userTeam, budget: userTeam.budget - offerAmount });
  if (fromTeam) await putTeam({ ...fromTeam, budget: fromTeam.budget + offerAmount });
  const updated = { ...player, teamId: save.userTeamId };
  await putPlayer(updated);
  await addTransfer({ playerId, playerName: player.name, fromTeamId, toTeamId: save.userTeamId, fee: offerAmount, type: 'buy', date: save.currentDate });
  return { success: true, player: updated, fee: offerAmount };
}

// ─── Sell a player ────────────────────────────────────────────
export async function sellPlayer(playerId) {
  const save   = await getSave();
  const player = await getPlayer(playerId);
  if (!player || player.teamId !== save.userTeamId) throw new Error('PLAYER_NOT_IN_SQUAD');

  const allPlayers = await getAllPlayers();
  const aiIds      = [...new Set(allPlayers.map(p => p.teamId))].filter(id => id !== save.userTeamId);
  const buyerId    = aiIds[Math.floor(Math.random() * aiIds.length)];
  const buyerTeam  = await getTeam(buyerId);
  const fee        = Math.round(formAdjustedValue(player) * (0.9 + Math.random() * 0.22));

  if (!buyerTeam || buyerTeam.budget < fee) throw new Error('NO_BUYERS');

  const userTeam = await getTeam(save.userTeamId);
  await putTeam({ ...buyerTeam, budget: buyerTeam.budget - fee });
  await putTeam({ ...userTeam,  budget: userTeam.budget  + fee });
  await putPlayer({ ...player, teamId: buyerId });
  await addTransfer({ playerId, playerName: player.name, fromTeamId: save.userTeamId, toTeamId: buyerId, fee, type: 'sell', date: save.currentDate });
  return { success: true, fee, buyerName: buyerTeam.name };
}

// ─── Generate AI inbound offers ───────────────────────────────
/**
 * Each gameweek, AI clubs may bid on your players.
 * Stored in save.inboundOffers = [{playerId, clubId, clubName, fee, date, status}]
 */
export async function generateAIOffers() {
  const save      = await getSave();
  const myPlayers = await getAllPlayers();
  const userSquad = myPlayers.filter(p => p.teamId === save.userTeamId);
  const allTeams  = await getAllTeams();
  const aiTeams   = allTeams.filter(t => t.id !== save.userTeamId);

  const existing = save.inboundOffers?.filter(o => o.status === 'pending') ?? [];

  // Limit to 2 new offers per gameweek
  const newOffers = [];
  const shuffled  = [...userSquad].sort(() => Math.random() - 0.5);
  for (const player of shuffled.slice(0, 4)) {
    if (existing.find(o => o.playerId === player.id)) continue;
    if (Math.random() > 0.25) continue; // 25% chance per player per GW
    const club = aiTeams[Math.floor(Math.random() * aiTeams.length)];
    const fav  = formAdjustedValue(player);
    const fee  = Math.round(fav * (0.85 + Math.random() * 0.35));
    if (club.budget < fee) continue;
    newOffers.push({ playerId: player.id, playerName: player.name, clubId: club.id, clubName: club.name, fee, date: save.currentDate, status: 'pending' });
    if (newOffers.length >= 2) break;
  }

  const allOffers = [...existing, ...newOffers];
  await putSave({ ...save, inboundOffers: allOffers });
  return newOffers;
}

// ─── Accept an inbound offer ──────────────────────────────────
export async function acceptOffer(playerId) {
  const save   = await getSave();
  const offer  = save.inboundOffers?.find(o => o.playerId === playerId && o.status === 'pending');
  if (!offer) throw new Error('OFFER_NOT_FOUND');

  const player   = await getPlayer(playerId);
  const buyerTeam = await getTeam(offer.clubId);
  const userTeam  = await getTeam(save.userTeamId);
  if (!buyerTeam || buyerTeam.budget < offer.fee) throw new Error('BUYER_CANT_AFFORD');

  await putTeam({ ...buyerTeam, budget: buyerTeam.budget - offer.fee });
  await putTeam({ ...userTeam,  budget: userTeam.budget  + offer.fee });
  await putPlayer({ ...player, teamId: offer.clubId });
  await addTransfer({ playerId, playerName: player.name, fromTeamId: save.userTeamId, toTeamId: offer.clubId, fee: offer.fee, type: 'accepted_offer', date: save.currentDate });

  const updated = save.inboundOffers.map(o => o.playerId === playerId ? { ...o, status: 'accepted' } : o);
  await putSave({ ...save, inboundOffers: updated });
  return { success: true, fee: offer.fee, buyerName: offer.clubName };
}

// ─── Reject an offer ──────────────────────────────────────────
export async function rejectOffer(playerId) {
  const save  = await getSave();
  const updated = (save.inboundOffers ?? []).map(o => o.playerId === playerId && o.status === 'pending' ? { ...o, status: 'rejected' } : o);
  await putSave({ ...save, inboundOffers: updated });
}

// ─── Counter an offer — instant negotiation ─────────────────
export async function counterOffer(playerId, askingPrice) {
  const save   = await getSave();
  const player = await getPlayer(playerId);
  const fav    = player ? formAdjustedValue(player) : askingPrice;
  let result   = { outcome: 'rejected' };

  const updated = (save.inboundOffers ?? []).map(o => {
    if (o.playerId !== playerId || o.status !== 'pending') return o;

    // AI decision logic:
    // If asking <= 105% of their original offer, they just accept at your asking price
    if (askingPrice <= o.fee * 1.05) {
      result = { outcome: 'accepted', fee: askingPrice, clubName: o.clubName };
      return { ...o, fee: askingPrice, status: 'pending' };
    }

    // If asking is reasonable (within 130% of their offer), chance they meet in the middle
    const stretch = askingPrice / o.fee;
    if (stretch <= 1.30 && Math.random() < 0.55) {
      const meetFee = Math.round(o.fee + (askingPrice - o.fee) * (0.4 + Math.random() * 0.4));
      result = { outcome: 'accepted', fee: meetFee, clubName: o.clubName };
      return { ...o, fee: meetFee, status: 'pending' };
    }

    // Otherwise they come back with a revised (higher) counter, or walk away
    if (Math.random() < 0.6) {
      // AI bumps their offer up but not to your asking price
      const bump = Math.round(o.fee * (1.05 + Math.random() * 0.15));
      const newFee = Math.min(bump, askingPrice - 1);
      result = { outcome: 'counter', fee: newFee, clubName: o.clubName, originalFee: o.fee };
      return { ...o, fee: newFee, status: 'pending' };
    }

    // Walk away
    result = { outcome: 'rejected', clubName: o.clubName };
    return { ...o, counterAsking: askingPrice, status: 'counter_rejected' };
  });

  await putSave({ ...save, inboundOffers: updated });
  return result;
}

// ─── Buy-side counter: club comes back with price after rejection ──
export function generateBuyCounter(player, offerAmount) {
  const fav       = formAdjustedValue(player);
  const threshold = minimumOffer(player);

  // If offer was way too low, they don't negotiate
  if (offerAmount < threshold * 0.7) return null;

  // Club counters at somewhere between form value and 115% of form value
  const counterFee = Math.round(fav * (1.0 + Math.random() * 0.15));
  // Small chance they just won't sell at all
  if (Math.random() < 0.15) return null;

  return { fee: counterFee, playerName: player.name, playerId: player.id };
}
