/**
 * data/plTeams.js — 2025/26 Premier League squads
 * Accurate as of March 2026, including:
 *   - Relegated: Leicester City, Ipswich Town, Southampton (to Championship)
 *   - Promoted: Leeds United (champions), Burnley (runners-up), Sunderland (play-offs)
 *   - Alexander Isak → Liverpool (£125m, Sep 2025)
 *   - Hugo Ekitike → Liverpool (£79m, summer 2025)
 *   - Florian Wirtz → Liverpool (£116m, summer 2025)
 *   - Jeremie Frimpong → Liverpool (from Leverkusen)
 *   - Milos Kerkez → Liverpool (from Bournemouth)
 *   - Yoane Wissa → Newcastle (£55m, from Brentford)
 *   - Nick Woltemade → Newcastle (£65m, from Stuttgart)
 *   - Trent Alexander-Arnold → Real Madrid (Jan 2025)
 *   - Jadon Sancho → Chelsea (Jan 2026)
 *   - Luis Díaz → Bayern Munich (summer 2025)
 *   - Darwin Núñez → Al-Hilal (summer 2025)
 *   - Ivan Toney → Al-Ahli (Jan 2026)
 *   - Marcus Rashford → AC Milan (loan, Jan 2026)
 *   - Cole Palmer — key man Chelsea
 *   - Florian Wirtz — Liverpool record signing
 *
 * p(id, name, position, age, attack, midfield, defence, gk, value_£m, wage_£k/w)
 */
const p = (id, nm, pos, age, atk, mid, def, gk, val, wage) => ({
  id, name: nm, position: pos, age,
  attack: atk, midfield: mid, defence: def, goalkeeping: gk,
  value: val * 1_000_000, wage: wage * 1_000,
  goals: 0, assists: 0, cleanSheets: 0, form: 50,
  injured: false, suspended: false, inSquad: true, fitness: 100,
});

const PL_TEAMS = [
// ── ARSENAL ──────────────────────────────────────────────────
{ id:'arsenal', name:'Arsenal', shortName:'ARS', crest:'🔴',
  league:'Premier League', stadium:'Emirates Stadium', stadiumCapacity:60704,
  budget:130_000_000, reputation:88, primaryColor:'#EF0107', players:[
  p('ars_raya',       'D. Raya',            'GK',  29,12,15,20,87,35, 82),
  p('ars_turner',     'M. Turner',           'GK',  30,10,12,15,76,14, 40),
  p('ars_white',      'B. White',            'RB',  27,73,70,85,10,62,132),
  p('ars_timber',     'J. Timber',           'RB',  23,71,72,82,10,62,112),
  p('ars_saliba',     'W. Saliba',           'CB',  24,46,53,91,10,105,178),
  p('ars_gabriel',    'Gabriel Magalhães',   'CB',  27,58,56,88,10,72,152),
  p('ars_calafiori',  'R. Calafiori',        'LB',  22,68,70,80,10,55, 92),
  p('ars_zinchenko',  'O. Zinchenko',        'LB',  28,71,79,79,10,38,112),
  p('ars_rice',       'D. Rice',             'CDM', 26,68,89,83,10,118,312),
  p('ars_partey',     'T. Partey',           'CDM', 31,62,83,78,10,28,178),
  p('ars_merino',     'M. Merino',           'CM',  28,70,84,66,10,40,102),
  p('ars_odegaard',   'M. Ødegaard',         'CAM', 26,84,91,63,10,118,312),
  p('ars_saka',       'B. Saka',             'RW',  23,89,83,61,10,165,322),
  p('ars_martinelli', 'G. Martinelli',       'LW',  23,85,73,53,10,72,162),
  p('ars_trossard',   'L. Trossard',         'LW',  30,82,77,56,10,40,152),
  p('ars_havertz',    'K. Havertz',          'CF',  26,85,81,53,10,78,292),
  p('ars_nketiah',    'E. Nketiah',          'ST',  25,79,61,41,10,26, 88),
]},
// ── ASTON VILLA ──────────────────────────────────────────────
{ id:'aston_villa', name:'Aston Villa', shortName:'AVL', crest:'🦁',
  league:'Premier League', stadium:'Villa Park', stadiumCapacity:42095,
  budget:90_000_000, reputation:82, primaryColor:'#670E36', players:[
  p('avl_martinez',  'E. Martínez',          'GK',  32,14,15,18,90,45,182),
  p('avl_olsen',     'R. Olsen',             'GK',  35,10,10,12,74, 5, 25),
  p('avl_cash',      'M. Cash',              'RB',  27,71,67,81,10,30, 84),
  p('avl_konsa',     'E. Konsa',             'CB',  27,49,51,85,10,55,110),
  p('avl_carlos',    'D. Carlos',            'CB',  26,46,52,82,10,32, 72),
  p('avl_digne',     'L. Digne',             'LB',  32,68,66,76,10,12, 96),
  p('avl_kamara',    'B. Kamara',            'CM',  25,61,83,75,10,38,110),
  p('avl_mcginn',    'J. McGinn',            'CM',  30,73,84,65,10,38,134),
  p('avl_tielemans', 'Y. Tielemans',         'CM',  28,71,84,67,10,28,102),
  p('avl_bailey',    'L. Bailey',            'RW',  27,81,71,49,10,35,102),
  p('avl_diaby',     'M. Diaby',             'LW',  28,84,73,49,10,52,164),
  p('avl_watkins',   'O. Watkins',           'ST',  29,88,66,49,10,78,218),
  p('avl_rogers',    'M. Rogers',            'CAM', 22,79,78,53,10,42, 72),
  p('avl_duran',     'J. Durán',             'ST',  21,80,59,40,10,42, 65),
]},
// ── BOURNEMOUTH ──────────────────────────────────────────────
{ id:'bournemouth', name:'Bournemouth', shortName:'BOU', crest:'🍒',
  league:'Premier League', stadium:'Vitality Stadium', stadiumCapacity:11307,
  budget:38_000_000, reputation:68, primaryColor:'#DA291C', players:[
  p('bou_neto',       'Neto',                'GK',  35,12,12,15,81, 7, 40),
  p('bou_travers',    'M. Travers',          'GK',  25,10,10,12,74, 8, 18),
  p('bou_smith',      'A. Smith',            'RB',  29,63,59,75,10,10, 37),
  p('bou_senesi',     'M. Senesi',           'CB',  27,45,47,79,10,20, 52),
  p('bou_kelly',      'L. Kelly',            'CB',  26,43,46,79,10,17, 42),
  // Kerkez left to Liverpool
  p('bou_hill',       'J. Hill',             'LB',  22,62,58,72,10,12, 28),
  p('bou_cook',       'L. Cook',             'CDM', 28,56,77,71,10,12, 42),
  p('bou_christie',   'R. Christie',         'CM',  29,66,77,63,10,12, 47),
  p('bou_semenyo',    'A. Semenyo',          'RW',  25,77,63,45,10,25, 45),
  p('bou_kluivert',   'J. Kluivert',         'LW',  25,80,68,46,10,35, 62),
  p('bou_tavernier',  'M. Tavernier',        'CAM', 25,75,79,51,10,18, 42),
  p('bou_evanilson',  'Evanilson',           'ST',  25,82,62,42,10,45, 65),
  p('bou_brooks',     'D. Brooks',           'RW',  27,73,69,49,10,10, 37),
]},
// ── BRENTFORD ────────────────────────────────────────────────
{ id:'brentford', name:'Brentford', shortName:'BRE', crest:'🐝',
  league:'Premier League', stadium:'Gtech Community Stadium', stadiumCapacity:17250,
  budget:55_000_000, reputation:71, primaryColor:'#D20000', players:[
  p('bre_flekken',    'M. Flekken',          'GK',  31,12,14,16,83,17, 42),
  p('bre_valter',     'B. Valter',           'GK',  24,10,10,12,72, 5, 15),
  p('bre_roerslev',   'M. Roerslev',         'RB',  25,65,61,75,10,13, 37),
  p('bre_pinnock',    'E. Pinnock',          'CB',  31,45,49,81,10,18, 57),
  p('bre_collins',    'N. Collins',          'CB',  24,43,46,79,10,20, 42),
  p('bre_henry',      'R. Henry',            'LB',  27,65,61,77,10,14, 42),
  p('bre_norgaard',   'C. Nørgaard',         'CDM', 31,59,81,75,10,20, 62),
  p('bre_janelt',     'V. Janelt',           'CM',  26,63,79,67,10,19, 47),
  p('bre_dasilva',    'J. Da Silva',         'LM',  26,71,77,59,10,22, 52),
  p('bre_mbeumo',     'B. Mbeumo',           'RW',  25,87,72,49,10,78, 92),
  // Wissa left to Newcastle
  p('bre_schade',     'K. Schade',           'LW',  23,79,65,43,10,28, 58),
  p('bre_yarmolyuk',  'V. Yarmolyuk',        'CAM', 21,72,74,52,10,18, 30),
  p('bre_miller',     'K. Miller',           'ST',  22,76,58,40,10,18, 30),
]},
// ── BRIGHTON ─────────────────────────────────────────────────
{ id:'brighton', name:'Brighton', shortName:'BHA', crest:'🕊️',
  league:'Premier League', stadium:'Amex Stadium', stadiumCapacity:31800,
  budget:72_000_000, reputation:77, primaryColor:'#0057B8', players:[
  p('bha_verbruggen','B. Verbruggen',        'GK',  23,10,10,12,82,22, 32),
  p('bha_steele',    'J. Steele',            'GK',  29,10,10,12,76, 8, 25),
  p('bha_veltman',   'J. Veltman',           'RB',  33,63,61,77,10, 8, 40),
  p('bha_dunk',      'L. Dunk',             'CB',  33,45,51,83,10,12, 60),
  p('bha_igor',      'Igor',                'CB',  26,45,53,81,10,22, 52),
  p('bha_estupinan', 'P. Estupinán',        'LB',  27,71,67,79,10,40, 82),
  p('bha_gross',     'P. Groß',             'CM',  33,69,83,65,10,12, 80),
  p('bha_baleba',    'C. Baleba',           'CDM', 21,56,79,71,10,35, 55),
  p('bha_gilmour',   'B. Gilmour',          'CM',  24,61,81,63,10,25, 55),
  p('bha_mitoma',    'K. Mitoma',           'LW',  27,87,73,53,10,62, 95),
  p('bha_adingra',   'S. Adingra',          'RW',  23,79,63,45,10,32, 55),
  p('bha_joao-pedro','João Pedro',          'ST',  23,81,63,43,10,40, 62),
  p('bha_minteh',    'Y. Minteh',           'RW',  21,80,65,44,10,40, 58),
]},
// ── CHELSEA ──────────────────────────────────────────────────
{ id:'chelsea', name:'Chelsea', shortName:'CHE', crest:'🔵',
  league:'Premier League', stadium:'Stamford Bridge', stadiumCapacity:40343,
  budget:160_000_000, reputation:86, primaryColor:'#034694', players:[
  p('che_sanchez',   'R. Sánchez',          'GK',  28,12,14,16,80,20, 65),
  p('che_petrovic',  'D. Petrovic',         'GK',  25,10,10,12,79,12, 35),
  p('che_reece',     'R. James',            'RB',  25,77,73,83,10,72,212),
  p('che_colwill',   'L. Colwill',          'CB',  22,52,58,84,10,58, 92),
  p('che_badiashile','B. Badiashile',       'CB',  23,43,49,81,10,38, 85),
  p('che_cucurella', 'M. Cucurella',        'LB',  26,66,63,77,10,32,125),
  p('che_caicedo',   'M. Caicedo',          'CDM', 23,61,86,81,10,118,265),
  p('che_fernandez', 'E. Fernández',        'CM',  24,66,85,69,10,82,208),
  p('che_palmer',    'C. Palmer',           'CAM', 23,91,88,58,10,165,308),
  p('che_nkunku',    'C. Nkunku',           'CF',  27,87,76,51,10,68,212),
  p('che_jackson',   'N. Jackson',          'ST',  24,83,61,43,10,52,125),
  // Sancho joined Jan 2026
  p('che_sancho',    'J. Sancho',           'RW',  25,83,73,53,10,68,148),
  p('che_mudryk',    'M. Mudryk',           'LW',  24,81,69,47,10,55,192),
  p('che_guiu',      'M. Guiu',             'ST',  19,78,55,38,10,32, 40),
]},
// ── CRYSTAL PALACE ───────────────────────────────────────────
{ id:'crystal_palace', name:'Crystal Palace', shortName:'CRY', crest:'🦅',
  league:'Premier League', stadium:'Selhurst Park', stadiumCapacity:25486,
  budget:42_000_000, reputation:72, primaryColor:'#1B458F', players:[
  p('cry_henderson','D. Henderson',         'GK',  28,12,14,16,83,25, 72),
  p('cry_johnstone','S. Johnstone',         'GK',  32,10,10,12,75, 6, 30),
  p('cry_ward',     'J. Ward',              'RB',  35,59,56,75,10, 4, 40),
  p('cry_andersen', 'J. Andersen',          'CB',  29,45,51,85,10,34, 92),
  p('cry_guehi',    'M. Guéhi',            'CB',  24,43,53,84,10,62, 85),
  p('cry_mitchell', 'T. Mitchell',          'LB',  25,65,61,77,10,25, 55),
  p('cry_wharton',  'A. Wharton',           'CDM', 21,53,77,69,10,25, 38),
  p('cry_eze',      'E. Eze',              'CAM', 26,84,85,53,10,68,128),
  p('cry_mateta',   'J. Mateta',           'ST',  28,82,57,39,10,35, 68),
  p('cry_edouard',  'O. Édouard',          'ST',  27,77,59,41,10,12, 62),
  p('cry_lerma',    'J. Lerma',            'CDM', 30,56,75,69,10,12, 50),
  p('cry_sarr',     'I. Sarr',             'RW',  27,82,68,46,10,38, 75),
  p('cry_schlupp',  'J. Schlupp',          'LM',  32,67,71,59,10, 7, 50),
]},
// ── EVERTON ──────────────────────────────────────────────────
{ id:'everton', name:'Everton', shortName:'EVE', crest:'💙',
  league:'Premier League', stadium:'Goodison Park', stadiumCapacity:39572,
  budget:35_000_000, reputation:73, primaryColor:'#003399', players:[
  p('eve_pickford',     'J. Pickford',      'GK',  30,14,14,18,85,32, 92),
  p('eve_virginia',     'J. Virginia',      'GK',  25,10,10,12,72, 5, 15),
  p('eve_mykolenko',    'V. Mykolenko',     'LB',  25,63,59,77,10,16, 42),
  p('eve_branthwaite',  'J. Branthwaite',   'CB',  22,43,49,83,10,62, 48),
  p('eve_tarkowski',    'J. Tarkowski',     'CB',  32,45,49,83,10,14, 62),
  p('eve_young',        'A. Young',         'RB',  39,57,55,71,10, 2, 40),
  p('eve_onana',        'A. Onana',         'CM',  28,63,79,65,10,26, 72),
  p('eve_doucoure',     'A. Doucouré',     'CM',  32,67,79,63,10,12, 90),
  p('eve_mcneil',       'D. McNeil',        'LM',  25,73,75,53,10,22, 45),
  p('eve_calvert-lewin','D. Calvert-Lewin', 'ST',  28,81,57,39,10,38,125),
  p('eve_ndiaye',       'I. Ndiaye',        'RW',  25,76,67,45,10,28, 52),
  p('eve_beto',         'Beto',             'ST',  27,75,49,35,10,24, 62),
  p('eve_harrison',     'J. Harrison',      'LW',  28,75,67,49,10,14, 50),
]},
// ── FULHAM ───────────────────────────────────────────────────
{ id:'fulham', name:'Fulham', shortName:'FUL', crest:'⚫',
  league:'Premier League', stadium:'Craven Cottage', stadiumCapacity:25700,
  budget:48_000_000, reputation:71, primaryColor:'#FFFFFF', players:[
  p('ful_leno',    'B. Leno',              'GK',  33,14,14,18,84,15, 82),
  p('ful_benda',   'S. Benda',             'GK',  24,10,10,12,70, 3, 15),
  p('ful_tete',    'Tete',                 'RB',  25,69,63,73,10,19, 52),
  p('ful_diop',    'I. Diop',             'CB',  28,45,49,79,10,18, 57),
  p('ful_tosin',   'Tosin',               'CB',  27,47,51,81,10,28, 62),
  p('ful_robinson','A. Robinson',          'LB',  27,67,65,77,10,25, 67),
  p('ful_palinha', 'J. Palhinha',          'CDM', 29,56,83,79,10,62,135),
  p('ful_pereira', 'A. Pereira',           'CM',  29,71,81,61,10,32, 82),
  p('ful_iwobi',   'A. Iwobi',            'CAM', 29,76,79,57,10,30, 82),
  p('ful_muniz',   'C. Muniz',            'ST',  24,79,55,37,10,32, 65),
  p('ful_jimenez', 'R. Jiménez',          'ST',  33,78,57,39,10,12,100),
  p('ful_adama',   'Adama Traoré',        'RW',  29,79,61,47,10,20, 80),
  p('ful_cairney', 'T. Cairney',          'CM',  33,64,78,58,10, 8, 60),
]},
// ── LEEDS UNITED ──────────────────────────────────────────────
// Promoted as Championship champions 2024/25 (100 pts)
// Key signings: Bijol, Longstaff, Stach, Perri, Okafor, Calvert-Lewin, Gudmundsson, Nmecha
{ id:'leeds', name:'Leeds United', shortName:'LEE', crest:'⚪',
  league:'Premier League', stadium:'Elland Road', stadiumCapacity:37645,
  budget:55_000_000, reputation:72, primaryColor:'#FFFFFF', players:[
  p('lee_perri',       'L. Perri',           'GK',  28,10,10,14,79,12, 35),
  p('lee_meslier',     'I. Meslier',         'GK',  25,10,10,12,76, 8, 25),
  p('lee_bogle',       'J. Bogle',           'RB',  25,65,60,76,10,14, 38),
  p('lee_struijk',     'P. Struijk',         'CB',  26,48,52,80,10,22, 52),
  p('lee_rodon',       'J. Rodon',           'CB',  27,44,50,79,10,18, 48),
  p('lee_bijol',       'J. Bijol',           'CB',  26,46,53,81,10,25, 55),
  p('lee_gudmundsson', 'G. Gudmundsson',     'LB',  25,64,62,76,10,14, 38),
  p('lee_ampadu',      'E. Ampadu',          'CDM', 25,58,76,73,10,18, 52),
  p('lee_stach',       'A. Stach',           'CM',  26,62,78,68,10,15, 42),
  p('lee_gruev',       'I. Gruev',           'CM',  24,60,75,66,10,12, 32),
  p('lee_aaronson',    'B. Aaronson',        'CAM', 25,76,77,55,10,20, 55),
  p('lee_gnonto',      'W. Gnonto',          'RW',  22,78,70,48,10,22, 52),
  p('lee_calvert_lewin','D. Calvert-Lewin',  'ST',  28,81,60,42,10,30, 72),
  p('lee_okafor',      'N. Okafor',          'LW',  25,79,66,44,10,22, 48),
]},
// ── BURNLEY ───────────────────────────────────────────────────
// Promoted as Championship runners-up 2024/25
// Key signings: Ward-Prowse, Florentino, Broja, Ugochukwu, Dubravka, K.Walker, Tchaouna, Flemming
{ id:'burnley', name:'Burnley', shortName:'BUR', crest:'🟤',
  league:'Premier League', stadium:'Turf Moor', stadiumCapacity:22546,
  budget:42_000_000, reputation:68, primaryColor:'#6C1D45', players:[
  p('bur_dubravka',    'M. Dubravka',       'GK',  36,10,10,14,79, 5, 28),
  p('bur_weiss',       'M. Weiß',           'GK',  22,10,10,12,74, 4, 15),
  p('bur_walker',      'K. Walker',         'RB',  36,66,64,80,10, 8, 55),
  p('bur_esteve',      'M. Estève',         'CB',  22,42,48,78,10,14, 32),
  p('bur_beyer',       'J. Beyer',          'CB',  25,44,50,77,10,12, 28),
  p('bur_hartman',     'Q. Hartman',        'LB',  23,66,63,76,10,12, 32),
  p('bur_florentino',  'Florentino',        'CDM', 26,55,78,72,10,22, 52),
  p('bur_ward_prowse', 'J. Ward-Prowse',    'CM',  31,72,82,62,10,14, 65),
  p('bur_cullen',      'J. Cullen',         'CM',  29,58,75,66,10, 8, 28),
  p('bur_ugochukwu',   'L. Ugochukwu',      'CM',  22,63,74,65,10,18, 38),
  p('bur_anthony',     'J. Anthony',        'RW',  26,76,68,48,10,12, 35),
  p('bur_flemming',    'Z. Flemming',       'CAM', 27,75,73,50,10,14, 38),
  p('bur_broja',       'A. Broja',          'ST',  24,77,56,38,10,20, 42),
  p('bur_foster',      'L. Foster',         'ST',  25,74,55,37,10,12, 28),
]},
// ── LIVERPOOL ─────────────────────────────────────────────────
// Key changes: +Wirtz(7), +Frimpong(30), +Kerkez(6), +Ekitike(22), +Isak(9)
// Departed: Alexander-Arnold→Real Madrid, Díaz→Bayern, Núñez→Al-Hilal
{ id:'liverpool', name:'Liverpool', shortName:'LIV', crest:'❤️',
  league:'Premier League', stadium:'Anfield', stadiumCapacity:61276,
  budget:80_000_000, reputation:95, primaryColor:'#C8102E', players:[
  p('liv_alisson',     'Alisson',           'GK',  32,14,16,20,93,58,212),
  p('liv_mamardashvili','G. Mamardashvili', 'GK',  24,10,10,12,83,42, 82),
  p('liv_frimpong',    'J. Frimpong',       'RB',  24,78,74,74,10,68,112),
  p('liv_bradley',     'C. Bradley',        'RB',  22,68,65,73,10,28, 52),
  p('liv_konate',      'I. Konaté',        'CB',  26,49,53,88,10,65,150),
  p('liv_van-dijk',    'V. van Dijk',       'CB',  34,53,59,91,10,52,285),
  p('liv_kerkez',      'M. Kerkez',         'LB',  21,70,66,78,10,48, 85),
  p('liv_robertson',   'A. Robertson',      'LB',  31,75,73,83,10,38,205),
  p('liv_mac-allister','A. Mac Allister',   'CDM', 26,69,87,73,10,78,218),
  p('liv_gravenberch', 'R. Gravenberch',   'CM',  23,74,86,66,10,72,148),
  p('liv_szoboszlai',  'D. Szoboszlai',    'CM',  24,79,87,63,10,82,188),
  p('liv_wirtz',       'F. Wirtz',          'CAM', 22,90,91,61,10,185,295),
  p('liv_salah',       'M. Salah',          'RW',  33,93,79,57,10,82,408),
  p('liv_gakpo',       'C. Gakpo',          'LW',  26,84,75,53,10,68,158),
  // Isak injured, Ekitike covering
  p('liv_isak',        'A. Isak',           'ST',  25,91,67,45,10,135,265),
  p('liv_ekitike',     'H. Ekitike',        'ST',  23,84,64,44,10,82, 85),
  p('liv_jota',        'D. Jota',           'CF',  28,85,71,51,10,58,155),
]},
// ── MANCHESTER CITY ──────────────────────────────────────────
{ id:'man_city', name:'Manchester City', shortName:'MCI', crest:'🩵',
  league:'Premier League', stadium:'Etihad Stadium', stadiumCapacity:55017,
  budget:200_000_000, reputation:96, primaryColor:'#6CABDD', players:[
  p('mci_ederson',   'Ederson',             'GK',  31,20,20,22,91,58,208),
  p('mci_ortega',    'S. Ortega',           'GK',  32,10,10,12,78,10, 45),
  p('mci_walker',    'K. Walker',           'RB',  35,70,66,82,10,18,188),
  p('mci_dias',      'R. Dias',             'CB',  27,49,55,91,10,78,218),
  p('mci_akanji',    'M. Akanji',           'CB',  29,47,53,88,10,55,168),
  p('mci_gvardiol',  'J. Gvardiol',         'LB',  23,73,69,85,10,88,175),
  p('mci_rodri',     'Rodri',               'CDM', 28,69,93,83,10,130,368),
  p('mci_kovacic',   'M. Kovačić',         'CM',  31,69,87,69,10,28,208),
  p('mci_bernardo',  'B. Silva',            'CM',  30,83,91,65,10,108,365),
  p('mci_doku',      'J. Doku',             'LW',  23,87,75,51,10,82,162),
  p('mci_foden',     'P. Foden',            'CAM', 25,91,91,59,10,162,428),
  p('mci_haaland',   'E. Haaland',          'ST',  25,97,63,45,10,212,428),
  p('mci_grealish',  'J. Grealish',         'LW',  29,85,83,55,10,58,305),
  p('mci_savinho',   'Savinho',             'RW',  21,82,73,50,10,58, 78),
]},
// ── MANCHESTER UNITED ────────────────────────────────────────
// Rashford on loan to AC Milan Jan 2026; Sancho sold to Chelsea
{ id:'man_utd', name:'Manchester United', shortName:'MUN', crest:'🔴',
  league:'Premier League', stadium:'Old Trafford', stadiumCapacity:74140,
  budget:95_000_000, reputation:88, primaryColor:'#DA291C', players:[
  p('mun_onana',    'A. Onana',             'GK',  29,14,16,18,83,52,125),
  p('mun_bayindir', 'A. Bayindir',          'GK',  27,10,10,12,75, 8, 30),
  p('mun_dalot',    'D. Dalot',             'RB',  26,71,67,79,10,42,105),
  p('mun_de-ligt',  'M. de Ligt',           'CB',  26,49,55,85,10,45,148),
  p('mun_maguire',  'H. Maguire',           'CB',  32,45,49,81,10,18,185),
  p('mun_shaw',     'L. Shaw',              'LB',  29,69,67,81,10,28,170),
  p('mun_ugarte',   'M. Ugarte',            'CDM', 24,62,84,76,10,62,118),
  p('mun_fernandes','B. Fernandes',         'CAM', 30,85,89,59,10,72,295),
  p('mun_mainoo',   'K. Mainoo',            'CM',  20,67,81,61,10,62, 65),
  p('mun_amad',     'Amad Diallo',          'RW',  22,81,70,46,10,38, 58),
  p('mun_hojlund',  'R. Højlund',          'ST',  22,83,59,39,10,72,178),
  p('mun_zirkzee',  'J. Zirkzee',           'ST',  24,80,65,42,10,42, 58),
  p('mun_antony',   'Antony',              'LW',  25,77,67,47,10,35,185),
]},
// ── NEWCASTLE UNITED ─────────────────────────────────────────
// Isak sold to Liverpool; +Wissa(9, £55m), +Woltemade(27, £65m)
{ id:'newcastle', name:'Newcastle United', shortName:'NEW', crest:'⚫',
  league:'Premier League', stadium:"St. James' Park", stadiumCapacity:52258,
  budget:120_000_000, reputation:85, primaryColor:'#241F20', players:[
  p('new_pope',       'N. Pope',            'GK',  33,14,14,18,87,26, 82),
  p('new_dubravka',   'M. Dúbravka',       'GK',  36,10,10,12,76, 5, 25),
  p('new_trippier',   'K. Trippier',        'RB',  34,77,75,83,10,28,152),
  p('new_schar',      'F. Schär',          'CB',  33,49,53,85,10,14, 82),
  p('new_botman',     'S. Botman',          'CB',  25,45,51,84,10,42, 95),
  p('new_burn',       'D. Burn',            'LB',  32,59,56,79,10,12, 58),
  p('new_guimaraes',  'B. Guimarães',      'CDM', 27,69,89,75,10,98,215),
  p('new_tonali',     'S. Tonali',          'CM',  25,67,86,73,10,58,128),
  p('new_joelinton',  'Joelinton',          'CM',  28,72,80,62,10,32, 92),
  p('new_gordon',     'A. Gordon',          'LW',  24,85,74,51,10,82,112),
  // Isak gone; Wissa and Woltemade are new strikers
  p('new_wissa',      'Y. Wissa',           'ST',  29,86,63,45,10,55,105),
  p('new_woltemade',  'N. Woltemade',       'ST',  24,80,66,43,10,65, 85),
  p('new_almiron',    'M. Almirón',        'CAM', 31,77,79,53,10,22, 92),
  p('new_barnes',     'H. Barnes',          'LW',  27,79,68,50,10,28, 72),
]},
// ── NOTTINGHAM FOREST ────────────────────────────────────────
{ id:'nottm_forest', name:'Nottm Forest', shortName:'NFO', crest:'🌲',
  league:'Premier League', stadium:'City Ground', stadiumCapacity:30455,
  budget:52_000_000, reputation:73, primaryColor:'#DD0000', players:[
  p('nfo_sels',       'M. Sels',            'GK',  33,12,12,15,82,10, 35),
  p('nfo_hennessey',  'W. Hennessey',       'GK',  38,10,10,12,74, 4, 25),
  p('nfo_aina',       'O. Aina',            'RB',  28,65,61,77,10,16, 42),
  p('nfo_murillo',    'Murillo',            'CB',  22,43,47,83,10,45, 62),
  p('nfo_milenkovic', 'N. Milenković',     'CB',  27,47,51,83,10,28, 65),
  p('nfo_williams',   'N. Williams',        'LB',  23,63,61,75,10,20, 35),
  p('nfo_sangare',    'I. Sangaré',        'CDM', 27,59,81,71,10,35, 72),
  p('nfo_gibbs-white','M. Gibbs-White',    'CAM', 25,82,83,55,10,48, 78),
  p('nfo_anderson',   'E. Anderson',        'CAM', 21,78,79,53,10,30, 48),
  p('nfo_elanga',     'A. Elanga',          'RW',  23,80,63,45,10,30, 52),
  p('nfo_hudson-odoi','C. Hudson-Odoi',    'LW',  24,78,69,47,10,24, 52),
  p('nfo_wood',       'C. Wood',            'ST',  33,79,53,37,10,10, 62),
  p('nfo_awoniyi',    'T. Awoniyi',         'ST',  27,80,57,39,10,28, 65),
]},
// ── SUNDERLAND ────────────────────────────────────────────────
// Promoted via Championship play-offs 2024/25 (beat Sheffield United 2-1)
// Key signings: Xhaka, Le Fée, Mukiele, Geertruida(loan), Brobbey, Traore, Mepham
{ id:'sunderland', name:'Sunderland', shortName:'SUN', crest:'🔴⚪',
  league:'Premier League', stadium:'Stadium of Light', stadiumCapacity:48707,
  budget:48_000_000, reputation:70, primaryColor:'#FF0000', players:[
  p('sun_patterson',  'A. Patterson',       'GK',  26,10,10,14,78,12, 32),
  p('sun_moore',      'S. Moore',           'GK',  35,10,10,12,72, 2, 10),
  p('sun_hume',       'T. Hume',            'RB',  23,63,60,76,10,12, 28),
  p('sun_ballard',    'D. Ballard',         'CB',  26,42,48,78,10,14, 35),
  p('sun_mepham',     'C. Mepham',          'CB',  27,40,47,76,10, 8, 22),
  p('sun_cirkin',     'D. Cirkin',          'LB',  23,62,60,76,10,10, 25),
  p('sun_mukiele',    'N. Mukiele',         'RB',  27,60,62,80,10,18, 48),
  p('sun_xhaka',      'G. Xhaka',          'CM',  33,66,84,72,10,18, 82),
  p('sun_le_fee',     'E. Le Fée',          'CM',  25,65,78,64,10,18, 42),
  p('sun_rigg',       'C. Rigg',            'CAM', 18,72,74,55,10,22, 45),
  p('sun_mundle',     'R. Mundle',          'RW',  23,76,67,46,10,15, 35),
  p('sun_roberts',    'P. Roberts',         'LW',  29,75,72,48,10, 8, 28),
  p('sun_isidor',     'W. Isidor',          'ST',  25,79,60,38,10,22, 48),
  p('sun_brobbey',    'B. Brobbey',         'ST',  23,78,55,36,10,25, 42),
]},
// ── TOTTENHAM HOTSPUR ────────────────────────────────────────
{ id:'tottenham', name:'Tottenham Hotspur', shortName:'TOT', crest:'🐓',
  league:'Premier League', stadium:'Tottenham Hotspur Stadium', stadiumCapacity:62850,
  budget:110_000_000, reputation:84, primaryColor:'#132257', players:[
  p('tot_vicario',   'G. Vicario',          'GK',  28,14,14,18,85,32, 85),
  p('tot_forster',   'F. Forster',          'GK',  36,10,10,12,73, 3, 30),
  p('tot_porro',     'P. Porro',            'RB',  25,75,69,79,10,52,110),
  p('tot_romero',    'C. Romero',           'CB',  27,51,57,88,10,72,180),
  p('tot_van-de-ven','M. van de Ven',       'CB',  24,49,55,87,10,72,150),
  p('tot_udogie',    'D. Udogie',           'LB',  23,71,66,79,10,52, 88),
  p('tot_bissouma',  'Y. Bissouma',         'CDM', 28,59,83,75,10,30,110),
  p('tot_bentancur', 'R. Bentancur',        'CM',  28,63,83,69,10,28,110),
  p('tot_maddison',  'J. Maddison',         'CAM', 28,83,87,57,10,62,208),
  p('tot_kulusevski','D. Kulusevski',       'RW',  25,84,79,55,10,65,160),
  p('tot_son',       'Son Heung-min',       'LW',  33,88,77,55,10,38,258),
  p('tot_solanke',   'D. Solanke',          'ST',  27,83,63,43,10,62, 90),
  p('tot_richarlison','Richarlison',        'ST',  27,83,63,47,10,38,208),
]},
// ── WEST HAM UNITED ──────────────────────────────────────────
{ id:'west_ham', name:'West Ham United', shortName:'WHU', crest:'⚒️',
  league:'Premier League', stadium:'London Stadium', stadiumCapacity:62500,
  budget:62_000_000, reputation:77, primaryColor:'#7A263A', players:[
  p('whu_areola',     'A. Areola',          'GK',  32,10,10,12,79,10, 42),
  p('whu_fabianski',  'L. Fabiański',      'GK',  40,10,10,14,74, 2, 48),
  p('whu_coufal',     'V. Coufal',          'RB',  32,66,63,77,10, 9, 50),
  p('whu_aguerd',     'N. Aguerd',          'CB',  28,45,51,81,10,32, 72),
  p('whu_zouma',      'K. Zouma',           'CB',  30,45,51,81,10,18,125),
  p('whu_emerson',    'Emerson Palmieri',   'LB',  30,67,63,75,10,12, 70),
  p('whu_alvarez',    'E. Álvarez',        'CDM', 24,61,83,71,10,38,110),
  p('whu_ward-prowse','J. Ward-Prowse',     'CM',  30,73,83,61,10,26, 92),
  p('whu_kudus',      'M. Kudus',           'CAM', 24,83,81,53,10,52,110),
  p('whu_bowen',      'J. Bowen',           'RW',  28,84,73,55,10,58,130),
  p('whu_paqueta',    'L. Paquetá',        'CAM', 27,81,85,53,10,65,130),
  p('whu_fullkrug',   'N. Füllkrug',        'ST',  32,81,60,42,10,32,115),
  p('whu_antonio',    'M. Antonio',         'ST',  34,75,57,41,10, 5, 78),
]},
// ── WOLVERHAMPTON ────────────────────────────────────────────
{ id:'wolves', name:'Wolverhampton Wanderers', shortName:'WOL', crest:'🐺',
  league:'Premier League', stadium:'Molineux Stadium', stadiumCapacity:32050,
  budget:40_000_000, reputation:70, primaryColor:'#FDB913', players:[
  p('wol_sa',          'José Sá',           'GK',  32,14,14,18,83,20, 62),
  p('wol_bentley',     'D. Bentley',        'GK',  30,10,10,12,72, 5, 20),
  p('wol_semedo',      'N. Semedo',         'RB',  31,69,65,79,10,16, 82),
  p('wol_kilman',      'M. Kilman',         'CB',  28,45,51,82,10,32, 65),
  p('wol_dawson',      'C. Dawson',         'CB',  34,45,47,79,10, 5, 50),
  p('wol_ait-nouri',   "R. Aït-Nouri",     'LB',  23,71,67,77,10,35, 58),
  p('wol_joao-gomes',  'João Gomes',        'CDM', 23,57,79,69,10,28, 58),
  p('wol_lemina',      'M. Lemina',         'CM',  31,63,77,65,10,12, 62),
  p('wol_neto',        'Pedro Neto',        'RW',  25,84,73,49,10,58, 85),
  p('wol_cunha',       'M. Cunha',          'CF',  25,85,73,47,10,58,110),
  p('wol_hwang',       'Hwang Hee-chan',    'ST',  29,79,63,43,10,20, 58),
  p('wol_strand-larsen','J. Strand Larsen', 'ST',  25,80,60,42,10,32, 48),
  p('wol_doyle',       'T. Doyle',          'CM',  22,61,73,59,10,12, 28),
]},
];

